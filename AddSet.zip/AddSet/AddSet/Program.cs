﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace AddSet
{
  partial class Program
  {
    static void Main(string[] args)
    {   // string input contains different combinations of code for test  adding 'set' 
      string input = "for(i,0,5)" + "\r\n" +
                      "{" + "\r\n" +
                      "  write#(\"a = 0;\");" + "\r\n" +
                      "  var x = 1;" + "\r\n" +
                      "  const c = 0;" + "\r\n" +
                      "  array arr[3] = 0;" + "\r\n" +
                      "  set a = 0;" + "\r\n" +
                      "  ssetrow s[] = {0,1,2,3};" + "\r\n" +
                      "  x = 2;" + "\r\n" +
                      "  y[0] = Three,3;" + "\r\n" +
                      "  {x = 1 == 2 ? True:False;}" + "\r\n" +
                      "====================" + "\r\n" +
                      " R = 2 != 3 ? True:False;" + "\r\n" +
                      "====================" + "\r\n" +
                      "}" + "\r\n" +
                      "====================" + "\r\n" +
                      "\"{x = 3;}\" {y = 3;}";
    
      //string input = "m = 100;n=0;";
      //string input = "set x = 0;";
      //string input = "set x1 = A;" + " " + "x2 = B;";

      //string input =  "{y = 3,three;}";
      // string input = "\"{x = 3;}\" {y = 3;}";
      // string input = "{x = 1 == 2 ? True:False;}";
      //string input = "x = concat(a)(\",\");";
      string output = AddCommandSet( input);
      Console.WriteLine("{0}", output);
    }
    //=====================================   
      static int indexAfterFunction = 0;
    //======================================================
      static bool SetCommandProcessing(ref string input, ref int j)
      {
        char[] beforeNotEqual = { '<', '>', '!' };
        char[] afterNotEqual = { '<', '>', '=' };
        char[] beforeEqual = { ' ', ']', '\t', '\r', '\n' };
        char[] beforeName = { '{', '}', ')', ';', '\r', '\n', ' ', '\t' };
        string[] commandsUsed_Equal = { "setkvp", "array", "sinit", "ssetrow", "sset", "set",
                                   "var", "const", "realloc" };
        char[] array = input.ToCharArray();
        if (j == 0)  // first call
        {
          // pass function and its parameters
          int indexToFunction = SmartIndexOf(input, "function");
          int indexToDelegate = SmartIndexOf(input, "delegate");
          //int indexToDlgt     = SmartIndexOf(input, "dlgt");
          if (indexToFunction != -1)
          {
            indexAfterFunction = indexToFunction + "function".Length;
            j = input.IndexOf(")", indexAfterFunction);  // after function parameters
            indexAfterFunction = j + 1;
            if (j == -1)
            {
              Console.WriteLine("Error: [SetCommandProcessing] ')' omitted  [{0}]", new object[] { input });
              return false;
            }
            return true;
          }
          if (indexToDelegate != -1)
          {
            indexAfterFunction = indexToFunction + "delegate".Length;
            j = input.IndexOf(")", indexAfterFunction);  // after function parameters
            indexAfterFunction = j + 1;
            if (j == -1)
            {
              Console.WriteLine("Error: [SetCommandProcessing] ')' omitted  [{0}]", new object[] { input });
              return false;
            }
            return true;
          }
          else
            indexAfterFunction = 0;
        }
        //if (indexAfterFunction == -1)
        //  indexAfterFunction = 0;
        if (input[j] != '=')
          return true;
        if ((j == 0) && (input[j] == '='))
        {
          Console.WriteLine("Error: [SetCommandProcessing] '=' is first character");
          return false;
        }
        //==============================================
        if (beforeNotEqual.Contains(input[j - 1]))
          return true;
        if (afterNotEqual.Contains(input[j + 1]))
        {
          j++;
          return true;
        }

        // ex. input = "else {\r\n  x = 100;"
        // to end of var.name
        int n;
        for (n = j - 1; n > -1; n--)
        {
          if (beforeEqual.Contains(input[n]) == true)
            break;
          /* if ((input[n] == ']') && (input[n + 1] == ' '))
           {
             n++;
             break;
           }*/
        }
        string setSentence = "";
        string tmp1 = "";  // input.Substring(0, j - 1);
        if (n != -1)
          tmp1 = input.Substring(0, n);   //ex.  tmp1 = "else {\r\n  y[0]"
                                          // to begin of var.name
        int m;
        for (m = n - 1; m > -1; m--)
        {
          if (beforeName.Contains(tmp1[m]) == true)
            break;
        }
        string head = "";
        if (m > 0)
          head = input.Substring(0, m + 1);   // string before name  "else {\r\n "
        int lastLndex = input.Length - 1;      // input[lastLndex] = ';'

        string SentenceWithoutSet = "";
        if (m == -1)
          SentenceWithoutSet = input.Substring(0, lastLndex + 1);
        else
          SentenceWithoutSet = input.Substring(head.Length);   // ex. y[] = OneHundred,100;

        int ind = -1;
        for (int jj = 0; jj < beforeName.Length; jj++)
        {
          ind = tmp1.IndexOf(beforeName[jj]);
          if (ind != -1)
            break;
        }
        //==============================================
        bool b = false;
        string tmp3 = input.Substring(indexAfterFunction);
        if ((tmp3.Contains("set")) && (tmp3.Contains("setkvp") == false))
        {
          setSentence = head + " " + SentenceWithoutSet;
          setSentence = ProcessingQuestionMark(setSentence);
          input = setSentence;
          j = setSentence.Length;
        }
        foreach (string cmd in commandsUsed_Equal)
        {
          if (tmp3.Contains(cmd))
          {
            b = true;
            break;
          }
        }
        if (b)
          return true;
        //==============================================
        //if (SmartIndexOf(SentenceWithoutSet, "{") != -1)  //array y[] = {,};
        //  return true;
        string command = "set";
        int end = 0;
        string tmp = GetContents(SentenceWithoutSet, '(', ')', ref end);
        if ((tmp.Length > 0) && (SmartIndexOf(tmp, ",") != -1))
        {
          Console.WriteLine("Error: [SetCommandProcessing] arguments on the right part of expression [{0}]", new object[] { SentenceWithoutSet });
          return false;
        }
        if (SmartIndexOf(SentenceWithoutSet, ",") != -1)       //  ex. x=concat("123")(",")(456);
          command = "setkvp";
        setSentence = head + command + " " + SentenceWithoutSet;
        setSentence = ProcessingQuestionMark(setSentence);
        input = setSentence;
        j = setSentence.Length;    
        return true;
      }
    //=======================================
      static string AddCommandSet(string input)
      {
        string result = "";
        string[] sentences = SmartSplit(input, new char[] { ';' });
        bool b;
        for (int i = 0; i < sentences.Length; i++)
        {
          if (sentences[i] != "\r\n")
          {
            sentences[i] += ";";
            b = ProcessingOutOfQuotes(ref sentences[i], SetCommandProcessing);
          }
        }
        foreach (string s in sentences)
        {
          if (s != "\r\n")
            result += s;
        }
        return result;
      }
    //=======================================
      public delegate bool CallBackDelegate(ref string input, ref int j);
      static bool ProcessingOutOfQuotes(ref string input, CallBackDelegate CallBackFunction)
      {
        bool inQuotes = false;
        bool b = false;
        for (int j = 0; j < input.Length - 1; j++)
        {
          char c = input[j];
          if (inQuotes)
          {
            if ((c == '\\') && (input[j + 1] == '\"'))
            {
              j++;
              continue;
            }
            if (c == '\"')
            {
              inQuotes ^= true;
              continue;
            }
          }
          else
          {
            if (c == '\"')
            {
              inQuotes ^= true;
              continue;
            }
            if (inQuotes == false)
            {
              b = CallBackFunction(ref input, ref j);
              if(!b)
              return false;
            }
          }
        }
        int lastIndex = input.Length - 1;
        if (input[lastIndex] == '\"')
          inQuotes ^= true;
       else
          b = CallBackFunction(ref input, ref lastIndex);
        return b;
      }
   
  }
}
