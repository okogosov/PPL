﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AddSet
{
  partial class Program
  {
    static string ProcessingQuestionMark(string input)
    {
      int indexQuestionMark = 0;
      int indexSet = 0;
      int indexSemiColon = 0;
      string tmp = input;
      string output = input;
      string statement = "";
      if ((input.Substring(0, 2) == "? ") || (input.Substring(0, 2) == "?;"))
        return output;
      while (true)
      {
        indexQuestionMark = SmartIndexOf(tmp, "?");   // //tmp.IndexOf("?");
        if (indexQuestionMark == -1)
          break;
        int j = indexQuestionMark - 1;
        statement = "";
        while (true)
        {
          if (j == -1)
          {
            Console.Write("Error:  [ProcessingQuestionMark] 'set' is not found ");
            return "";
          }
          if (tmp[j] == ';')
          {
            Console.Write("Error:  [ProcessingQuestionMark] 'set' is not found ");
            return "";
          }
          statement = tmp[j] + statement;
          if (statement.Length < 3)
            continue;
          if (statement.Substring(0, 3) == "set")
          {
            indexSet = j;
            string tmp2 = tmp.Substring(indexQuestionMark + 1);
            indexSemiColon = SmartIndexOf(tmp2, ";");   //tmp2.IndexOf(";");
            if (indexSemiColon == -1)
            {
              Console.Write("Error:  [ProcessingQuestionMark] ';' is absent");
              return "";
            }
            //statement += tmp.Substring(indexQuestionMark, indexSemiColon + 2);
            statement = tmp.Substring(indexSet, indexQuestionMark + indexSemiColon - indexSet + 2);
            string tmp3 = CreateIfBlock(statement);
            output = output.Replace(statement, tmp3);
            tmp = tmp.Substring(indexQuestionMark + indexSemiColon + 2);
            break;
          }
          if (j == -1)
            break;
          j--;
        }
      }
      return output;
    }
    //====================================
    static string CreateIfBlock(string statement)
    {
      string output = "";
      string tmp = statement.Substring(4);
      string[] comparisonOps = new string[] { "==", "!=", "<=", ">=", ">", "<" };
      int indexComparisonOps = -1;
      foreach (string comparisonOp in comparisonOps)
      {
        indexComparisonOps = SmartIndexOf(tmp, comparisonOp);    //tmp.IndexOf(comparisonOp);
        {
          if (indexComparisonOps != -1)
            break;
        }
      }
      if (indexComparisonOps == -1)
      {
        Console.WriteLine("error: comparison op is absent");
        return "";
      }
      int indexEqual = SmartIndexOf(tmp, "=");   //tmp.IndexOf("=");
      if (indexEqual == indexComparisonOps)
      {
        Console.Write("Error:  [ProcessingQuestionMark.CreateIfBlock]  '=' is absent");
        return "";
      }
      string name = tmp.Substring(0, indexEqual - 1);
      int indexQuestionMark = SmartIndexOf(tmp, "?");   //tmp.IndexOf("?");
      string condition = tmp.Substring(indexEqual + 1, indexQuestionMark - indexEqual - 1);
      int indexColon = SmartIndexOf(tmp, ":");   //tmp.IndexOf(":");
      if (indexColon == -1)
      {
        Console.Write("Error:  [ProcessingQuestionMark.CreateIfBlock] ':' is absent");
        return "";
      }
      string consequent = tmp.Substring(indexQuestionMark + 1, indexColon - indexQuestionMark - 1);
      int indexSemiColon = SmartIndexOf(tmp, ";");   //tmp.IndexOf(";");
      string alternative = tmp.Substring(indexColon + 1, indexSemiColon - indexColon - 1);
      output = "if(" + condition.Trim() + ")" + Environment.NewLine;
      output += "{" + Environment.NewLine;
      output += "   set " + name.Trim() + " = " + consequent.Trim() + ";" + Environment.NewLine;
      output += "}" + Environment.NewLine;
      output += "else" + Environment.NewLine;
      output += "{" + Environment.NewLine;
      output += "   set " + name.Trim() + " = " + alternative.Trim() + ";" + Environment.NewLine;
      output += "}" + Environment.NewLine;
      return output;
    }
    //=====================================
    /*
    static string SmartReplace(string input, string src, string dst, bool oneTimeReplace = false)
    {
      char[] array = input.ToCharArray();
      StringBuilder sb = new StringBuilder();
      string result = "";
      bool inQuotes = false;
      char ch;
      bool Flag = false;
      for (int j = 0; j < array.Length; j++)
      {
        ch = array[j];
        if (ch == '\"')
        {
          inQuotes = !inQuotes;
          sb.Append(ch);
          continue;
        }
        if ((inQuotes) && (ch == '\\') && (array[j + 1] == '\"'))
        {
          sb.Append(ch);
          sb.Append(array[j + 1]);
          j++;
          continue;
        }
        if ((inQuotes) && (ch == '\\') && (array[j + 1] == '\\'))
        {
          sb.Append(ch);
          sb.Append(array[j + 1]);
          j++;
          continue;
        }
        if (!inQuotes)
        {
          if (j + src.Length > input.Length)
          {
            sb.Append(ch);
            continue;
          }
          else
          {
            string tmp = "";
            for (int i = j; i < j + src.Length; i++)
            {
              tmp += array[i].ToString();
            }
            if ((tmp == src) && (Flag == false))
            {
              j += src.Length - 1;
              for (int n = 0; n < dst.Length; n++)
                sb.Append(dst[n]);
              if (oneTimeReplace == true)
              {
                Flag = true;
                continue;
              }
            }
            else
              sb.Append(ch);
            continue;
          }
        }
        sb.Append(ch);
        continue;
      }
      result = sb.ToString();
      return result;
    }
    //=====================================
    static public string ReplaceFirst(string text, string search, string replace)
    {
      int pos = text.IndexOf(search);
      if (pos < 0)
      {
        return text;
      }
      return text.Substring(0, pos) + replace + text.Substring(pos + search.Length);
    }
    */
    //=====================================
    static string[] SmartSplit(string input, char[] separators)
    {
      List<string> list = new();
      if (input.Length == 0)
        return list.ToArray();
      string tmp = input;
      char[] arr = tmp.ToCharArray();
      char ch;
      StringBuilder sb = new StringBuilder();
      bool inquotes = false;
      bool IsChar(char[] arrchar, char ch)
      {
        for (int i = 0; i < arrchar.Length; i++)
        {
          if (arrchar[i] == ch)
          {
            return true;
          }
        }
        return false;
      }
      for (int i = 0; i < arr.Length - 1; i++)
      {
        ch = arr[i];
        if (ch == '\"')
        {
          inquotes ^= true;
          sb.Append(ch);
          continue;
        }
        if (inquotes == true)
        {
          sb.Append(ch);
          if ((ch == '\\') && (arr[i + 1] == '\"'))
          {
            sb.Append(arr[i + 1]);
            i++;
          }
          if ((ch == '\\') && (arr[i + 1] == '\\'))
          {
            sb.Append(arr[i + 1]);
            i++;
          }
          continue;
        }
        else
        {
          if (IsChar(separators, ch))
          {
            list.Add(sb.ToString());
            sb.Clear();
            continue;
          }
          else
          {
            sb.Append(ch);
            continue;
          }
        }
      }
      int last_index = arr.Length - 1;
      ch = arr[last_index];
      if (IsChar(separators, ch) == false)
        sb.Append(ch);
      string t = sb.ToString();
      if (t != "")
        list.Add(t);

      return list.ToArray();
    }
    //=====================================
    static int SmartIndexOf(string input, string src)
    {
      char[] array = input.ToCharArray();
      bool inQuote = false;
      char ch;
      for (int j = 0; j < array.Length; j++)
      {
        ch = array[j];
        if (ch == '\"')
        {
          inQuote = !inQuote;
          continue;
        }
        if ((inQuote) && (ch == '\\') && (array[j + 1] == '\"'))
        {
          j++;
          continue;
        }
        if ((inQuote) && (ch == '\\') && (array[j + 1] == '\\'))
        {
          j++;
          continue;
        }
        if (!inQuote)
        {
          if (j + src.Length > input.Length)
            continue;
          else
          {
            string tmp = "";
            int i = 0;
            for (i = j; i < j + src.Length; i++)
            {
              tmp += array[i].ToString();
            }
            if (tmp == src)
            {
              //return j - tmp.Length + 1;
              return i - tmp.Length;
            }
            continue;
          }
        }
        continue;
      }
      return -1;
    }
    //=====================================
    //=======================================
    // EndBlock - next position after 'end'
    static string GetContents(string input0, char start, char end, ref int EndBlock)
    {
      string input = input0;
      List<string> quotedText = new();
      string qt = "";
      int qtBegin = 0;
      int qtEnd = 0;
      string decorator = ((char)0x2665).ToString(); //0x000F;   //♥ 
      //================================
      if (start == end)
      {
        EndBlock = -2;   // chars 'start' & 'end' are not same characters
        return "";
      }
      char[] arr = input.ToCharArray();
      bool inQuotes = false;
      char c;
      int index = 0;
      // Create quotedText list and replace in input saved quottedText  on numbers in list
      while (true)
      {
        if (index == arr.Length)
          break;
        c = arr[index];
        if (c == '\"')
        {
          if (!inQuotes)
          {
            qt = "";
            qtBegin = index;
          }
          inQuotes ^= true;
          qt += c;
          if (!inQuotes)
          {
            qtEnd = index;
            string src = input.Substring(qtBegin, qtEnd - qtBegin + 1);
            string dst = decorator + quotedText.Count + decorator;
            quotedText.Add(qt);
            input = input.Replace(src, dst);
            arr = input.ToCharArray();
            index = input.IndexOf(dst) + dst.Length;
            continue;
          }
          index++;
          continue;
        }
        if (index < arr.Length - 1)
        {
          if ((c == '\\') && (arr[index + 1] == '\"'))
          {
            qt += c;
            qt += arr[index + 1];
            index += 2;
            continue;
          }
        }
        if (!inQuotes)
        {
          index++;
          continue;
        }
        qt += c;
        index++;
      }
      //=======================
      //   processing text between start and end
      bool inContents = false;
      int counter = 0;
      EndBlock = 0;

      StringBuilder sb = new();
      for (index = 0; index < arr.Length; index++)
      {
        c = arr[index];
        if (inContents)
          sb.Append(c);
        if (c == start)
        {
          if (counter == 0)
            inContents = true;
          counter++;
        }
        if (c == end)
        {
          counter--;
          if (counter == 0)
          {
            sb.Remove(sb.Length - 1, 1);
            break;
          }
        }
      }
      string result = sb.ToString();
      if (result == "")
      {        // ()    empty contents
        EndBlock = index + 1;
        return "";  // no char contents end
      }
      string tmp;
      for (int i = 0; i < quotedText.Count; i++)
      {
        tmp = decorator + i.ToString() + decorator;
        if (result.Contains(tmp))
        {
          result = result.Replace(tmp, quotedText[i]);
        }
      }
      EndBlock = input0.IndexOf(result) + result.Length + 1;

      if ((EndBlock > input0.Length) && (result.Length > 0))
      {
        EndBlock = -1;    // char end is absent
        result = "";
      }
      return result;
    }
  }
}
