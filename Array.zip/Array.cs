/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Collections.Generic;
namespace PPLNS
{
  public class Array : AbstractClass
  {
    //  ppl & help_dict in Abstract Class
    //public PPL ppl;
    //Dictionary<string, string> help_dict = new Dictionary<string, string>();
    public Array(PPL ppl)
    {
      this.ppl = ppl;
    }
    //==========================================================
    public void AddToKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, PPL.OperatorDelegate>();
      keyword_dict.Add("help", FuncHelp);
      keyword_dict.Add("Max",FuncMax);
      keyword_dict.Add("Min",FuncMin);
      keyword_dict.Add("Sum",FuncSum);
      keyword_dict.Add("Mean",FuncMean);
      keyword_dict.Add("Sum2",FuncSum2);
      keyword_dict.Add("Sub2",FuncSub2);
      keyword_dict.Add("Mult2",FuncMult2);
      keyword_dict.Add("Div2",FuncDiv2);
      keyword_dict.Add("Sort", FuncSort);
      keyword_dict.Add("Reverse",FuncReverse);
      keyword_dict.Add("IndexOf",FuncIndexOf);
      keyword_dict.Add("LastIndexOf",FuncLastIndexOf);
     
      help_dict.Add("help","Array.help([name])");
      help_dict.Add("Max","");
      help_dict.Add("Min","");
      help_dict.Add("Sum","");
      help_dict.Add("Mean","");
      help_dict.Add("Sum2","");
      help_dict.Add("Sub2","");
      help_dict.Add("Mult2","");
      help_dict.Add("Div2","");
      help_dict.Add("Sort", "");
      help_dict.Add("Reverse","");
      help_dict.Add("IndexOf","");
      help_dict.Add("LastIndexOf","");
     
      try
      {
        if (ppl.ImportList.ContainsKey("Array") == false)
        {
           foreach (KeyValuePair<string, PPL.OperatorDelegate> pair in keyword_dict)
           {
             ppl.processing.keyword_dict.Add("Array." + pair.Key, pair.Value);
           }
           ppl.ImportList.Add("Array", this);
        }
      }
      catch (Exception io)
      { }
    }
    //==========================================================
    public bool FuncMax(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncMin(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSum(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncMean(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSum2(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSub2(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncMult2(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncDiv2(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="array_name"></param>
    /// <param_name="array_type"></param_name>
    public bool FuncSort(List<string> inp_parameters, ref string result, Composite node = null)
    {
      string[] array_types = { "double","string" };
      string func_name = "FuncSort";
      if (inp_parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong operator format: Array.Sort(\"name\")(type)", new object[] { func_name });
        return false;
      }
      string fullname = inp_parameters[0];
      if (fullname.Contains("Array "))
      {
        ppl.print("Error: [{0}] missing quotes around the name", new object[] { func_name });
        return false;
      }
      string array_type = inp_parameters[1];
      if (System.Array.IndexOf(array_types, array_type) == -1)
      {
        ppl.print("Error: [{0}] wrong type", new object[] { array_type });
        return false;
      }      
      try
      {        
        Composite cc = GetArrayComposite(fullname);
        //====================================================
        int length = cc._children.Count;
        switch (array_type)
        {
          case "double":
            double[] darray = new double[length];
            for (int i = 0; i < length; i++)
              darray[i] = Double.Parse(cc._children[i].value);
            System.Array.Sort(darray);
            for (int i = 0; i < length; i++)
              cc._children[i].value = darray[i].ToString();
            break;
          case "string":
            string[] sarray = new string[length];
            for (int i = 0; i < length; i++)
              sarray[i] = cc._children[i].value;
            System.Array.Sort(sarray);
            for (int i = 0; i < length; i++)
              cc._children[i].value = sarray[i];
            break;
          default:
            break;
        }
      }
      catch (Exception e)
      {
        ppl.print("Error: [{0}] wrong data in array [{1}]", new object[] { func_name, fullname });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncReverse(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncIndexOf(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncLastIndexOf(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    Composite GetArrayComposite(string fullname)
    {
      string func_name = "GetArrayComposite";
      string name = "";
      string nodes = "";
      ppl.processing.SplitNodesName(fullname, ref nodes, ref name);
      Composite path = null;
      bool b = ppl.processing.GetPathAndNameFromGlobalLocal(func_name, fullname, ref path, ref nodes, ref name);
      if (b == false)
      {
        ppl.print("Error: [{0}] wrong name [{1}]", new object[] { func_name, fullname });
        return null;
      }
      Component c = null;
      for (int m = 0; m < path.GetChildren().Count; m++)
      {
        c = path.GetChildren()[m];
        if (c.name == name)
          break;
      }
      if (c == null)
      {
        ppl.print("Error: [{0}] wrong name [{1}]", new object[] { func_name, name });
        return null;
      }
      return(Composite)c;   // node array in Tree
    }
  }
}