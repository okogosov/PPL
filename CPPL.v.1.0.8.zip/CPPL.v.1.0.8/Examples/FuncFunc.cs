using System;
using System.Collections.Generic;
using System.Text;

namespace PPLNS
{
  public partial class Processing
  {
    Composite NodeExecFunction = null;
    //=========================================
    // function (f(n1)(n2)(n3)) (write(+(n1)(n2)(n3) (*(4)(6))))
    public bool FuncCreateFunction(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
        Composite CurrentNode = null;
        if (ppl.CurrentNode.name == "NS")
          CurrentNode = ppl.Functions;
        else
          CurrentNode = ppl.CurrentNode;
        if (node.First() == null)
        {
          ppl.print("Error: [FuncCreateFunction] wrong format, missing ';' at the end of the statement");
          return false;
        }
        Composite Node = ppl.root;
        string func_name = node.First().name;
        if (IsValid(func_name) == false)
        {
          ppl.print("Error: [FuncCreateFunction] wrong symbols in name [{0}]", new object[] { func_name });
          return false;
        }
        string[] tokens = func_name.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);
        string last_func_name = tokens[tokens.Length - 1];
        string path = "";
        if (tokens.Length > 1)
        {
          List<string> names = null;
          Composite ResultNode = null;
          Array.Resize(ref tokens, tokens.Length - 1);
          path = String.Join(".", tokens);
          GetNodeByName(ref Node, tokens, ref names, ref ResultNode);
          if (ResultNode == null)
          {
            ppl.print("Error: [FuncCreateFunction] wrong name [{0}]", new object[] { tokens[0] });
            return false;
          }
          CurrentNode = ResultNode;
        }
        else
        {
          if (CurrentNode.name != "Functions")
          {
            Component c = CurrentNode.GetChildren().Find(item1 => item1.name == tokens[0]);
            if (c == null)
            {
              ppl.print("Error: [FuncCreateFunction] wrong name [{0}]", new object[] { tokens[0] });
              return false;
            }
            CurrentNode = (Composite)c;
          }
        }

        Composite clone = null;
        Composite node_tmp = null;
        ((Composite)node.First()).Clone(ref clone, ref node_tmp);
        clone.value = "function";
        Composite FuncNode = null;
        // save path & name
        if (keyword_dict.ContainsKey(node.First().name) == true)
          keyword_dict.Remove(node.First().name);
        keyword_dict.Add(clone.name, FuncExecFunction);

        // FuncNode only with last_func_name
        FuncNode = ppl.GetFunctionNode(clone.name);
        if (FuncNode != null)
          CurrentNode.Remove(FuncNode);
        clone.name = last_func_name;
        CurrentNode.Add(clone);
      }
      catch (Exception)
      {
        ppl.print("Error: [FuncCreateFunction] wrong function format");
        return false;
      }
      return true;
    }
    //=================================================
    // exec(func()()())
    //====================================================
    public bool FuncExecFunction(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {        
        if (node == null)
        {
          ppl.print("Error: [FuncExecFunction] wrong format, missing ';' at the end of the function");
          return false;
        }
        NodeExecFunction = ppl.GetFunctionNode(node.name);
        if (NodeExecFunction == null)
        {
          ppl.print("Error: [FuncExecFunction] function {0} does not exist", new object[] { node.name });
          return false;
        }
        int counter = ppl.Local_dns.Count;
        string str_scope_node = node.name + '_' + counter.ToString();
        Composite scope_node = new Composite(str_scope_node, "scope Function");
        ppl.Local.Add(scope_node);
        PPL.LocalDataNameStruct local_dns;
        local_dns.scope_node = scope_node;
        local_dns.dns = new List<PPL.DataNameStruct>();
        local_dns.RunFlag = true;
        ppl.Local_dns.Push(local_dns);
        if (ppl.debugppl == "yes")
          ppl.print("Info: Local space for function [{0}] is created", new object[] { local_dns.scope_node.name });

        Composite func_clone = null;
        Composite node_tmp = null;
        // get function copy to run 
        node.value = "function";
        NodeExecFunction.Clone(ref func_clone, ref node_tmp);
        if (node.parent.name == "root")
          func_clone.parent = node;
        else
          func_clone.parent = node.parent;  // node.parent is call node for function

        //=====================================
        Composite path = null;
        string nodes = "";
        string name = "";
       
        
        // bool b = ppl.processing.GetPathAndNameFromGlobalLocal("FuncExecFunction", parameters[0], ref path, ref nodes, ref name);
        //=====================================

        // func_clone.value = "function";   // for using this field in Traversal 
        int NumberFormalParams = 0;
        bool BodyFlag = false;
        foreach (Component c in func_clone.GetChildren())
        {
          if (c.name == "#")     // parentheses block around function body, all stmts in function body must be in ()
          {
            BodyFlag = true;
            break;
          }
          NumberFormalParams++;
        }
        if (BodyFlag == false)
        {
          ppl.print("Error: [FuncExecFunction] not enough () around each stmt  or  function body is empty");
          DeleteLocalData();
          NodeExecFunction = null;
          return false;
        }
        int NumberRealParams = parameters.Count;
        if (NumberRealParams > NumberFormalParams)
        {
          ppl.print("Error: [FuncExecFunction] [{2}] NumberRealParams [{0}] != NumberFormalParams [{1}]",
               new object[] { NumberRealParams, NumberFormalParams, func_clone.name });
          DeleteLocalData();
          NodeExecFunction = null;
          return false;
        }
        // for parameters with value is possible do not set parameters,
        // in this case parameter will be created here
        if (NumberRealParams < NumberFormalParams)
        {
          int number_empty_param = NumberFormalParams - NumberRealParams;
          for (int j = 0; j < number_empty_param; j++)
            parameters.Add("");
        }
          List<KeyValuePair<string,string>> list_formal_params = new  List<KeyValuePair<string, string>>();
        Composite func_body = null;
        foreach (Component c in func_clone.GetChildren())
        {
          if (c is Leaf)
          {
            list_formal_params.Add(new KeyValuePair<string,string>(c.name, c.value));
            continue;
          }
          if (c is Composite)
          {
            func_body = (Composite)c;
            break;
          }
        }   // foreach (Component c in func_clone.GetChildren())
            //  for(int j = 0; j < parameters.Count;j++)
            //     parameters[j] = parameters[j].Trim('\"');
        bool bret = func_body.ChangeFormal_FunctionParametersOnRealParameters(list_formal_params, parameters);
        //======Traversal======
        foreach (Component c in func_body.GetChildren())
        {
          if (ppl.RunScriptFlag == PPL.RUN_SCRIPT.Stop)
            break;
          local_dns = ppl.Local_dns.Peek();
          if (local_dns.RunFlag == false)
            break;
          if (c is Composite cc)
          {
            bool StartFlag = false;
            cc.Traversal(ref StartFlag, this);
          }
        }
        //=====================
        if (result != "")
          node.ChildrenResults.Push(result);
        if (ppl.debugppl == "yes")
        {
          ppl.print("Info: [FuncExecFunction] end of function [{0}]", new object[] { func_clone.name });
        }
      }
      catch (Exception io)
      {
        ppl.print("Error: [FuncExecFunction] wrong format, check ';', '(', ')' ");
        DeleteLocalData();
        NodeExecFunction = null;
        return false;
      }
      DeleteLocalData();
      NodeExecFunction = null;
      return true;
    }
    //====================================================
    // delete the latest LocalDataNameStruct & node with data from Local
    public void DeleteLocalData()
    {
      PPL.LocalDataNameStruct local_dns = ppl.Local_dns.Peek();
      if (ppl.debugppl == "yes")
        ppl.print("Info: Local space for function [{0}] is deleted", new object[] { local_dns.scope_node.name });
      Composite parent = local_dns.scope_node.parent;
      parent.Remove(local_dns.scope_node);
      ppl.Local_dns.Pop();
  }
    //====================================================
    public bool FuncFuncList(List<string> parameters, ref string result, Composite node = null)
    {
      if (parameters.Count != 0)
      {
        ppl.print("Error: [FuncList] wrong cmd, format: funclist");
        return false;
      }
      ppl.print("-----Function List-----");
      string s = "";
      foreach (Component c in ppl.Functions.GetChildren())
      {
        s = c.name + "  (";
        if (c is Composite cc)
        {
          foreach (Component c2 in cc.GetChildren())
          {
            if (c2.name == "#")     // parentheses block around function body
              break;
            s += c2.name;
            s += ", ";
          }
          int index = s.LastIndexOf(", ");
          s = s.Substring(0, index);
          s += ")";
          ppl.print(s);
          continue;
        }
        else
        {
          ppl.print("Error: [FuncFuncList] leaf {0} in functions", new object[] { c.name });
        }
      }
      return true;
    }
  }
}
