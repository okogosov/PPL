// Simplified description of the (part of) the provisional means algorithm
public class MeansXProdIncr // Increment means and cross products for one (vector case of data 
{
    // Local (class) variables
    int nVars;       // number of variables
    int nCases;      // number of cases processed so far
    double[] means;  // array of means
    double[] mxProd; // array of centered cross products (lower triangular part of
                     // the symmetric matrix elements), order of elements
                     // m[0,0], m[1,0], m[1,1], m[2,0], m[2,1], m[2,2], etc.

    // Methods:

    // Initialize and allocate local (class) variables
    void Init( int n ) // n is number of variables
    {
        nVars = n;
        nCases = 0;

        // Allocate array of means
        means = new double[ nVars ];

        // Allocate array of centered cross products of length nVars*(nVars+1)/2
        mxProd = new double[ nVars*(nVars+1)/2 ];
    }

    // Process one case (vector) of data 
    void AddCase( double[] vData )
    {
        // Update number of cases
        nCases++;

        // Update matrix of cross products (see below)
        UpdateXX( vData );

        // Update means
        double ratio = 1.0 / nCases;

        for ( int iVar = 0; iVar < nVars; iVar++ )
        {
            double incr = ( vData[ iVar ] - meansArray[ iVar ] ) * ratio;
            meansArray[ iVar ] += incr;
        }
    }

    // Update the symmetric matrix of centered cross products
    void UpdateXX
    {
        int iX = 0;

        for ( int iRow = 0; iRow < nVars; iRow++ )
        {
            for ( int iCol = 0; iCol <= iRow; iCol++ )
            {
                mxProd[ iX++ ] += vData[ iRow ] * vData[ iCol ];;
            }
        }
    }
}
