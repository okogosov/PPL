﻿/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/

using System;
using System.Diagnostics;
using System.Collections.Generic;
namespace PPLNS
{
  public class Template : AbstractClass
  {
    //  ppl & help_dict in Abstract Class
    //public PPL ppl;
    //Dictionary<string, string> help_dict = new Dictionary<string, string>();
    public Template(PPL ppl)
    {
      this.ppl = ppl;
    }
    //==========================================================
    public void AddToKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, PPL.OperatorDelegate>();
      keyword_dict.Add("help", FuncHelp);
      keyword_dict.Add("sum", FuncSum);
      // add here other methods & their keywords
      //...

      help_dict.Add("sum", "Returns sum of two double-precision floating-point numbers: \r\n\tTemplate.sum(double d1)(double d2)");
      // add here other help
      //...
      try
      {
        foreach (KeyValuePair<string, PPL.OperatorDelegate> pair in keyword_dict)
          ppl.processing.keyword_dict.Add("Template." + pair.Key, pair.Value);
        ppl.ImportList.Add("Template", this);
      }
      catch (Exception io)
      { }
}
    //==========================================================
    //==========================================================
    public bool FuncSum(List<string> parameters, ref string result, Composite node = null)
    {
      result = "";
      string v = "";
      try
      {
        double zd = 0;
        if (parameters.Count == 0)
        {
          ppl.print("Error: FuncSum number of parameters = 0");
          return false;
        }
        foreach (string s in parameters)
        {
          v = s;
          zd += Double.Parse(s);
        }
        result = zd.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: Sum not digital value {0}", new object[] { v });
        return false;
      }
      return true;
    }
  }
}

