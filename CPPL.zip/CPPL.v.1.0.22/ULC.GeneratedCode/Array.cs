/***************************************************************
*This code generated with Application ULC.exe                  *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Collections.Generic;
namespace PPLNS
{
  public class Array : AbstractClass
  {
    //  ppl & help_dict in Abstract Class
    //public PPL ppl;
    //Dictionary<string, string> help_dict = new Dictionary<string, string>();
    public Array(PPL ppl)
    {
      this.ppl = ppl;
    }
    //==========================================================
    public void AddToKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, PPL.OperatorDelegate>();
      keyword_dict.Add("help", FuncHelp);
      keyword_dict.Add("Max",FuncMax);
      keyword_dict.Add("Min",FuncMin);
      keyword_dict.Add("Sum",FuncSum);
      keyword_dict.Add("Average",FuncAverage);
      keyword_dict.Add("Sum2",FuncSum2);
      keyword_dict.Add("Sub2",FuncSub2);
      keyword_dict.Add("Mult2",FuncMult2);
      keyword_dict.Add("Div2",FuncDiv2);
      keyword_dict.Add("Sort",FuncSort);
      keyword_dict.Add("Reverse",FuncReverse);
      keyword_dict.Add("IndexOf",FuncIndexOf);
      keyword_dict.Add("LastIndexOf",FuncLastIndexOf);
     
      help_dict.Add("help","Array.help([name])");
      help_dict.Add("Max","");
      help_dict.Add("Min","");
      help_dict.Add("Sum","");
      help_dict.Add("Average","");
      help_dict.Add("Sum2","");
      help_dict.Add("Sub2","");
      help_dict.Add("Mult2","");
      help_dict.Add("Div2","");
      help_dict.Add("Sort","");
      help_dict.Add("Reverse","");
      help_dict.Add("IndexOf","");
      help_dict.Add("LastIndexOf","");
     
      try
      {
        if (ppl.ImportList.ContainsKey("Array") == false)
        {
           foreach (KeyValuePair<string, PPL.OperatorDelegate> pair in keyword_dict)
           {
             ppl.processing.keyword_dict.Add("Array." + pair.Key, pair.Value);
           }
           ppl.ImportList.Add("Array", this);
        }
      }
      catch (Exception io)
      { }
    }
    //==========================================================
    public bool FuncMax(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncMin(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSum(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncAverage(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSum2(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSub2(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncMult2(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncDiv2(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSort(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncReverse(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncIndexOf(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncLastIndexOf(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
  }
}