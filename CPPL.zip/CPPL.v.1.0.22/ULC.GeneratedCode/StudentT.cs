/***************************************************************
*This code generated with Application ULC.exe                  *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Collections.Generic;
namespace PPLNS
{
  //============================================================
  public class PPL_StudentT
  {
    PPL ppl = null;
    public PPL_StudentT(PPL ppl)
    {
      this.ppl = ppl;
    }
    //============================================================
    public bool FuncStudentT(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_StudentT.FuncStudentT";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_StudentT.FuncCDF";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncInvCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_StudentT.FuncInvCDF";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
  }
}
