/***************************************************************
*This code generated with Application ULC.exe                  *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Collections.Generic;
namespace PPLNS
{
  //============================================================
  public class PPL_Normal
  {
    PPL ppl = null;
    public PPL_Normal(PPL ppl)
    {
      this.ppl = ppl;
    }
    //============================================================
    public bool FuncNormal(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncNormal";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncCDF";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncEstimate(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncEstimate";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncInvCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncInvCDF";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncIsValidParameterSet(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncIsValidParameterSet";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncPDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncPDF";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncPDFLn(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncPDFLn";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncSample(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncSample";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncSamples(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncSamples";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncWithMeanPrecision(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncWithMeanPrecision";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncWithMeanStdDev(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncWithMeanStdDev";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncWithMeanVariance(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncWithMeanVariance";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncCumulativeDistribution(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncCumulativeDistribution";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncDensity(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncDensity";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncDensityLn(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncDensityLn";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncEquals(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncEquals";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncGetHashcode(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncGetHashcode";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncGetType(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncGetType";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncInverseCumulaiveDistribution(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncInverseCumulaiveDistribution";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncToString(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncToString";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncEntropy(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncEntropy";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncMaximum(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncMaximum";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncMean(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncMean";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncMedian(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncMedian";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncMinimum(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncMinimum";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncMode(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncMode";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncPrecision(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncPrecision";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncRandomSource(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncRandomSource";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncSkeness(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncSkeness";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncStdDev(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncStdDev";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncVariance(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncVariance";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
  }
}
