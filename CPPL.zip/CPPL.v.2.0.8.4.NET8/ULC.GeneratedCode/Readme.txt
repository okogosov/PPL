Utility ulc.exe  creates code  for User’s DLL .
ulc.exe [config_file.json]
     by default name of config file - ConfigULC.json
Examples:
1.	creation code without classes:
ulc.exe ConfigULC.Array.json

	File ConfigULC.Array.json:
{
    "name":"Array",
    "path":"",
       "functions":
       [
        "Max",
        "Min",
        "Sum",
        …
       ]
}
Utility ulc.exe generates 2 files:
-	Array.cs , this file must be added to user’s dll project 
-	Array.json , this file must be added to directory  JsonHelp ( for Assistant.exe).

 

2.	creation code with classes:
ulc.exe ConfigULC.json
      File ConfigULC.json:
{
    "name":"Distributions",
    "path":"",
    "ulc_classes": [
     {"name":"Normal",
       "functions":
       [
        "Normal",
        "CDF",
        "Estimate",
        "InvCDF"
       ]
     },
     {"name":"StudentT",
      "functions": 
      [
        "StudentT",
        "CDF",
        "InvCDF" 
      ]        
     },
     {"name":"ChiSquared",
     "functions":
      [
        "ChiSquared",
        "CDF",
        "InvCDF" 
      ]        
     }
   ]
}
Utility ulc.exe generates  files:
-	Distributions.cs  	- must be added to user’s dll project 
-	Normal.cs 		- must be added to user’s dll project 
-	StudentT.cs 		- must be added to user’s dll project
-	ChiSquared.cs 	- must be added to user’s dll project 
-	Distributions.json 	- must be added to directory  JsonHelp ( for Assistant.exe).
