﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using Newtonsoft.Json;

namespace ULC
{
  public struct ULC_Class
  {
    public string name;
    public string[] functions;
  }
  public struct Config
  {
    public string name;
    public string path;
    public ULC_Class[] ulc_classes;
  }
  public struct Functions
  {
     public string name;
     public string[] parameters;
  }
  public struct ConfigWithoutClasses
  {
    public string name;
    public string path;
    public Functions[] functions;
  }
  partial class ULC
  { 
    static void Main(string[] args)
    {
      if(args.Length == 0)
        ReadConfig("ConfigULC.json");
      else
        ReadConfig(args[0]);
    }
    //================================================
    static public bool ReadConfig(string filename)
    {
      string curDir = Environment.CurrentDirectory + "\\";
      string filenameConfig = curDir + filename;
      try
      {
        #region  create json
        /*Config config = new Config();
        config.name = "Distrib";
        config.path = "";
        config.ulc_classes = new ULC_Class[2];
        ULC_Class cls;
        cls.name = "Normal";
        cls.functions = new string[]  {"Normal", "CDF","InvCDF" };
        config.ulc_classes[0] = cls;

        ULC_Class cls2;
        cls2.name = "StudentT";
        cls2.functions = new string[] { "Normal", "CDF", "InvCDF" };
        config.ulc_classes[1] = cls2;

        string jsonConfig  = JsonConvert.SerializeObject(config,Formatting.Indented);
        */
        #endregion

        if (File.Exists(filenameConfig) == false)
         {
           Console.WriteLine("Error: [ReadPatternsFromFile] file [{0}] not found", filename );
           return false;
         }
         string jsonConfig = File.ReadAllText(filenameConfig);
        if (jsonConfig.Contains("ulc_classes") == false)
        {
          ConfigWithoutClasses config = JsonConvert.DeserializeObject<ConfigWithoutClasses>(jsonConfig);
          if (CreateCodeWithoutClasses(config) == false)  // includes JsonHelp 
            Environment.Exit(0);
        }
        else
        {
          Config config = JsonConvert.DeserializeObject<Config>(jsonConfig);
          for (int i = 0; i < config.ulc_classes.Length; i++)
          {
            Console.WriteLine("{0}", config.ulc_classes[i].name);
            for (int j = 0; j < config.ulc_classes[i].functions.Length; j++)
              Console.WriteLine("  {0}", config.ulc_classes[i].functions[j]);
          }
          if(CreateMainClassCode(config) == false)
            Environment.Exit(0);
          CreateInternalClassesCode(config);
          CreateJsonHelp(config);
        }
        Console.WriteLine("Press any button for exit");
        Console.ReadKey();
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error: [ReadConfig] errors in file [{0}]  {1}", filename, ex.Message );
        return false;
      }
      return true;
    } 
  }
}
