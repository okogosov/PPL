/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Collections.Generic;
namespace PPLNS
{
  public class DataFrame : AbstractClass
  {
    //  ppl & help_dict in Abstract Class
    //public PPL ppl;
    //Dictionary<string, string> help_dict = new Dictionary<string, string>();
    public DataFrame(PPL ppl)
    {
      this.ppl = ppl;
    }
    //==========================================================
    public void AddToKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, PPL.OperatorDelegate>();
      keyword_dict.Add("help", FuncHelp);
      keyword_dict.Add("Create",FuncCreate);
      keyword_dict.Add("SetRow",FuncSetRow);
      keyword_dict.Add("SetColumn",FuncSetColumn);
      keyword_dict.Add("Write",FuncWrite);
      keyword_dict.Add("Save",FuncSave);
      keyword_dict.Add("Read",FuncRead);
      keyword_dict.Add("InsertRows",FuncInsertRows);
      keyword_dict.Add("AddRows",FuncAddRows);
      keyword_dict.Add("InsertColumns",FuncInsertColumns);
      keyword_dict.Add("AddColumns",FuncAddColumns);
      keyword_dict.Add("RemoveRows",FuncRemoveRows);
      keyword_dict.Add("RemoveColumns",FuncRemoveColumns);
      keyword_dict.Add("ClearColumns",FuncClearColumns);
      keyword_dict.Add("SetWidthForAll",FuncSetWidthForAll);
      keyword_dict.Add("Sort",FuncSort);
      keyword_dict.Add("Reverse",FuncReverse);
      keyword_dict.Add("SelectRows",FuncSelectRows);
      keyword_dict.Add("UnSelectRows",FuncUnSelectRows);
     
      help_dict.Add("help","DataFrame.help([name])");
      help_dict.Add("Create","");
      help_dict.Add("SetRow","");
      help_dict.Add("SetColumn","");
      help_dict.Add("Write","");
      help_dict.Add("Save","");
      help_dict.Add("Read","");
      help_dict.Add("InsertRows","");
      help_dict.Add("AddRows","");
      help_dict.Add("InsertColumns","");
      help_dict.Add("AddColumns","");
      help_dict.Add("RemoveRows","");
      help_dict.Add("RemoveColumns","");
      help_dict.Add("ClearColumns","");
      help_dict.Add("SetWidthForAll","");
      help_dict.Add("Sort","");
      help_dict.Add("Reverse","");
      help_dict.Add("SelectRows","");
      help_dict.Add("UnSelectRows","");
     
      try
      {
        if (ppl.ImportList.ContainsKey("DataFrame") == false)
        {
           foreach (KeyValuePair<string, PPL.OperatorDelegate> pair in keyword_dict)
           {
             ppl.processing.keyword_dict.Add("DataFrame." + pair.Key, pair.Value);
           }
           ppl.ImportList.Add("DataFrame", this);
        }
      }
      catch (Exception io)
      { }
    }
    //==========================================================
    public bool FuncCreate(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSetRow(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSetColumn(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncWrite(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSave(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncRead(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncInsertRows(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncAddRows(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncInsertColumns(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncAddColumns(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncRemoveRows(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncRemoveColumns(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncClearColumns(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSetWidthForAll(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSort(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncReverse(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSelectRows(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncUnSelectRows(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
  }
}