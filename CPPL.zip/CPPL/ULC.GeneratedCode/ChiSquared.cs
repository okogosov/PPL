/***************************************************************
*This code generated with Application ULC.exe                  *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Collections.Generic;
namespace PPLNS
{
  //============================================================
  public class PPL_ChiSquared
  {
    PPL ppl = null;
    public PPL_ChiSquared(PPL ppl)
    {
      this.ppl = ppl;
    }
    //============================================================
    public bool FuncChiSquared(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_ChiSquared.FuncChiSquared";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_ChiSquared.FuncCDF";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncInvCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_ChiSquared.FuncInvCDF";
       try
       {
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
  }
}
