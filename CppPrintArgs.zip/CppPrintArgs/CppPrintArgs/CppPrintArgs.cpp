// C# format for Console.WriteLine for C++ cout
// I do not variadic functions, due to an unpredictable error in case
// when braces counter in format > real number of args (see error 3 below)

#include <iostream>
#include <string>
#include <cstdarg>
#include <stdio.h>
#include <vector>

using namespace std;
struct FORMAT_POSITION
{
public:
  int start = 0;
  int end = 0;
  int position = 0;
  string frmt = "";
  string aligment = "";
};
//================================================================
bool isAllDigits(const string& str)
{
  return str.find_first_not_of("-0123456789") == string::npos;
}
//=====================================================
// Composite formatting:    {numbered placeholder[,alignment]}
// string interpolation does ot supported
// error: 0 - ok
//        1 - wrong number of braces, error
//        2 - position < 0, error
//        3 - number of args < number of position in format, error 
//        4 - number of args > number of position in format, not error
//        5 - placeholder not digit
//        6 - alignment not digit
// example c# format: '{2}' => c++ format '%3$s'
int printArgs(vector<string> args)
{
  if (args.size() == 0)
  {
    cout << endl;
    return 0;
  }
  vector<FORMAT_POSITION> fpVector;
  string frmtCopy = args[0];
  bool nBraces = false;
  FORMAT_POSITION fp;
  string betweenBraces = "";
  int bracesCount = 0;
  for (int i = 0; i < frmtCopy.size(); i++)
  {
    if (frmtCopy[i] == '{')
    {
      if (betweenBraces != "")
      {
        FORMAT_POSITION fp1;
        fp1.frmt = betweenBraces;
        fpVector.push_back(fp1);
        betweenBraces = "";
      }
      nBraces = true;
      fp.start = i;
      continue;
    }
    if (frmtCopy[i] == '}')
    {
      betweenBraces = "";
      nBraces = false;
      string contents = frmtCopy.substr(fp.start, i - fp.start + 1);
      string tmp = contents.substr(1, contents.size() - 2);

      int indexComma = (int)tmp.find(",");
      string token1 = "";
      string token2 = "";
      if (indexComma == string::npos)
      {
        token1 = tmp;
      }
      else
      {
        token1 = tmp.substr(0, indexComma);
        token2 = tmp.substr(indexComma + 1);
      }
      if (isAllDigits(token1) == false)
        return 5;
      int n = atoi(token1.c_str());
      if (n < 0)
        return 2;
      n++;
      tmp = "%" + to_string(n) + "$s";
      fp.end = (int)frmtCopy.find(contents, 0);
      fp.frmt = tmp;
      fp.aligment = token2;
      fp.position = n - 1;
      fpVector.push_back(fp);
      bracesCount++;
      continue;
    }
    betweenBraces += frmtCopy[i];
  }
  if (nBraces == true)
    return 1;

  if (betweenBraces != "")
  {
    FORMAT_POSITION fp2;
    fp2.frmt = betweenBraces;
    fpVector.push_back(fp2);
  }
  int argsSize = (int)args.size();
  if (bracesCount > (argsSize - 1))
    return 3;
  int iresult = 0;
  if (bracesCount < (argsSize - 1))
    iresult = 4;
  string tmp = "";
  string value = "";
  int position;
  for (int i = 0; i < (int)fpVector.size(); i++)
  {
    if (fpVector.at(i).frmt[0] != '%')
    {
      tmp += fpVector.at(i).frmt;
      continue;
    }
    if (fpVector.at(i).aligment == "")
    {
      position = fpVector.at(i).position;
      value = args.at(position + 1);
    }
    else
    {
      if (isAllDigits(fpVector.at(i).aligment) == false)
        return 6;
      int ialigment = atoi(fpVector.at(i).aligment.c_str());
      string tmp2 = "";
      string tmp3 = "";
      for (int i = 0; i < abs(ialigment); i++)      tmp2 += " ";
      if (ialigment < 0)
      {
        position = fpVector.at(i).position;
        value = args.at(position + 1);
        tmp3 = value.substr(0, abs(ialigment));
        tmp2.replace(0, tmp3.size(), (const char*)(tmp3.c_str()));
        value = tmp2;
      }
      else
      {
        position = fpVector.at(i).position;
        value = args.at(position + 1);
        tmp3 = value.substr(0, abs(ialigment));
        tmp2.replace(tmp2.size() - tmp3.size(), tmp3.size(), (const char*)(tmp3.c_str()));
        value = tmp2;
      }
    }
    tmp += value;
  }
  cout << tmp;
  return iresult;
}
//=====================================================
int main()
{
  int ires = printArgs({ "={0,-5}=\r\n", "1234" });
  cout << "Return: " << ires << endl;    // = 0

  printArgs({ "={0,5}=\r\n", "1234" });
  ires = printArgs({ "={0,-5}=\r\n", "1234" });

  // Test Errors
  ires = printArgs({ "={a,-5}=\r\n", "1234" });
  cout << "Return: error " << ires << endl;    // = 5

  ires = printArgs({ "={0,-s}=\r\n", "1234" });
  cout << "Return: error  " << ires << endl;    // = 6

  // Length of data > alignment 
  printArgs({ "={0,-5}=\r\n", "123456" });
  printArgs({ "={0,5}=\r\n", "123456" });
  //Numbered placeolders in format test
  printArgs({ "First: {2} Second: {1} Third: {0} \r\nEnd\r\n", "1", "2", "3" });
  printArgs({ "First: {0} Second: {1} Third: {2} \r\nEnd\r\n", "1", "2", "3" });

  // arg."4" rejected in accordance with format, it is not error
  ires = printArgs({ "First: {0} Second: {1} Third: {2} \r\nEnd\r\n", "1", "2", "3", "4" });
  cout << "Return: " << ires << endl;   // = 4

  // Test Error
  //numbered placeholder is not exist, error
  ires = printArgs({ "First: {0} Second: {1} Third: {2} \r\nEnd\r\n", "1", "2" });
  cout << "Return: error " << ires << endl;                 // = 3
}

/*
=1234 =
Return: 0
= 1234=
=1234 =
Return: error 5
Return: error  6
=12345=
=12345=
First: 3 Second: 2 Third: 1
End
First: 1 Second: 2 Third: 3
End
First: 1 Second: 2 Third: 3
End
Return: 4
Return: error 3
*/
