/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Collections.Generic;
namespace PPLNS
{
  public class Test : AbstractClass
  {
    //  ppl & help_dict in Abstract Class
    //public PPL ppl;
    //Dictionary<string, string> help_dict = new Dictionary<string, string>();
    public Test(PPL ppl)
    {
      this.ppl = ppl;
    }
    //==========================================================
    public void AddToKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, PPL.OperatorDelegate>();
      keyword_dict.Add("help", FuncHelp);
      keyword_dict.Add("Sum",FuncSum);
      keyword_dict.Add("Sub",FuncSub);
      keyword_dict.Add("Mult",FuncMult);
      keyword_dict.Add("Div",FuncDiv);
     
      help_dict.Add("Sum","");
      help_dict.Add("Sub","");
      help_dict.Add("Mult","");
      help_dict.Add("Div","");
     
      try
      {
        if (ppl.ImportList.ContainsKey("Test") == false)
        {
           foreach (KeyValuePair<string, PPL.OperatorDelegate> pair in keyword_dict)
           {
             ppl.processing.keyword_dict.Add("Test." + pair.Key, pair.Value);
           }
           ppl.ImportList.Add("Test", this);
        }
      }
      catch (Exception io)
      { }
    }
    //==========================================================
    public bool FuncSum(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSub(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncMult(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncDiv(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {
              
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
  }
}