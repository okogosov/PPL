﻿/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Text;

namespace PPLNS
{
  public partial class DataFrame : AbstractClass
  {   
    /// <summary>
    /// 
    /// </summary>
    /// <param name="DataFrame name"></param>
    /// <param name="filename.csv|data"></param>
    /// <param name="list of selected columns"></param>
    /// <returns></returns>
    public bool FuncRead(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncRead";
      try
      {
        if (parameters.Count < 1)
        {
          ppl.print(
            "Error: [{0}] wrong parameter, format: DataFrame.Read [(DataFrame name)](filename.csv|data)[(column_name1)(column_name2)...]",
             new object[] { func_name });
          return false;
        }
        string df_name = "";
        string filename = "";
        if (parameters.Count == 1)
          filename = parameters[0];
        else
        {
          df_name = parameters[0];
          filename = parameters[1];
        }
        string extension = filename.Substring(filename.Length - 4);
        if ( (extension == ".csv") && (parameters.Count == 1) )
        {
          ppl.print(
            "Error: [{0}] wrong parameter, format: DataFrame.Read [(DataFrame name)](filename.csv|data)[(column_name1)(column_name2)...]",
             new object[] { func_name });
          return false;
        }
        if ((extension == "data") && (parameters.Count == 1))
        {
           string tmp_return = "";
           ppl.processing.FuncReadData(new List<string>() { filename }, ref tmp_return, node);
           return true;
        }
          //=========================================================
          Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        TypeWidth[] arr_type_width = CreateTypeWidthArray(comp_df, comp_settings);
        int columns_quantity = comp_df._children.Count;

        //====================================================
        string output = "     ";
        string[] columns_selected = null;
        if (parameters.Count > 2)
        {
          columns_selected = new string[parameters.Count - 2];
          for (int i = 2; i < parameters.Count; i++)
            columns_selected[i - 2] = parameters[i];
        }
        //=========================================================
        string strLength = GetSettingsValue(comp_settings, "RowsLength");

        // string Key = GetSettingsValue(comp_settings, "Key");
        int Length = int.Parse(strLength);
        //=============Test column names================
        if (columns_selected != null)
        {
          foreach (string cw in columns_selected)
          {
            bool b2 = false;
            for (int i = 0; i < columns_quantity; i++)
            {
              if (comp_df._children[i].name == cw)
              {
                b2 = true;
                break;
              }
            }
            if (b2 == false)
            {
              ppl.print("Error: [{0}] wrong column name [{1}]", new object[] { func_name, cw });
              return false;
            }
          }
        }
        //=====get RowSelectedFrom & RowSelectedTo===================================
        string strRowSelectedFrom = "";
        int RowSelectedFrom = 0;
        string strRowSelectedTo = "";
        int RowSelectedTo = 0;
        bool b = false;
        if (strRowSelectedFrom != "")
        {
          b = int.TryParse(strRowSelectedFrom, out RowSelectedFrom);
          if (b == false)
          {
            ppl.print("Error: [{0}] not digital  RowSelectedFrom [{1}])", new object[] { func_name, strRowSelectedFrom });
            return false;
          }
        }
        if (strRowSelectedTo != "")
        {
          b = int.TryParse(strRowSelectedTo, out RowSelectedTo);
          if (b == false)
          {
            ppl.print("Error: [{0}] not digital  RowSelectedTo [{1}])", new object[] { func_name, strRowSelectedTo });
            return false;
          }
        } 
        if(System.IO.File.Exists(filename) == false)
        {
          ppl.print("Error: [{0}] file [{1}] is absent)", new object[] { func_name, filename });
          return false;
        }
        //=========================================================
        int real_lines = 0;
        switch (extension)
        {
          case ".csv":
            string[] arr_lines = System.IO.File.ReadAllLines(filename);
            if (arr_lines.Length > Length)
            {
              string add_result = "";
              int delta = arr_lines.Length - Length;
              FuncAddRows(new List<string>() { df_name, delta.ToString() }, ref add_result, node);
              Length = arr_lines.Length;
            }
            real_lines = Length = arr_lines.Length;
            //=====get RowSelectedFrom & RowSelectedTo===================================
            strRowSelectedFrom = GetSettingsValue(comp_settings, "RowSelectedFrom");
            strRowSelectedTo = GetSettingsValue(comp_settings, "RowSelectedTo");
            RowSelectedTo = real_lines - 1; //Length - 1;
            if (strRowSelectedFrom != "")
            {
              b = int.TryParse(strRowSelectedFrom, out RowSelectedFrom);
              if (b == false)
              {
                ppl.print("Error: [{0}] not digital  RowSelectedFrom [{1}])", new object[] { func_name, strRowSelectedFrom });
                return false;
              }
            }
            if (strRowSelectedTo != "")
            {
              b = int.TryParse(strRowSelectedTo, out RowSelectedTo);
              if (b == false)
              {
                ppl.print("Error: [{0}] not digital  RowSelectedTo [{1}])", new object[] { func_name, strRowSelectedTo });
                return false;
              }
            }
            if(RowSelectedTo > real_lines)
            {
              ppl.print("Error: [{0}] RowSelectedTo [{1}] > real_lines [{2])", new object[] { func_name, strRowSelectedTo });
              return false;
            }
            //=========================================================
            int column_index = 0;
            for (int j = RowSelectedFrom; j <= RowSelectedTo; j++)
            {
              string[] cells = SplitCsv(arr_lines[j], ',');
              int col_num = cells.Length;
              for (int i = 0; i < col_num; i++)  // first - Settings
              {
                column_index = i + 1;
                if (columns_selected != null)
                {
                  string selected_name = columns_selected[i];
                  column_index = GetColumnIndex(comp_df, selected_name);
                }
                if (arr_type_width[column_index - 1].Type == "Text")
                {
                  ((Composite)comp_df._children[column_index])._children[j].value = cells[i];
                  continue;
                }
                if (arr_type_width[column_index - 1].Type == "Number")
                {
                  double d = 0;
                  bool b2 = double.TryParse(cells[i], out d);
                  if (b2)
                    ((Composite)comp_df._children[column_index ])._children[j].value = cells[i];
                  else
                    ((Composite)comp_df._children[column_index ])._children[j].value = "*error";
                  continue;
                }
                //if (arr_type_width[i - k].Type == "Date") { }
                else
                {
                  ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
                  return false;
                }

              }
            }
            break;
          /*case "":
            {
  
            }*/
            break;
          default:
            break;
        }
        return true;
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
  }
}
