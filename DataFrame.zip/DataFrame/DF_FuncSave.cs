﻿/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Text;

namespace PPLNS
{
  public partial class DataFrame : AbstractClass
  {
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="DataFrame name"></param>
    /// <param name="filename.csv|data"></param>
    /// <param name="list of selected columns"></param>
    /// <returns></returns>
    public bool FuncSave(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncSave";
      try
      {
        if (parameters.Count < 2)
        {
          ppl.print("Error: [{0}] wrong parameter, format: DataFrame.Save (DataFrame name)(filename.csv|data)[(column name1)(column name2)...]",
             new object[] { func_name });
          return false;
        }
        string df_name = parameters[0];
        string filename = parameters[1];
        string extension = filename.Substring(filename.Length - 4);
        //=========================================================
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        //TypeWidth[] arr_type_width = CreateTypeWidthArray( comp_df,  comp_settings);
        int columns_quantity = comp_df._children.Count;
        //====================================================
        string output = "     ";
        string[] columns_selected = null;
        if (parameters.Count > 2)
        {
          columns_selected = new string[parameters.Count - 2];
          for (int i = 2; i < parameters.Count; i++)
            columns_selected[i - 2] = parameters[i];
        }
        //=============Test column names================
        if (columns_selected != null)
        {
          foreach (string cw in columns_selected)
          {
            bool b2 = false;
            for (int i = 0; i < columns_quantity; i++)
            {
              if (comp_df._children[i].name == cw)
              {
                b2 = true;
                break;
              }
            }
            if (b2 == false)
            {
              ppl.print("Error: [{0}] wrong column name [{1}]", new object[] { func_name, cw });
              return false;
            }
          }
        }
        string strLength = GetSettingsValue(comp_settings, "RowsLength");

        // string Key = GetSettingsValue(comp_settings, "Key");
        int length = int.Parse(strLength);
        output = "";
        //=====get RowSelectedFrom & RowSelectedTo===================================
        string strRowSelectedFrom = "";
        int RowSelectedFrom = 0;
        string strRowSelectedTo = "";
        int RowSelectedTo = 0;
        bool b = false;
        if (strRowSelectedFrom != "")
        {
          b = int.TryParse(strRowSelectedFrom, out RowSelectedFrom);
          if (b == false)
          {
            ppl.print("Error: [{0}] not digital  RowSelectedFrom [{1}])", new object[] { func_name, strRowSelectedFrom });
            return false;
          }
        }
        if (strRowSelectedTo != "")
        {
          b = int.TryParse(strRowSelectedTo, out RowSelectedTo);
          if (b == false)
          {
            ppl.print("Error: [{0}] not digital  RowSelectedTo [{1}])", new object[] { func_name, strRowSelectedTo });
            return false;
          }
        }
        //=========================================================
        switch (extension)
        {
          case ".csv":
            int real_lines = length;
            //=====get RowSelectedFrom & RowSelectedTo===================================
            strRowSelectedFrom = GetSettingsValue(comp_settings, "RowSelectedFrom");
            strRowSelectedTo = GetSettingsValue(comp_settings, "RowSelectedTo");
            RowSelectedTo = length - 1;
            if (strRowSelectedFrom != "")
            {
              b = int.TryParse(strRowSelectedFrom, out RowSelectedFrom);
              if (b == false)
              {
                ppl.print("Error: [{0}] not digital  RowSelectedFrom [{1}])", new object[] { func_name, strRowSelectedFrom });
                return false;
              }
            }
            if (strRowSelectedTo != "")
            {
              b = int.TryParse(strRowSelectedTo, out RowSelectedTo);
              if (b == false)
              {
                ppl.print("Error: [{0}] not digital  RowSelectedTo [{1}])", new object[] { func_name, strRowSelectedTo });
                return false;
              }
            }
            //=========================================================
            for (int j = RowSelectedFrom; j <= RowSelectedTo; j++)
            {
              int col_num = columns_quantity;
              for (int i = 1; i < col_num; i++)  // first - Settings
              {
                if (columns_selected != null)
                {
                  if (columns_selected.Contains(comp_df._children[i].name) == false)
                    continue;
                }
                output += ((Composite)comp_df._children[i])._children[j].value;
                output += ",";
              }
              output = output.Remove(output.Length - 1);
              output += Environment.NewLine;
            }
            System.IO.File.WriteAllText(filename, output);
            break;
          case "data":
            {
              string tmp_return = "";
              ppl.processing.FuncSaveData(new List<string>() { filename,df_name},ref tmp_return, node);
            }
            break;
          default:
            break;
        }
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
  }
}
