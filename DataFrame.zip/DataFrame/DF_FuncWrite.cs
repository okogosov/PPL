﻿/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Text;

namespace PPLNS
{
  public partial class DataFrame : AbstractClass
  {
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="DataFrame"></param>
    /// <param name="list of selected columns"></param>
    /// <returns></returns>
    public bool FuncWrite(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncWrite";
      try
      {
        if (parameters.Count == 0)
        {
          parameters.Add("DF");
        }
          string df_name = parameters[0];
        //====================================================
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        TypeWidth[] arr_type_width = CreateTypeWidthArray(comp_df, comp_settings);
        int columns_quantity = comp_df._children.Count;
        string strLength = GetSettingsValue(comp_settings, "RowsLength");
        int Length = int.Parse(strLength);
        //====================================================
        string output = "     ";
        string[] columns_selected = null;
        if (parameters.Count > 1)
        {
          columns_selected = new string[parameters.Count - 1];
          for (int i = 1; i < parameters.Count; i++)
            columns_selected[i - 1] = parameters[i];
        }
        //=============Test column names================
        if (columns_selected != null)
        {
          foreach (string cw in columns_selected)
          {
            bool b2 = false;
            for (int i = 0; i < columns_quantity; i++)
            {
              if (comp_df._children[i].name == cw)
              {
                b2 = true;
                break;
              }
            }
            if (b2 == false)
            {
              ppl.print("Error: [{0}] wrong column name [{1}]", new object[] { func_name, cw });
              return false;
            }
          }
        }
        //=====get RowSelectedFrom & RowSelectedTo===================================
        string strRowSelectedFrom = GetSettingsValue(comp_settings, "RowSelectedFrom");
        int RowSelectedFrom = 0;
        string strRowSelectedTo = GetSettingsValue(comp_settings, "RowSelectedTo");
        int RowSelectedTo = Length - 1;
        string PrintEmptyRows = GetSettingsValue(comp_settings, "PrintEmptyRows").ToLower();
        bool b = false;
        if (strRowSelectedFrom != "")
        {
          b = int.TryParse(strRowSelectedFrom, out RowSelectedFrom);
          if (b == false)
          {
            ppl.print("Error: [{0}] not digital  RowSelectedFrom [{1}])", new object[] { func_name, strRowSelectedFrom });
            return false;
          }
        }
        if (strRowSelectedTo == "*")
        {
          strRowSelectedTo = (Length-1).ToString();
        }
        if (strRowSelectedTo != "")
        {
          b = int.TryParse(strRowSelectedTo, out RowSelectedTo);
          if (b == false)
          {
            ppl.print("Error: [{0}] not digital  RowSelectedTo [{1}])", new object[] { func_name, strRowSelectedTo });
            return false;
          }
          if(RowSelectedTo >= Length)
          {
            ppl.print("Error: [{0}] RowSelectedTo [{1}] >= Max Rows Number [{2}])", new object[] { func_name, strRowSelectedTo, Length });
            return false;
          }
        }        
        int width = 0;
        //================Write column names=============
        ppl.print("");
        for (int i = 1; i < columns_quantity; i++)
        {
          if (columns_selected != null)
          {
            if (columns_selected.Contains(comp_df._children[i].name) == false)
              continue;
          }
          width = int.Parse(arr_type_width[i - 1].Width);
          output += comp_df._children[i].name.PadRight(width);
        }
        ppl.print("{0}", new object[] { output });
        ppl.print("");
        output = "";
        //==============================================
        if(Length == 0)
        {
          ppl.print("          no rows [{0}]", new object[] {  df_name });
          return true;
        }
        for (int j = RowSelectedFrom; j <= RowSelectedTo; j++)
        {
          output = String.Format("{0,-5}", j);
          string output2 = "";
          for (int i = 1; i < columns_quantity; i++)
          {
            if (columns_selected != null)
            {
              if (columns_selected.Contains(comp_df._children[i].name) == false)
                continue;
            }
            string value = ((Composite)comp_df._children[i])._children[j].value;
            width = int.Parse(arr_type_width[i - 1].Width);
            if (PrintEmptyRows == "yes")
              output2 += value.PadRight(width);
            else
            {
              if (value.Length > 0)
                output2 += value.PadRight(width);
            }
          }
          if (output2 == "")
            continue;
          output += output2;
          ppl.print("{0}", new object[] { output });
        }

      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
  }
}
