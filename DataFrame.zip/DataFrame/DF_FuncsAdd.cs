﻿/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Text;

namespace PPLNS
{
  public partial class DataFrame : AbstractClass
  {
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="[df_name=DF]"></param>
    /// <param name=["number=10]"></param>
    /// <returns></returns>
    public bool FuncAddRows(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncAddRows";
      try
      {
        if (parameters.Count == 0)
        {
          parameters.Add("DF");
          parameters.Add("10");
        }
        //=========================================================
        string df_name = parameters[0];
        string strLength = "";
        int Length = 0;

        bool b = false;
        if (parameters.Count == 2)
        {
          strLength = parameters[1];
          b = int.TryParse(strLength, out Length);
          if (b == false)
          {
            ppl.print("Error: [{0}] [{1}] not digital [{2}]", new object[] { func_name, df_name, strLength });
            return false;
          }
        }
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        if (parameters.Count == 1)
        {
          string strReallocIncrement = GetSettingsValue(comp_settings, "ReallocIncrement");
          b = int.TryParse(strReallocIncrement, out Length);
          if (b == false)
          {
            ppl.print("Error: [{0}] wrong ReallocIncrement  [{1}]", new object[] { func_name, strReallocIncrement });
            return false;
          }
        }
        ppl.print("DataFrame [{0}] added [{1}] rows", new object[] { df_name, Length });
        Component compRowsLength = GetComponentSettingsByName(comp_settings, "RowsLength");
        if (compRowsLength == null)
        {
          ppl.print("Error: [{0}] RowsLength is absent in [{1}].Settings", new object[] { func_name, df_name });
          return false;
        }
        int new_length = int.Parse(compRowsLength.value) + Length;
        for (int i = 1; i < comp_df._children.Count; i++)
        {
          comp_df._children[i].value = "Array " + new_length.ToString();
          for (int j = 0; j < Length; j++)
          {
            Leaf leaf = new Leaf("#");
            ((Composite)comp_df._children[i]).Add(leaf);
          }
        }
        compRowsLength.value = ((Composite)comp_df._children[1])._children.Count.ToString();
        string tmp_result = "";
        ppl.processing.FuncDisplayNodes(new List<string>() { parameters[0] }, ref tmp_result, node);
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="df_name"></param>
    /// <param name="column1"></param>
    /// <param name="column2"></param>
    /// <param name="....."></param>
    /// <returns></returns>
    public bool FuncAddColumns(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "FuncAddColumns";
      try
      {
         if (parameters.Count < 2)
         {
           ppl.print
            ("Error: [{0}] wrong parameter, format: DataFrame.FuncAddColumns (df_name)(column name1)(column name2)...", new object[] { func_name });
           return false;
         }
         string df_name = parameters[0];
        if (ppl.IsDigitsOnly(parameters[1]))
        {
          ppl.print("Error: [{0}] wrong column name [{1}])", new object[] { func_name, parameters[1] });
          return false;
        }
        //====================================================
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        int columns_quantity = comp_df._children.Count;
        string strLength = GetSettingsValue(comp_settings, "RowsLength");
        //int Length = int.Parse(strLength);
        //====================================================
        string output = "     ";
        string[] columns_selected = null;
        if (parameters.Count > 1)
        {
          columns_selected = new string[parameters.Count - 1];
          for (int i = 1; i < parameters.Count; i++)
            columns_selected[i - 1] = parameters[i];
        }
        //=============Test column names================
          foreach (string cw in columns_selected)
          {
            bool b2 = false;
            for (int i = 0; i < columns_quantity; i++)
            {
              if (comp_df._children[i].name == cw)
              {
                ppl.print("Error: [{0}] [{1}] column name [{2}] exists", new object[] { func_name, df_name, cw });
                return false;
              }
            }
          }
        //=====================================
        string tmp_result = "";
        string settings = parameters[0] + "." + "Settings";
        for (int i = 1; i < parameters.Count; i++)
         {
            tmp_result = "";
            string name = df_name + "." + parameters[i];
            ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + parameters[i] + "Type", "Text" }, ref tmp_result, node);
            ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + parameters[i] + "Width", "12" }, ref tmp_result, node);
            ppl.processing.FuncCreateArray(new List<string>() { name, strLength }, ref tmp_result, node);
         }
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
  }
}
