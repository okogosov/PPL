﻿using System;
using System.Text;

namespace PPLNS
{
  public partial class DataFrame : AbstractClass
  {
    //==========================================================
    public bool FuncClearColumns(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncClearColumns";
      try
      {
        if (parameters.Count < 1)
        {
          ppl.print
           ("Error: [{0}] wrong parameter, format: DataFrame.ClearColumns (df_name)[(column)(column)...]",
                 new object[] { func_name });
          return false;
        }
        if(parameters.Count == 0)
        {
          parameters.Add("DF");
        }
        string df_name = parameters[0];
        //====================================================
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name });
          return false;
        }
        int columns_quantity = comp_df._children.Count;
        string strLength = GetSettingsValue(comp_settings, "RowsLength");
        string[] columns_selected = null;
        if (parameters.Count > 1)
        {
          columns_selected = new string[parameters.Count - 1];
          for (int i = 1; i < parameters.Count; i++)
            columns_selected[i - 1] = parameters[i];
        }
        //=============Test column names================
        if (columns_selected != null)
        {
          foreach (string cw in columns_selected)
          {
            bool b2 = false;
            for (int i = 0; i < columns_quantity; i++)
            {
              if (comp_df._children[i].name == cw)
              {
                b2 = true;
                break;
              }
            }
            if (b2 == false)
            {
              ppl.print("Error: [{0}] wrong column name [{1}]", new object[] { func_name, cw });
              return false;
            }
          }
        }
        //============================================
        for (int i = 1; i < columns_quantity; i++)
        {
          if (comp_df._children[i] is Leaf)
          {
            ppl.print("Warning: [{0}] DataFrame [{1}] var [{2}]) not usable",
              new object[] { func_name, df_name, comp_df._children[i].name });
            continue;
          }
          Composite comp_column = (Composite)comp_df._children[i];
          if (columns_selected == null)
          {
            for (int j = 0; j < comp_column._children.Count; j++)
              comp_column._children[j].value = "";
          }
          else
          {
            if(columns_selected.Contains(comp_column.name))
            {
              for (int j = 0; j < comp_column._children.Count; j++)
                comp_column._children[j].value = "";
            }
          }
        }
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
  }
}
