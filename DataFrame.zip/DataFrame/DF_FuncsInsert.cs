﻿/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Text;

namespace PPLNS
{
  public partial class DataFrame : AbstractClass
  {
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="df_name"></param>
    /// <param name="index"></param>
    /// <param name="[count = 1]"></param>
    /// <returns></returns>
    public bool FuncInsertRows(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncInsertRows";
      try
      {
        if ((parameters.Count != 3) && (parameters.Count != 2))
        {
          ppl.print("Error: [{0}] wrong parameter, format: DataFrame.FuncInsertRows (DataFrame name)(index)[(number)]",
           new object[] { func_name });
          return false;
        }
        if(parameters.Count == 2)
        {
          parameters.Add("1");
        }
        //=========================================================
        string df_name = parameters[0];
        string strLength = "";
 

        bool b = false;
        string strIndex = "";
        int Index = 0;
        strIndex = parameters[1];
        b = int.TryParse(strIndex, out Index);
        if (b == false)
        {
          ppl.print("Error: [{0}] [{1}] index not digital [{2}]", new object[] { func_name, df_name, strIndex });
          return false;
        }
 
        string strNumberInsertedRows = parameters[2];
        int NumberInsertedRows = 0;
        b = int.TryParse(strNumberInsertedRows, out NumberInsertedRows);
        if (b == false)
        {
           ppl.print("Error: [{0}] [{1}] length not digital [{2}]", new object[] { func_name, df_name, strNumberInsertedRows });
           return false;
        }

        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        int Length = 0;
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Component compRowsLength = GetComponentSettingsByName(comp_settings, "RowsLength");
 
        if (compRowsLength == null)
        {
          ppl.print("Error: [{0}] RowsLength is absent in [{1}].Settings", new object[] { func_name, df_name });
          return false;
        }
        Length = int.Parse(compRowsLength.value);
        int new_length = Length + NumberInsertedRows;
        for (int i = 1; i < comp_df._children.Count; i++)
        {
          comp_df._children[i].value = "Array " + new_length.ToString();
          for (int j = Index; j < NumberInsertedRows + 1; j++)
          {
            ((Composite)comp_df._children[i]).Insert(j, new Leaf("#"));

          }
        }
        compRowsLength.value = new_length.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }

    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="df_name"></param>
    /// <param name="InsertBeforeColumn"></param>   
    /// <param name="Column1"></param>
    /// <param name="Column2"></param>
    /// <param name="..."></param>
    /// <returns></returns>
    public bool FuncInsertColumns(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncInsertColumns";
      try
      {
        if (parameters.Count < 3)
        {
          ppl.print
           ("Error: [{0}] wrong parameter, format: DataFrame.FuncInsertColumns (df_name)(InsertBeforeColumn)(column name1)(column name2)...", 
               new object[] { func_name });
          return false;
        }
        string df_name = parameters[0];
        string InsertBeforeColumn = parameters[1];
        //====================================================
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        int columns_quantity = comp_df._children.Count;
        string strLength = GetSettingsValue(comp_settings, "RowsLength");
        int Length = int.Parse(strLength);
        //====================================================
        string output = "     ";
        string[] columns_selected = null;
        columns_selected = new string[parameters.Count - 2];
        for (int i = 2; i < parameters.Count; i++)
           columns_selected[i - 2] = parameters[i];
      //=============Test column names================
      bool b3 = false;
      int IndexInsertBeforeColumn = 0;
      foreach (Component c in comp_df._children)
      {
        if(InsertBeforeColumn == c.name)
        {
          b3 = true;
          break;
        }
          IndexInsertBeforeColumn++;
      }
      if(b3 = false)
      {
        ppl.print("Error: [{0}]  [{1}] wrong InsertBeforeColumn name [{2}])", new object[] { func_name, df_name, InsertBeforeColumn });
        return false;
      }
      foreach (string cw in columns_selected)
      {
          bool b2 = false;
          for (int i = 0; i < columns_quantity; i++)
          {
            if (comp_df._children[i].name == cw)
            {
              ppl.print("Error: [{0}] [{1}] column name [{2}] exists", new object[] { func_name, df_name, cw });
              return false;
            }
          }
      }
        //=====================================
        string tmp_result = "";
        string settings = parameters[0] + "." + "Settings";
        for (int i = 2; i < parameters.Count; i++)
        {
          tmp_result = "";
          string name = parameters[i];
          ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + parameters[i] + "Type", "Text" }, ref tmp_result, node);
          ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + parameters[i] + "Width", "12" }, ref tmp_result, node);
          Composite new_array = new Composite(name,"Array " + strLength);
          new_array.nesting = comp_df.nesting + 1;
          for (int j = 0; j < Length; j++)  new_array.Add(new Leaf("#",""));
          comp_df.Insert(IndexInsertBeforeColumn, new_array);
          IndexInsertBeforeColumn++;

          if (ppl.Local_dns.Count == 0)    
          {
            ppl.Global_dns.Clear();
            ppl.Global.RefreshDataNameStructure(ppl, ppl.Global_dns, ppl.Global);
          }
          else     
          {
            PPL.LocalDataNameStruct local_dns = ppl.Local_dns.Peek();
            local_dns.dns.Clear();
            local_dns.scope_node.RefreshDataNameStructure(ppl, local_dns.dns, local_dns.scope_node);             
          }          
        }
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }

  }
}
