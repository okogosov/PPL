﻿/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Text;

namespace PPLNS
{
  public partial class DataFrame : AbstractClass
  {
    /// <summary>
    /// 
    /// </summary>
    /// <param name="df_name"></param>
    /// <param name="[number from]"></param>
    /// <param name="[number to]"></param>
    /// <returns></returns>
    /// RemoveRows(df_name) - remove all rows
    /// RemoveRows(df_name)(number row) - remove 1 row
    /// RemoveRows(df_name)(number from)(*) - remove from number till end
    /// RemoveRows(df_name)(number from)(number to) - remove rows from number_from to number_to
    public bool FuncRemoveRows(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncRemoveRows";
      try
      {
        if ((parameters.Count < 1) || ((parameters.Count > 3)))
        {
          ppl.print
           ("Error: [{0}] wrong parameter, format: DataFrame.RemoveRows (df_name)[(number from)[(number to)]]",
                 new object[] { func_name });
          return false;
        }
        //=========================================================
        string df_name = parameters[0];
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        int columns_quantity = comp_df._children.Count;
        string strLength = GetSettingsValue(comp_settings, "RowsLength");
        int Length = int.Parse(strLength);
        //====================================================
        int NumberFrom = 0;
        int NumberTo = 0;
        int parCount = parameters.Count;
        if (parCount == 1)         // remove all
        {
          parameters.Add("0"); 
          parameters.Add((Length - 1).ToString());
        }
        if (parCount == 2)      // remove 1 row
        {    
          parameters.Add(parameters[1]);
        }
        if ( (parCount == 3)  && (parameters[2] == "*") )   // remove 1 row
        {
          parameters[2] = (Length - 1).ToString();
        }
        string strNumberFrom = parameters[1];
        string strNumberTo = parameters[2];

        bool b = int.TryParse(strNumberFrom, out NumberFrom);
        if (b == false)
        {
          ppl.print("Error: [{0}] [{1}] not digital NumberFrom [{2}]", new object[] { func_name, df_name, strNumberFrom });
          return false;
        }
        b = int.TryParse(strNumberTo, out NumberTo);
        if (b == false)
        {
          ppl.print("Error: [{0}] [{1}] not digital NumberTo [{2}]", new object[] { func_name, df_name, strNumberTo });
          return false;
        }
        //=========================================================
        for (int i = 1; i < comp_df._children.Count; i++)
        {
          if (comp_df._children[i] is Leaf)
          {
            ppl.print("Warning: [{0}] DataFrame [{1}] var [{2}]) not usable",
              new object[] { func_name, df_name, comp_df._children[i].name });
            continue;
          }
          Composite comp = (Composite)comp_df._children[i];
          int delta = NumberTo - NumberFrom;
          for (int j = NumberFrom; j < comp._children.Count; j++)
          {
            comp.Remove(comp._children[j]);
            j--;
            if (delta == 0)
              break;
            delta--;
          }
          strLength = comp._children.Count.ToString();
          comp.value = "Array " + strLength;
        }
        Component c = GetComponentSettingsByName(comp_settings,"RowsLength");
        c.value = strLength;
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncRemoveColumns(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncRemoveColumns";
      try
      {
        if (parameters.Count < 1)
        {
          ppl.print
           ("Error: [{0}] wrong parameter, format: DataFrame.RemoveColumns (df_name)[(column1)(column2)...]",
                 new object[] { func_name });
          return false;
        }
        string df_name = parameters[0];
        //====================================================
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        int columns_quantity = comp_df._children.Count;
        string strLength = GetSettingsValue(comp_settings, "RowsLength");
        int Length = int.Parse(strLength);
        //====================================================
        string output = "     ";
        string[] columns_selected = null;
        if (parameters.Count > 1)
        {
          columns_selected = new string[parameters.Count - 1];
          for (int i = 1; i < parameters.Count; i++)
            columns_selected[i - 1] = parameters[i];
        }
        //=============Test column names================
        if (columns_selected != null)
        {
          foreach (string cw in columns_selected)
          {
            bool b2 = false;
            for (int i = 0; i < columns_quantity; i++)
            {
              if (comp_df._children[i].name == cw)
              {
                b2 = true;
                break;
              }
            }
            if (b2 == false)
            {
              ppl.print("Error: [{0}] wrong column name [{1}]", new object[] { func_name, cw });
              return false;
            }
          }
        }
        //=========================================================
        for (int i = 0; i < comp_df._children.Count; i++)
        {
          if (comp_df._children[i].name == "Settings")
            continue;
          if (comp_df._children[i] is Leaf)
          {
            ppl.print("Warning: [{0}] DataFrame [{1}] var [{2}]) not usable",
              new object[] { func_name, df_name, comp_df._children[i].name });
            continue;
          }
          if (columns_selected != null)
          {
            if (columns_selected.Contains(comp_df._children[i].name) == false)
              continue;
          }
          //else
          //{
            Component comp = GetComponentSettingsByName(comp_settings, comp_df._children[i].name + "Type");
            comp_settings.Remove(comp);
            comp = GetComponentSettingsByName(comp_settings, comp_df._children[i].name + "Width");
            comp_settings.Remove(comp);
            comp_df._children[i].parent.Remove(comp_df._children[i]);
            i--;
          //}
          //}
        }
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }

  }
}
