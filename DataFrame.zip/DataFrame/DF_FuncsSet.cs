﻿/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Text;

namespace PPLNS
{
  public partial class DataFrame : AbstractClass
  {
    /// <summary>
    /// 
    /// </summary>
    /// <param name="row number"></param>
    /// <param name="DataFrame"></param>
    /// <param name="value1"></param>
    /// <param name="value2"></param>
    /// ...
    /// <returns></returns>
    public bool FuncSetRow(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "FuncSetRow";
      try
      {
        if (parameters.Count < 3)
        {
          ppl.print
           ("Error: [FuncSetDataFrameRow] wrong parameter, format: DataFrame.SetRow (df_name)(row number)(value column1)(value column2)...");
          return false;
        }
        string df_name = parameters[0];
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
 
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        int columns_quantity = comp_df._children.Count;
        string strLength = GetSettingsValue(comp_settings, "RowsLength");
        int Length = int.Parse(strLength);

        int index = 0;
        bool b = int.TryParse(parameters[1], out index);
        if (b == false)
        {
          ppl.print("Error: [{0}] [{1}] index not digital [{2}]", new object[] { func_name, df_name, parameters[1] });
          return false;
        }
        if(index >= Length)
        {
          ppl.print("Error: [{0}] [{1}] index [{2}] out of bounds", new object[] { func_name, df_name, parameters[1] });
          return false;
        }
        if (parameters.Count - 2 > columns_quantity)
        {
          ppl.print("Error: []");
          return false;
        }
        for (int i = 2; i < parameters.Count; i++)
        {     // comp_df._children[0] - settings
          string column_name = comp_df._children[i - 1].name;
          string type = GetSettingsValue(comp_settings, column_name + "Type");
          if (type == "Number")
          {
            double d = 0;
            if (double.TryParse(parameters[i], out d) == false)
            {
              ((Composite)comp_df._children[i - 1])._children[index].value = "*error";
              continue;
            }
          }
          ((Composite)comp_df._children[i - 1])._children[index].value = parameters[i];
        }
      }
      catch (Exception ex)
      {
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncSetColumn(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "FuncSetColumn";
      try
      {
        if (parameters.Count < 3)
        {
          ppl.print
           ("Error: [{0}] wrong parameter, format: DataFrame.FuncSetColumn (df_name)(column name)(value1)(value2)...", new object[] { func_name });
          return false;
        }
        string df_name = parameters[0];
        string column_name = parameters[1];
        //====================================================
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        int columns_quantity = comp_df._children.Count;
        string strLength = GetSettingsValue(comp_settings, "RowsLength");
        string type = GetSettingsValue(comp_settings, column_name + "Type");
        int Length = int.Parse(strLength);

        Composite column_node = null;
        for (int i = 0; i < columns_quantity; i++)
        {
          if (((Composite)comp_df)._children[i].name == column_name)
          {
            column_node = (Composite)((Composite)comp_df)._children[i];
            break;
          }
        }
        if (column_node == null)
        {
          ppl.print
          ("Error: [{0}] [{1}] wrong column name [{2}]", new object[] { func_name, df_name, column_name });
          return false;
        }
        int real_count = parameters.Count - 2;
        if (parameters.Count - 2 > Length)
        {
          real_count = Length;
          ppl.print
          ("Warning: [{0}] [{1}] number of elements [{2}] > df.Length [{3}]", new object[] { func_name, df_name, parameters.Count, Length });
        }
        for (int i = 0; i < real_count; i++)
        {
          if (type == "Number")
          {
            double d = 0;
            if (double.TryParse(parameters[i + 2], out d) == false)
            {
              column_node._children[i].value = "*error";
              continue;
            }
          }
          column_node._children[i].value = parameters[i + 2];
        }
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }

    //==========================================================
  }
}
