﻿/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Text;

namespace PPLNS
{
  public partial class DataFrame : AbstractClass
  {
    /// <summary>
    /// SelectRows(df_name)(selected_row)    only one row
    /// </summary>
    /// <param name="parameters"></param>
    /// <param name="result"></param>
    /// <param name="node"></param>
    /// <returns></returns>
    public bool FuncSelectRows(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncSelectRows";
      string df_name = "";
      try
      {
        if ((parameters.Count != 2) && (parameters.Count != 3))
        {
          ppl.print
           ("Error: [{0}] wrong parameter, format: DataFrame.SelectRows(df_name)(select_from)[(select_to)]",
                 new object[] { func_name });
          return false;
        }
        if (parameters.Count == 2)
        {
          parameters.Add(parameters[1]);
        }
        df_name = parameters[0];
        
        //====================================================
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        string strLength = GetSettingsValue(comp_settings, "RowsLength");
        int Length = int.Parse(strLength);
        //====================================================
        // Get strSelectFrom  & strSelectTo
        string strSelectFrom = parameters[1];
          int SelectFrom = 0;
          if (int.TryParse(strSelectFrom, out SelectFrom) == false)
          {
            ppl.print("Error: [{0}] [{1}] not digital value [{2]", new object[] { func_name, df_name, strSelectFrom });
            return false;
          }
          if (strSelectFrom == "0")
          {
            ppl.print("Error: [{0}]  [{1}] select_from = 0", new object[] { func_name, strSelectFrom });
            return false;
          }
          //====================================================
          string strSelectTo = parameters[2];
          if (strSelectTo == "*")
            strSelectTo = (Length - 1).ToString();
          int SelectTo = 0;
          if (int.TryParse(strSelectTo, out SelectTo) == false)
          {
            ppl.print("Error: [{0}] [{1}] not digital value [{2]", new object[] { func_name, df_name, strSelectTo });
            return false;
          }
          if (strSelectTo == "0")
          {
            ppl.print("Error: [{0}]  [{1}] select_to = 0", new object[] { func_name, strSelectTo });
            return false;
          }

        //====================================================
        for (int i = 0; i < comp_settings._children.Count; i++)
        {
          if (comp_settings._children[i].name.Contains("RowSelectedFrom"))
            comp_settings._children[i].value = strSelectFrom;
          if (comp_settings._children[i].name.Contains("RowSelectedTo"))
            comp_settings._children[i].value = strSelectTo;
        }
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}] [{1}]", new object[] { func_name, df_name });
        return false;
      }
      return true;
    }
    //===============================================================
    public bool FuncUnSelectRows(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncUnSelectRows";
      string df_name = "";
      try
      {
        if (parameters.Count != 1)
        {
          ppl.print
           ("Error: [{0}] wrong parameter, format: DataFrame.UnSelectRows(df_name)", new object[] { func_name });
          return false;
        }
        df_name = parameters[0];       
        //====================================================
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        for (int i = 0; i < comp_settings._children.Count; i++)
        {
          if (comp_settings._children[i].name.Contains("RowSelectedFrom"))
            comp_settings._children[i].value = "";
          if (comp_settings._children[i].name.Contains("RowSelectedTo"))
            comp_settings._children[i].value = "";
        }
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}] [{1}]", new object[] { func_name, df_name });
        return false;
      }
      return true;
    }
  }
}
