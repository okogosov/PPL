﻿/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Linq;

namespace PPLNS
{
  public partial class DataFrame : AbstractClass
  {
    struct ValueIndex <T>
    {
      public ValueIndex(T value, int i)
      {
        this.value = value;
        this.i = i;
      }
      public T value;
      public int i;
    }
     
    public bool FuncSort(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncSort";
      try
      {
        if (parameters.Count != 3)
        {
          ppl.print("Error: [{0}] wrong parameter, format: DataFrame.FuncSort (DataFrame name)(ascend|descend)(column)",
           new object[] { func_name });
          return false;
        }
        //=========================================================
        string df_name = parameters[0];
        string order   = parameters[1].ToLower();
        string column_name = parameters[2];
        string strLength = "";

        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        int Length = 0;
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Component compRowsLength = GetComponentSettingsByName(comp_settings, "RowsLength");
        if ((order != "ascend") && (order != "descend"))
        {
          order = "ascend";
          ppl.print("Warning: [{0}] [{1}] accepted ascend order [{1}]", new object[] { func_name, df_name });
        }
        if (compRowsLength == null)
        {
          ppl.print("Error: [{0}] RowsLength is absent in [{1}].Settings", new object[] { func_name, df_name });
          return false;
        }
        Length = int.Parse(compRowsLength.value);
        string type = GetSettingsValue(comp_settings, column_name + "Type");
        Composite sorted_column = null;
        for (int i = 1; i < comp_df._children.Count; i++)
        {
          if (comp_df._children[i].name == column_name)
          {
            sorted_column = (Composite)comp_df._children[i];
            break;
          }
        }
        if (sorted_column == null)
        {
          ppl.print("Error: [{0}] [{1}] wrong name [{2}]", new object[] { func_name, df_name, column_name });
          return false;
        }
        int columns_quantity = comp_df._children.Count;

        if (type == "Text")
        {
          ValueIndex<string>[] value_indexes = new ValueIndex<string>[Length];
          for (int i = 0; i < sorted_column._children.Count; i++)
            value_indexes[i] = new ValueIndex<string>(sorted_column._children[i].value, i);
          IEnumerable<ValueIndex<string>> query = null;
          if(order == "ascend")
            query = value_indexes.OrderBy(s => s.value);
          else
            query = value_indexes.OrderByDescending(s => s.value);
          ValueIndex<string>[] vi = query.ToArray();
          for (int i = 1; i < columns_quantity; i++)
          {
            if (comp_df._children[i].name == column_name)
            {
              for (int j = 0; j < Length; j++)
                ((Composite)comp_df._children[i])._children[j].value = vi[j].value;
              continue;
            }
            string[] tmp_array = new string[Length];
            for (int j = 0; j < Length; j++)
              tmp_array[j] = ((Composite)comp_df._children[i])._children[j].value;
            //=====return=====            
            for (int j = 0; j < Length; j++)
            {
              int index = vi[j].i;
              ((Composite)comp_df._children[i])._children[j].value = tmp_array[index];
            }
          }
        }
        if (type == "Number")
        {
          ValueIndex<double>[] value_indexes = new ValueIndex<double>[Length];
          for (int i = 0; i < sorted_column._children.Count; i++)
          {
            double d = double.Parse(sorted_column._children[i].value);
            value_indexes[i] = new ValueIndex<double>(d, i);
          }
          IEnumerable<ValueIndex<double>> query = null;
          if (order == "ascend")
            query = value_indexes.OrderBy(s => s.value);
          else
            query = value_indexes.OrderByDescending(s => s.value);
          ValueIndex<double>[] vi = query.ToArray();
          for (int i = 1; i < columns_quantity; i++)
          {
            if (comp_df._children[i].name == column_name)
            {
              for (int j = 0; j < Length; j++)
                ((Composite)comp_df._children[i])._children[j].value = vi[j].value.ToString();
              continue;
            }
            string[] tmp_array = new string[Length];
            for (int j = 0; j < Length; j++)
              tmp_array[j] = ((Composite)comp_df._children[i])._children[j].value;
            //=====return=====            
            for (int j = 0; j < Length; j++)
            {
              int index = vi[j].i;
              ((Composite)comp_df._children[i])._children[j].value = tmp_array[index];
            }
          }
        }

  
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //=================================================================
    public bool FuncReverse(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncReverse";
      try
      {
        if (parameters.Count != 2)
        {
          ppl.print("Error: [{0}] wrong parameter, format: DataFrame.FuncReverse (DataFrame name)(column)",
           new object[] { func_name });
          return false;
        }
        //=========================================================
        string df_name = parameters[0];
        string column_name = parameters[1];
        string strLength = "";

        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        int Length = 0;
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Component compRowsLength = GetComponentSettingsByName(comp_settings, "RowsLength");
        if (compRowsLength == null)
        {
          ppl.print("Error: [{0}] RowsLength is absent in [{1}].Settings", new object[] { func_name, df_name });
          return false;
        }
        Length = int.Parse(compRowsLength.value);
        string type = GetSettingsValue(comp_settings, column_name + "Type");
        Composite sorted_column = null;
        for (int i = 1; i < comp_df._children.Count; i++)
        {
          if (comp_df._children[i].name == column_name)
          {
            sorted_column = (Composite)comp_df._children[i];
            break;
          }
        }
        if (sorted_column == null)
        {
          ppl.print("Error: [{0}] [{1}] wrong name [{2}]", new object[] { func_name, df_name, column_name });
          return false;
        }
        int columns_quantity = comp_df._children.Count;
          ValueIndex<string>[] value_indexes = new ValueIndex<string>[Length];
          for (int i = 0; i < sorted_column._children.Count; i++)
            value_indexes[i] = new ValueIndex<string>(sorted_column._children[i].value, i);
          IEnumerable<ValueIndex<string>> query = null;
          query = value_indexes.Reverse();
   
          ValueIndex<string>[] vi = query.ToArray();
          for (int i = 1; i < columns_quantity; i++)
          {
            if (comp_df._children[i].name == column_name)
            {
              for (int j = 0; j < Length; j++)
                ((Composite)comp_df._children[i])._children[j].value = vi[j].value;
              continue;
            }
            string[] tmp_array = new string[Length];
            for (int j = 0; j < Length; j++)
              tmp_array[j] = ((Composite)comp_df._children[i])._children[j].value;
            //=====return=====            
            for (int j = 0; j < Length; j++)
            {
              int index = vi[j].i;
              ((Composite)comp_df._children[i])._children[j].value = tmp_array[index];
            }
          }
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
  }
}
