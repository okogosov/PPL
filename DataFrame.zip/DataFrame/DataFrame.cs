/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Text;

namespace PPLNS
{
  public partial class DataFrame : AbstractClass
  {
    //  ppl & help_dict in Abstract Class
    //public PPL ppl;
    //Dictionary<string, string> help_dict = new Dictionary<string, string>();
    public DataFrame(PPL ppl)
    {
      this.ppl = ppl;
    }
    //==========================================================
    public void AddToKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, PPL.OperatorDelegate>();
      keyword_dict.Add("help", FuncHelp);
      keyword_dict.Add("SetRow",FuncSetRow);                    
      keyword_dict.Add("SetColumn",FuncSetColumn);              
      keyword_dict.Add("Write",FuncWrite);                      
      keyword_dict.Add("Save",FuncSave);                        
      keyword_dict.Add("Read", FuncRead);                       
      keyword_dict.Add("Create",FuncCreate);                    
      keyword_dict.Add("InsertRows",FuncInsertRows);            
      keyword_dict.Add("AddRows",FuncAddRows);                    
      keyword_dict.Add("InsertColumns",FuncInsertColumns);      
      keyword_dict.Add("AddColumns",FuncAddColumns);            
      keyword_dict.Add("RemoveRows",FuncRemoveRows);            
      keyword_dict.Add("RemoveColumns",FuncRemoveColumns);       
      keyword_dict.Add("ClearColumns", FuncClearColumns);       
      keyword_dict.Add("SetWidthForAll", FuncSetWidthForAll);   
      keyword_dict.Add("Sort", FuncSort);                       
      keyword_dict.Add("Reverse", FuncReverse);                 
      keyword_dict.Add("SelectRows", FuncSelectRows);                 
      keyword_dict.Add("UnSelectRows", FuncUnSelectRows);


      help_dict.Add("help","DataFrame.help([name])");
      help_dict.Add("Create", "\tDataFrame.Create([df_name])[(number rows)(column1)(column2)(column3)�]");
      help_dict.Add("SetRow", "\tDataFrame.SetRow(df_name)(row index)(value column1)( value column2)�");
      help_dict.Add("SetColumn", "\tDataFrame.SetColumn(df_name)(column)(value row1)(value row2)�");
      help_dict.Add("Write", "\tDataFrame.Write([df_name])[(column)(column)�]");
      help_dict.Add("Save", "\tDataFrame.Save(df_name)(filename.csv|.data)[(column)( column)]�");
      help_dict.Add("Read", "\tDataFrame.Read(df_name)(filename.csv|.data)[(column)( column)]�");
      help_dict.Add("InsertRows", "\tDataFrame.InsertRows(df_name)(index)[(number of rows)]");
      help_dict.Add("AddRows", "\tDataFrame.AddRows([df_name])[(number of rows)]");
      help_dict.Add("InsertColumns", "\tDataFrame.InsertColumns(df_name) )(specified column)(column)(column)�");
      help_dict.Add("AddColumns", "\tDataFrame.AddColumns(df_name)(column1)(column2)�");
      help_dict.Add("RemoveRows", "\tRemoveRows(df_name)(number_from)(number_to)");
      help_dict.Add("RemoveColumns", "\tRemoveColumns(df_name)(column1)(column2)�");
      help_dict.Add("ClearColumns", "\tDataFrame.ClearColumns(df_name)[(column)(column)�]");
      help_dict.Add("SetWidthForAll", "\tDataFrame.SetWidthForAll([df_name])([width])");
      help_dict.Add("Sort", "\tDataFrame.Sort(df_name)(ascend | descend)(column)");
      help_dict.Add("Reverse", "\tDataFrame.Reverse(df_name)(column)");
      help_dict.Add("SelectRows", "\tDataFrame.SelectRows(df_name)(select_from)[(*|select_to)]");
      help_dict.Add("UnSelectRows", "\tDataFrame.UnSelectRows(df_name)");

      try
      {
        if (ppl.ImportList.ContainsKey("DataFrame") == false)
        {
           foreach (KeyValuePair<string, PPL.OperatorDelegate> pair in keyword_dict)
           {
             ppl.processing.keyword_dict.Add("DataFrame." + pair.Key, pair.Value);
           }
           ppl.ImportList.Add("DataFrame", this);
        }
      }
      catch (Exception io)
      { }
    }
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="DataFrame"></param>
    /// <param name="length"></param>
    /// <param name="column name1"></param>
    /// <param name="column name2"></param>
    /// <param name="column name3"></param>
    /// ...
    /// <returns></returns>
    /// DataFrame.Create() => Create(DF)(10)(A)(B)(C)...  26 columns
    public bool FuncCreate(List<string> inp_parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncCreate";
      try
      {
        bool abc = false;
        List<string> parameters = new();
        if (inp_parameters.Count == 0)
        {
          parameters.Add("DF");
          parameters.Add("10");
          int unicode = 65;
          abc = true;
          for (int i = 0; i < 26; i++)
          {
            char character = (char)(unicode + i);
            string column_name = character.ToString();
            parameters.Add(column_name);
          }
        }
        else 
        { 
          foreach (Component c in node._children)
            parameters.Add(c.name);
          if (node._children.Count == 1)
            parameters.Add("0");
          if (parameters[1] == "")   // Create(name)() = Create(name)(0) 
            parameters[1] = "0";
        }
        string tmp_result = "";
        string name = "";
        int Length = 0;
        string strLength = parameters[1];
        bool b = int.TryParse(strLength, out Length);
        if (b == false)
        {
          ppl.print ("Error: [{0}] wrong rows length [{1}]", new object[] { func_name, strLength });
          return false;
        }
        string settings = parameters[0] + "." + "Settings";
        ppl.processing.FuncCreateNode(new List<string>() { parameters[0], "" }, ref tmp_result, node);
        ppl.processing.FuncCreateNode(new List<string>() { settings, "" }, ref tmp_result, node);
        ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + "RowSelectedFrom", "" }, ref tmp_result, node);
        ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + "RowSelectedTo", "" }, ref tmp_result, node);
        ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + "PrintEmptyRows", "yes" }, ref tmp_result, node);   // yes|no
        ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + "RowsLength", strLength }, ref tmp_result, node);
        ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + "ReallocIncrement", "10" }, ref tmp_result, node);
        // set unic value for column
       // ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + "Key", "" }, ref tmp_result, node);
 
        // Type: Text.Number... 
        for (int i = 2; i < parameters.Count; i++)
        {
          tmp_result = "";
          name = parameters[0] + "." + parameters[i];
          ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + parameters[i] + "Type", "Text" }, ref tmp_result, node);
          if (abc)   // alphabet
            ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + parameters[i] + "Width", "4" }, ref tmp_result, node);
          else
          ppl.processing.FuncCreateVariables(new List<string>() { settings + "." + parameters[i] + "Width", "12" }, ref tmp_result, node);
          ppl.processing.FuncCreateArray(new List<string>() { name, strLength }, ref tmp_result, node);
        }
       // ppl.processing.FuncDisplay(new List<string>() { parameters[0] + "." + "Settings"}, ref tmp_result, node);
       // ppl.processing.FuncDisplayNodes(new List<string>() { parameters[0] }, ref tmp_result, node);
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
   
    string GetSettingsValue(Composite comp_settings,string name)
    {      
      foreach (Component c in comp_settings._children)
      {
        if (c.name == name)
        {
          return c.value;
        }
      }
      return "";
    }
    //==========================================================
    Component GetComponentSettingsByName(Composite comp_settings, string name)
    {
      foreach (Component c in comp_settings._children)
      {
        if (c.name == name)
        {
          return c;
        }
      }
      return null;
    }
    //==========================================================
    Composite GetDataFrameComposite(string df_name)
    {
      string name = "", nodes = "";
      Composite path = null;
      Composite comp_df = null;
      string func_name = "DataFrame.GetDataFrameComposite";
      bool b = ppl.processing.GetPathAndNameFromGlobalLocal(func_name, df_name, ref path, ref nodes, ref name);
      if (b == false)
        return null;
      for (int j = 0; j < path._children.Count; j++)
      {
        Component comp = path._children[j];
        if (comp.name == df_name)
        {
          comp_df = (Composite)comp;
          break;
        }
      }
      if (comp_df == null)
        return null;
      else
        return comp_df;
    }
    //==========================================================
    Composite GetSettingsComposite(Composite comp_df)
    {
      Composite comp_settings = null;
      foreach (Component c in comp_df._children)
      {
        if (c.name == "Settings")
        {
          comp_settings = (Composite)c;
          return comp_settings;
        }
      }
      return null;
    }
    //==========================================================
    struct TypeWidth
    {
      public string Type;
      public string Width;
    }
    TypeWidth[] CreateTypeWidthArray(Composite comp_df, Composite comp_settings)
    {
      int columns_quantity = comp_df._children.Count;
      
      string[] columns = new string[columns_quantity - 1];

      for (int i = 1; i < comp_df._children.Count; i++)
        columns[i - 1] = comp_df._children[i].name;
      TypeWidth[] arr_type_width = new TypeWidth[columns_quantity - 1];
      for (int i = 0; i < columns.Length; i++)
      {
        TypeWidth tw;
        tw.Type = GetSettingsValue(comp_settings, columns[i] + "Type");
        tw.Width = GetSettingsValue(comp_settings, columns[i] + "Width");
        arr_type_width[i] = tw;
      }
      return arr_type_width;
    }
    
    //==========================================================
    public string[] SplitCsv(string line, char separator)
    {
      // separator - not whitespace
      List<string> result = new List<string>();
      StringBuilder currentStr = new StringBuilder("");
      bool inQuotes = false;
      for (int i = 0; i < line.Length; i++)
      {
        if (line[i] == '\"')
          inQuotes = !inQuotes;
        else if (line[i] == separator)
        {
          if (!inQuotes) // If not in quotes, end of current string, add it to result
          {
            result.Add(currentStr.ToString().Trim());
            currentStr.Clear();
          }
          else
            currentStr.Append(line[i]); // If in quotes, just add it 
        }
        else // Add any other character to current string
        {
          currentStr.Append(line[i]);
        }
      }
      result.Add(currentStr.ToString().Trim());
      return result.ToArray();
    }
    //============================================================
    int GetColumnIndex(Composite comp_df, string name)
    {
      int i = 0;
      foreach (Component c in comp_df._children)
      {
        if (c.name == name)
          return i;
        i++;
      }
      return -1;
    }
    //=================================================================
    public bool FuncSetWidthForAll(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "DataFrame.FuncSetWidthForAll";
      string df_name = "";
      try
      {
        if (parameters.Count > 2)
        {
          ppl.print
           ("Error: [{0}] wrong parameter, format: DataFrame.SetWidthForAll ([df_name])[(value)]",
                 new object[] { func_name });
          return false;
        }
        if (parameters.Count == 0)
        {
          parameters.Add("DF");
          parameters.Add("12");
        }
        if (parameters.Count == 1)
        {
          parameters.Add("12");
        }
        df_name = parameters[0];
        string strWidth = parameters[1];
        int width = 0;
        if(int.TryParse(strWidth,out width) == false)
        {
            ppl.print ("Error: [{0}] [{1}] not digital width [{2]", new object[] { func_name, df_name, strWidth });
            return false;
        }
        if (strWidth == "0")
        {
            ppl.print("Error: [{0}]  [{1}] width = 0", new object[] { func_name, df_name });
            return false;
        }

        //====================================================
        Composite comp_df = GetDataFrameComposite(df_name);
        if (comp_df == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        Composite comp_settings = GetSettingsComposite(comp_df);
        if (comp_settings == null)
        {
          ppl.print("Error: [{0}] wrong DataFrame name [{1}])", new object[] { func_name, df_name });
          return false;
        }
        for (int i = 0; i < comp_settings._children.Count; i++)
        {
          if (comp_settings._children[i].name.Contains("Width"))
            comp_settings._children[i].value = strWidth;
        }
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}] [{1}]", new object[] { func_name, df_name });
        return false;
      }
      return true;
    }
    //=============================================================     
  }
}