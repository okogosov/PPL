/***************************************************************
*This code generated with Application ULC.exe                  *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Collections.Generic;
//using System.Reflection;
using MathNet.Numerics.Distributions;
using MathNet.Numerics.Random;
namespace PPLNS
{
  //============================================================
  public class PPL_ChiSquared
  {
    PPL ppl = null;
    MathNet.Numerics.Distributions.ChiSquared chiSquared = null;
    public PPL_ChiSquared(PPL ppl)
    {
      this.ppl = ppl;
    }
    //============================================================
    public bool FuncChiSquared(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_ChiSquared.FuncChiSquared";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.ChiSquared(freedom)", new object[] { func_name });
        return false;
      }
      try
      {
        double freedom;
        if (System.Double.TryParse(parameters[0], out freedom) == false)
        {
          ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        chiSquared = new MathNet.Numerics.Distributions.ChiSquared(freedom, new System.Random());

      }
      catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_ChiSquared.FuncCDF";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.ChiSquared.CDF (freedom)(x)", new object[] { func_name });
        return false;
      }
      try
      {
        double freedom, x;
        if (System.Double.TryParse(parameters[0], out freedom) == false)
        {
          ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out x) == false)
        {
          ppl.print("Error: [{0}] not digital x [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        result = MathNet.Numerics.Distributions.ChiSquared.CDF(freedom, x).ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name }); 
        return false; 
      }
       return true; 
    }
    //============================================================
    public bool FuncInvCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_ChiSquared.FuncInvCDF";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.ChiSquared.InvCDF (freedom)(p)", new object[] { func_name });
        return false;
      }
      try
      {
        double freedom, p;
        if (System.Double.TryParse(parameters[0], out freedom) == false)
        {
          ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out p) == false)
        {
          ppl.print("Error: [{0}] not digital p [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        result = MathNet.Numerics.Distributions.ChiSquared.InvCDF(freedom, p).ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name }); 
        return false; 
      }
       return true; 
    }
  }
}
