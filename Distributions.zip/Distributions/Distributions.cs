/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Collections.Generic;
using System.Reflection;
using MathNet.Numerics.Distributions;
using MathNet.Numerics.Random;

namespace PPLNS
{
  //============================================================
  //============================================================
  public class PPL_Normal
  {
    PPL ppl = null;
    MathNet.Numerics.Distributions.Normal normal = null;
    public PPL_Normal(PPL ppl)
    {
      this.ppl = ppl;
    }
    //==========================================================
    //Normal(double mean, double stddev, Random randomSource)
    /// <summary>
    /// 
    /// </summary>
    /// <param name="mean"></param>
    /// <param name="stdev"></param>
    /// <param name="seed"></param>
    /// <returns></returns>
    public bool FuncNormal(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "FuncNormal";
      if((parameters.Count != 0) && (parameters.Count != 2))
      {
        ppl.print("Error: [{0}] wrong format: Distributions.Normal () | (mean)(stddev)", new object[] { func_name });
        return false;
      }
      try
      {
        if (parameters.Count == 0)
        {
          normal = new MathNet.Numerics.Distributions.Normal();
          return true;
        }
        double mean;
        double stddev;

        if (System.Double.TryParse(parameters[0], out mean) == false)
        {
          ppl.print("Error: [{0}] not digital mean [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out stddev) == false)
        {
          ppl.print("Error: [{0}] not digital stddev [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        normal = new MathNet.Numerics.Distributions.Normal(mean, stddev, new System.Random());
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }

    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="means"></param>  double
    /// <param name="stddev"></param> double
    /// <param name="x"></param>      double
    /// <returns></returns>
    /// double = Distributions.Normal.CDF(mean)(stddev)(x);
    // static
    public bool CDF(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.CDF";
      if(parameters.Count != 3)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.Normal.CDF (mean)(stddev)(x)", new object[] { func_name });
        return false;
      }
      try
      {
        double mean, stddev, x;
        if (System.Double.TryParse(parameters[0], out mean) == false)
        {
          ppl.print("Error: [{0}] not digital mean [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out stddev) == false)
        {
          ppl.print("Error: [{0}] not digital stddev [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out x) == false)
        {
          ppl.print("Error: [{0}] not digital x [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }

        result = MathNet.Numerics.Distributions.Normal.CDF(mean,stddev,x).ToString();        
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    // static
    public bool Estimate(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Estimate";
      try
      {
        //MathNet.Numerics.Distributions.Normal.Estimate();
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="means"></param>  double
    /// <param name="stddev"></param> double
    /// <param name="p"></param>      double
    /// <returns></returns>
    /// double = Distributions.Normal.InvCDF(mean)(stddev)(p);
    // static
    public bool InvCDF(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.InvCDF";
      try
      {
        double mean, stddev, p;
        if (System.Double.TryParse(parameters[0], out mean) == false)
        {
          ppl.print("Error: [{0}] not digital mean [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out stddev) == false)
        {
          ppl.print("Error: [{0}] not digital stddev [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out p) == false)
        {
          ppl.print("Error: [{0}] not digital p [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }

        result = MathNet.Numerics.Distributions.Normal.CDF(mean, stddev, p).ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    #region
    //==========================================================
    // static
    public bool IsValidParameterSet(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.IsValidParameterSet";
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    // static
    public bool PDF(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.PDF";
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    // static
    public bool PDFLn(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.PDFLn";
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    // static
    public bool Sample(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Sample";
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    // static
    public bool Samples(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Samples";
      try
      {
        //ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
        //double[] d = new double[5];
        //normal.Samples(d);
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    // static
    public bool WithMeanPrecision(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.WithMeanPrecision";
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    // static
    public bool WithMeanStdDev(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.WithMeanStdev";
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    // static
    public bool WithMeanVariance(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.WithMeanVarianceNormal";
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
     //==========================================================
    public bool CumulativeDistribution(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.CumulativeDistribution";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool Density(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Density";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool DensityLn(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.DensityLn";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    /*public bool Equals(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Equals";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
              
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool GetHashCode(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.GetHashCode";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
              
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool GetType(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.GetType";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
              
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool ToString(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.ToString";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
              
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    */
    //==========================================================
    public bool InverseCumulaiveDistribution(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.InverseCumulaiveDistribution";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
  
    //==========================================================
    //       public properties
    public bool Entropy(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Entropy";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool Maximum(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Maximum";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        result = normal.Maximum.ToString();
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool Mean(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Mean";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
        result = normal.Mean.ToString();
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool Median(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Median";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool Minimum(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Minimum";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool Mode(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Mode";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        //ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
        result = normal.Mode.ToString();
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool Precision(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Precision";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool Skeness(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Skeness";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool StdDev(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.StdDev";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool Variance(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Normal.Variance";
      if (normal == null)
      {
        ppl.print("Error: [{0}] Constructor MathNet.Numerics.Distributions.Normal =  null", new object[] { func_name });
        return false;
      }
      try
      {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    #endregion
  }
  //============================================================
  //============================================================
  public class PPL_ChiSquared
  {
    //==========================================================
    PPL ppl;
    MathNet.Numerics.Distributions.ChiSquared chiSquared = null;
    public PPL_ChiSquared(PPL ppl)
    {
      this.ppl = ppl;
    }
    public bool FuncChiSquared(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "PPL_ChiSquared.FuncChiSquared";
      if(parameters.Count !=1)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.ChiSquared(freedom)", new object[] { func_name });
        return false;
      }
      try
      {
        double freedom;
        if (System.Double.TryParse(parameters[0], out freedom) == false)
        {
          ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        chiSquared = new MathNet.Numerics.Distributions.ChiSquared(freedom, new System.Random());

      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="freedom"></param>
    /// <param name="x"></param>
    /// <returns></returns>
    /// double = Distributions.ChiSquared.CDF(freedom)(x);
    // static
    public bool CDF(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "PPL_ChiSquared.CDF";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.ChiSquared.CDF (freedom)(x)", new object[] { func_name });
        return false;
      }
      try
      {
        double freedom, x;
        if (System.Double.TryParse(parameters[0], out freedom) == false)
        {
          ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out x) == false)
        {
          ppl.print("Error: [{0}] not digital x [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        result = MathNet.Numerics.Distributions.ChiSquared.CDF(freedom,x).ToString();
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="freedom"></param>
    /// <param name="p"></param>
    /// <returns></returns>
    /// double = Distributions.ChiSquared.InvCDF(freedom)(p);
    // static
    public bool InvCDF(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "PPL_ChiSquared.InvCDF";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.ChiSquared.InvCDF (freedom)(p)", new object[] { func_name });
        return false;
      }
      try
      {
        double freedom, p;
        if (System.Double.TryParse(parameters[0], out freedom) == false)
        {
          ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out p) == false)
        {
          ppl.print("Error: [{0}] not digital p [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        result = MathNet.Numerics.Distributions.ChiSquared.InvCDF(freedom, p).ToString();
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
  }
  //============================================================
  //============================================================
  public class PPL_FisherSnedecor
  {
    PPL ppl;
    MathNet.Numerics.Distributions.FisherSnedecor fisherSnedecor = null;
    public PPL_FisherSnedecor(PPL ppl)
    {
      this.ppl = ppl;
    }
    //==========================================================
    public bool FuncFisherSnedecor(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "PPL_FisherSnedecor.FuncFisherSnedecor";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.FisherSnedecor(d1)(d2)", new object[] { func_name });
        return false;
      }
      try
      {
        double d1,d2;
        if (System.Double.TryParse(parameters[0], out d1) == false)
        {
          ppl.print("Error: [{0}] not digital d1 [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out d2) == false)
        {
          ppl.print("Error: [{0}] not digital d2 [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        fisherSnedecor = new MathNet.Numerics.Distributions.FisherSnedecor(d1,d1, new System.Random());
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="d1"></param>
    /// <param name="d2"></param>
    /// <param name="x"></param>
    /// <returns></returns>
    /// double = Distributions.FisherSneDecor.CDF(d1)(d2)(x);
    // static
    public bool CDF(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "PPL_FisherSnedecor.CDF";
      if (parameters.Count != 3)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.FisherSnedecor.CDF (d1)(d2)(x)", new object[] { func_name });
        return false;
      }
      try
      {
        double d1, d2, x;
        if (System.Double.TryParse(parameters[0], out d1) == false)
        {
          ppl.print("Error: [{0}] not digital d1 [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out d2) == false)
        {
          ppl.print("Error: [{0}] not digital d2 [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out x) == false)
        {
          ppl.print("Error: [{0}] not digital x [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }
        result = MathNet.Numerics.Distributions.FisherSnedecor.CDF(d1,d2,x).ToString();
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="d1"></param>
    /// <param name="d2"></param>
    /// <param name="p"></param>
    /// <returns></returns>
    /// double = Distributions.FisherSneDecor.InvCDF(d1)(d2)(p);
    // static
    public bool InvCDF(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "PPL_FisherSnedecor.InvCDF";
      if (parameters.Count != 3)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.FisherSnedecor.CDF (d1)(d2)(x)", new object[] { func_name });
        return false;
      }
      try
      {
        double d1, d2, p;
        if (System.Double.TryParse(parameters[0], out d1) == false)
        {
          ppl.print("Error: [{0}] not digital d1 [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out d2) == false)
        {
          ppl.print("Error: [{0}] not digital d2 [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out p) == false)
        {
          ppl.print("Error: [{0}] not digital p [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }
        result = MathNet.Numerics.Distributions.FisherSnedecor.InvCDF(d1, d2, p).ToString();
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
  }
  //============================================================
  //============================================================
  public class PPL_StudentT
  {
     PPL ppl;
     MathNet.Numerics.Distributions.StudentT studenT = null;
     public PPL_StudentT(PPL ppl)
     {
      this.ppl = ppl;
     }
    //==========================================================
    public bool FuncStudentT(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "PPL_StudentT.FuncStudentT";
      if ((parameters.Count != 0) && (parameters.Count != 3))
      {
        ppl.print("Error: [{0}] wrong format: Distributions.StudentT() | (location)(scale)(freedom)", new object[] { func_name });
        return false;
      }
      try
      {
        if (parameters.Count == 0)
        {
          studenT = new MathNet.Numerics.Distributions.StudentT();
          return true;
        }
        double location, scale, freedom, x;
        if (System.Double.TryParse(parameters[0], out location) == false)
        {
          ppl.print("Error: [{0}] not digital location [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out scale) == false)
        {
          ppl.print("Error: [{0}] not digital scale [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out freedom) == false)
        {
          ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }
        studenT = new MathNet.Numerics.Distributions.StudentT(location, scale, freedom,new Random());  
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="location"></param>
    /// <param name="scale"></param>
    /// <param name="freedom"></param>
    /// <param name="x"></param>
    /// <returns></returns>
    /// double = Distributions.Student.CDF(location)(scale)(freedom)(x);
    // static
    public bool CDF(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "PPL_StudentT.CDF";
      if (parameters.Count != 4)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.StudentT.CDF (location)(scale)(freedom)(x)", new object[] { func_name });
        return false;
      }
      try
      {
        double location, scale, freedom, x;
        if (System.Double.TryParse(parameters[0], out location) == false)
        {
          ppl.print("Error: [{0}] not digital location [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out scale) == false)
        {
          ppl.print("Error: [{0}] not digital scale [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out freedom) == false)
        {
          ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }
        if (System.Double.TryParse(parameters[3], out x) == false)
        {
          ppl.print("Error: [{0}] not digital x [{1}]", new object[] { func_name, parameters[3] });
          return false;
        }
        result = MathNet.Numerics.Distributions.StudentT.CDF(location,scale,freedom,x).ToString();
      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="location"></param>
    /// <param name="scale"></param>
    /// <param name="freedom"></param>
    /// <param name="p"></param>
    /// <returns></returns>
    /// double = Distributions.Student.InvCDF(location)(scale)(freedom)(p);
    // static
    public bool InvCDF(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "PPL_StudentT.InvCDF";
      if (parameters.Count != 4)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.StudentT.InvCDF (location)(scale)(freedom)(p)", new object[] { func_name });
        return false;
      }
      try
      {
        try
        {
          double location, scale, freedom, p;
          if (System.Double.TryParse(parameters[0], out location) == false)
          {
            ppl.print("Error: [{0}] not digital location [{1}]", new object[] { func_name, parameters[0] });
            return false;
          }
          if (System.Double.TryParse(parameters[1], out scale) == false)
          {
            ppl.print("Error: [{0}] not digital scale [{1}]", new object[] { func_name, parameters[1] });
            return false;
          }
          if (System.Double.TryParse(parameters[2], out freedom) == false)
          {
            ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[2] });
            return false;
          }
          if (System.Double.TryParse(parameters[3], out p) == false)
          {
            ppl.print("Error: [{0}] not digital p [{1}]", new object[] { func_name, parameters[3] });
            return false;
          }
          result = MathNet.Numerics.Distributions.StudentT.InvCDF(location, scale, freedom, p).ToString();
        }
        catch (Exception ex)
        {
          ppl.print("Error: [{0}]", new object[] { func_name });
          return false;
        }

      }
      catch (Exception ex)
      {
         ppl.print("Error: [{0}]", new object[] { func_name });
        return false;
      }
      return true;
    }
    //==========================================================

  }
  //============================================================
  //============================================================
  public class Distributions : AbstractClass
  {
    //  ppl & help_dict in Abstract Class
    //public PPL ppl;
    //Dictionary<string, string> help_dict = new Dictionary<string, string>();
    PPL_Normal normal = null;
    PPL_ChiSquared chiSquared = null;
    PPL_FisherSnedecor fisherSnedecor = null;
    PPL_StudentT studentT = null;
    
    public Distributions(PPL ppl)
    {
      this.ppl = ppl;
      normal = new(ppl);
      chiSquared = new(ppl);
      fisherSnedecor = new(ppl);
      studentT = new(ppl);
    }
    //==========================================================
    public void AddToKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, PPL.OperatorDelegate>();
      keyword_dict.Add("help", FuncHelp);
      keyword_dict.Add("Normal",          normal.FuncNormal);
      #region
      
       keyword_dict.Add("Normal.CDF",      normal.CDF);
       keyword_dict.Add("Normal.Estimate", normal.Estimate);
       keyword_dict.Add("Normal.InvCDF",   normal.InvCDF);
      
       keyword_dict.Add("Normal.IsValidParameterSet",         normal.IsValidParameterSet);
       keyword_dict.Add("Normal.PDF",                         normal.PDF);
       keyword_dict.Add("Normal.PDFLn",                       normal.PDFLn);
       keyword_dict.Add("Normal.Sample",                      normal.Sample);
       keyword_dict.Add("Normal.Samples",                     normal.Samples);
       keyword_dict.Add("Normal.WithMeanPrecision",           normal.WithMeanPrecision);
       keyword_dict.Add("Normal.WithMeanStdDev",              normal.WithMeanStdDev);
       keyword_dict.Add("Normal.WithMeanVariance",            normal.WithMeanVariance);
       keyword_dict.Add("Normal.CumulativeDistribution",      normal.CumulativeDistribution);
       keyword_dict.Add("Normal.Density",                     normal.Density);
       keyword_dict.Add("Normal.DensityLn",                   normal.DensityLn);
      // keyword_dict.Add("Normal.Equals",                      normal.Equals);
      // keyword_dict.Add("Normal.GetHashCode",                 normal.GetHashCode);
      // keyword_dict.Add("Normal.GetType",                     normal.GetType);
      // keyword_dict.Add("Normal.ToString",                    normal.ToString);
       keyword_dict.Add("Normal.InverseCumulaiveDistribution",normal.InverseCumulaiveDistribution);      
       keyword_dict.Add("Normal.Entropy",                     normal.Entropy);
       keyword_dict.Add("Normal.Maximum",                     normal.Maximum);
       keyword_dict.Add("Normal.Mean",                        normal.Mean);
       keyword_dict.Add("Normal.Median",                      normal.Median);
       keyword_dict.Add("Normal.Minimum",                     normal.Minimum);
       keyword_dict.Add("Normal.Mode",                        normal.Mode);
       keyword_dict.Add("Normal.Precision",                   normal.Precision);
       keyword_dict.Add("Normal.Skeness",                     normal.Skeness);
       keyword_dict.Add("Normal.StdDev",                      normal.StdDev);
       keyword_dict.Add("Normal.Variance",                    normal.Variance);
       
      #endregion
      keyword_dict.Add("StudentT",        studentT.FuncStudentT);
      keyword_dict.Add("StudentT.CDF",    studentT.CDF);
      keyword_dict.Add("StudentT.InvCDF", studentT.InvCDF);
  
      keyword_dict.Add("ChiSquared",        chiSquared.FuncChiSquared);
      keyword_dict.Add("ChiSquared.CDF",    chiSquared.CDF);
      keyword_dict.Add("ChiSquared.InvCDF", chiSquared.InvCDF);
  
      keyword_dict.Add("FisherSnedecor",        fisherSnedecor.FuncFisherSnedecor);
      keyword_dict.Add("FisherSnedecor.CDF",    fisherSnedecor.CDF);
      keyword_dict.Add("FisherSnedecor.InvCDF", fisherSnedecor.InvCDF);
         
      help_dict.Add("help","Distributions.help([name])");
      help_dict.Add("Normal","");
      help_dict.Add("Normal.CDF","");
      help_dict.Add("Normal.Estimate","");
      help_dict.Add("Normal.InvCDF","");
      help_dict.Add("Normal.IsValidParameterSet","");
      help_dict.Add("Normal.PDFNormal.PDFLn","");
      help_dict.Add("Normal.Sample","");
      help_dict.Add("Normal.Samples","");
      help_dict.Add("Normal.WithMeanPrecision","");
      help_dict.Add("Normal.WithMeanStdDev","");
      help_dict.Add("Normal.WithMeanVarianceNormal","");
      help_dict.Add("Normal.CumulativeDistribution","");
      help_dict.Add("Normal.Density","");
      help_dict.Add("Normal.DensityLn","");
     // help_dict.Add("Normal.Equals","");
     // help_dict.Add("Normal.GetHashcode","");
     // help_dict.Add("Normal.GetType","");      
     // help_dict.Add("Normal.ToString","");
      help_dict.Add("Normal.InverseCumulaiveDistribution", "");
      help_dict.Add("Normal.Entropy", "");
      help_dict.Add("Normal.Maximum","");
      help_dict.Add("Normal.Mean","");
      help_dict.Add("Normal.Median","");
      help_dict.Add("Normal.Minimum","");
      help_dict.Add("Normal.Mode","");
      help_dict.Add("Normal.Precision","");
      help_dict.Add("Normal.Skeness","");
      help_dict.Add("Normal.StdDev","");
      help_dict.Add("Normal.Variance","");
      
      help_dict.Add("StudentT","");
      help_dict.Add("StudentT.CDF","");
      help_dict.Add("StudentT.InvCDF","");

      help_dict.Add("ChiSquared","");
      help_dict.Add("ChiSquared.CDF","");
      help_dict.Add("ChiSquared.InvCDF","");

      help_dict.Add("FisherSnedecor","");
      help_dict.Add("FisherSnedecor.CDF","");
      help_dict.Add("FisherSnedecor.InvCDF","");
      
      try
      {
        if (ppl.ImportList.ContainsKey("Distributions") == false)
        {
           foreach (KeyValuePair<string, PPL.OperatorDelegate> pair in keyword_dict)
           {
             ppl.processing.keyword_dict.Add("Distributions." + pair.Key, pair.Value);
           }
           ppl.ImportList.Add("Distributions", this);
        }
      }
      catch (Exception io)
      { }
    }   
  }
}