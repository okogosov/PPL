/***************************************************************
*This code generated with Application ULC.exe                  *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
//https://numerics.mathdotnet.com/api/MathNet.Numerics.Distributions/Normal.htm
// https://www.csharpcodi.com/csharp-examples/?api=mathnet.Numerics.distributions
//https://github.com/mathnet/mathnet-numerics/blob/master/examples/examples-csharp/ContinuousDistributions/NormalDistribution.cs
using System;
using System.Collections.Generic;
namespace PPLNS
{
//============================================================
  public class Distributions : AbstractClass
  {
    PPL_Normal normal = null;
    PPL_StudentT studentT = null;
    PPL_ChiSquared chiSquared = null;
    PPL_FisherSnedecor fisherSnedecor = null;

    public Distributions(PPL ppl)
    {
      this.ppl = ppl;
      normal = new (ppl);
      studentT = new (ppl);
      chiSquared = new (ppl);
      fisherSnedecor = new (ppl);
    }
//============================================================
    public void AddToKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, PPL.OperatorDelegate>();
      keyword_dict.Add("help", FuncHelp);
      keyword_dict.Add("Normal", normal.FuncNormal);
      keyword_dict.Add("Normal.CDF", normal.FuncCDF);
      keyword_dict.Add("Normal.Estimate", normal.FuncEstimate);
      keyword_dict.Add("Normal.InvCDF", normal.FuncInvCDF);
      keyword_dict.Add("Normal.IsValidParameterSet", normal.FuncIsValidParameterSet);
      keyword_dict.Add("Normal.PDF", normal.FuncPDF);
      keyword_dict.Add("Normal.PDFLn", normal.FuncPDFLn);
      keyword_dict.Add("Normal.Sample", normal.FuncSample);
      keyword_dict.Add("Normal.Samples", normal.FuncSamples);
      keyword_dict.Add("Normal.WithMeanPrecision", normal.FuncWithMeanPrecision);
      keyword_dict.Add("Normal.WithMeanStdDev", normal.FuncWithMeanStdDev);
      keyword_dict.Add("Normal.WithMeanVariance", normal.FuncWithMeanVariance);
      keyword_dict.Add("Normal.CumulativeDistribution", normal.FuncCumulativeDistribution);
      keyword_dict.Add("Normal.Density", normal.FuncDensity);
      keyword_dict.Add("Normal.DensityLn", normal.FuncDensityLn);
      keyword_dict.Add("Normal.Equals", normal.FuncEquals);
      keyword_dict.Add("Normal.GetHashcode", normal.FuncGetHashcode);
      keyword_dict.Add("Normal.GetType", normal.FuncGetType);
      keyword_dict.Add("Normal.InverseCumulaiveDistribution", normal.FuncInverseCumulaiveDistribution);
      keyword_dict.Add("Normal.ToString", normal.FuncToString);
      keyword_dict.Add("Normal.Entropy", normal.FuncEntropy);
      keyword_dict.Add("Normal.Maximum", normal.FuncMaximum);
      keyword_dict.Add("Normal.Mean", normal.FuncMean);
      keyword_dict.Add("Normal.Median", normal.FuncMedian);
      keyword_dict.Add("Normal.Minimum", normal.FuncMinimum);
      keyword_dict.Add("Normal.Mode", normal.FuncMode);
      keyword_dict.Add("Normal.Precision", normal.FuncPrecision);
      keyword_dict.Add("Normal.RandomSource", normal.FuncRandomSource);
      keyword_dict.Add("Normal.Skeness", normal.FuncSkeness);
      keyword_dict.Add("Normal.StdDev", normal.FuncStdDev);
      keyword_dict.Add("Normal.Variance", normal.FuncVariance);

      keyword_dict.Add("StudentT", studentT.FuncStudentT);
      keyword_dict.Add("StudentT.CDF", studentT.FuncCDF);
      keyword_dict.Add("StudentT.InvCDF", studentT.FuncInvCDF);

      keyword_dict.Add("ChiSquared", chiSquared.FuncChiSquared);
      keyword_dict.Add("ChiSquared.CDF", chiSquared.FuncCDF);
      keyword_dict.Add("ChiSquared.InvCDF", chiSquared.FuncInvCDF);

      keyword_dict.Add("FisherSnedecor", fisherSnedecor.FuncFisherSnedecor);
      keyword_dict.Add("FisherSnedecor.CDF", fisherSnedecor.FuncCDF);
      keyword_dict.Add("FisherSnedecor.InvCDF", fisherSnedecor.FuncInvCDF);

      help_dict.Add("help", "Distributions.help([name])");
      help_dict.Add("Normal.Normal","");
      help_dict.Add("Normal.CDF","");
      help_dict.Add("Normal.Estimate","");
      help_dict.Add("Normal.InvCDF","");
      help_dict.Add("Normal.IsValidParameterSet","");
      help_dict.Add("Normal.PDF","");
      help_dict.Add("Normal.PDFLn","");
      help_dict.Add("Normal.Sample","");
      help_dict.Add("Normal.Samples","");
      help_dict.Add("Normal.WithMeanPrecision","");
      help_dict.Add("Normal.WithMeanStdDev","");
      help_dict.Add("Normal.WithMeanVariance","");
      help_dict.Add("Normal.CumulativeDistribution","");
      help_dict.Add("Normal.Density","");
      help_dict.Add("Normal.DensityLn","");
      help_dict.Add("Normal.Equals","");
      help_dict.Add("Normal.GetHashcode","");
      help_dict.Add("Normal.GetType","");
      help_dict.Add("Normal.InverseCumulaiveDistribution","");
      help_dict.Add("Normal.ToString","");
      help_dict.Add("Normal.Entropy","");
      help_dict.Add("Normal.Maximum","");
      help_dict.Add("Normal.Mean","");
      help_dict.Add("Normal.Median","");
      help_dict.Add("Normal.Minimum","");
      help_dict.Add("Normal.Mode","");
      help_dict.Add("Normal.Precision","");
      help_dict.Add("Normal.RandomSource","");
      help_dict.Add("Normal.Skeness","");
      help_dict.Add("Normal.StdDev","");
      help_dict.Add("Normal.Variance","");

      help_dict.Add("StudentT.StudentT","");
      help_dict.Add("StudentT.CDF","");
      help_dict.Add("StudentT.InvCDF","");

      help_dict.Add("ChiSquared.ChiSquared","");
      help_dict.Add("ChiSquared.CDF","");
      help_dict.Add("ChiSquared.InvCDF","");

      help_dict.Add("FisherSnedecor.FisherSnedecor","");
      help_dict.Add("FisherSnedecor.CDF","");
      help_dict.Add("FisherSnedecor.InvCDF","");

      try
      {
        if (ppl.ImportList.ContainsKey("Distributions") == false)
        {
          foreach (KeyValuePair<string, PPL.OperatorDelegate> pair in keyword_dict)
          {
            ppl.processing.keyword_dict.Add("Distributions." + pair.Key, pair.Value);
          }
          ppl.ImportList.Add("Distributions", this);
        }
      }
      catch (Exception io)
      { }
    }
  }
}
