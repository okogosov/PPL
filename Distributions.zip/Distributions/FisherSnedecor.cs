/***************************************************************
*This code generated with Application ULC.exe                  *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using MathNet.Numerics.Distributions;
using System;
using System.Collections.Generic;
namespace PPLNS
{
  //============================================================
  public class PPL_FisherSnedecor
  {
    PPL ppl = null;
    MathNet.Numerics.Distributions.FisherSnedecor fisherSnedecor = null;
    public PPL_FisherSnedecor(PPL ppl)
    {
      this.ppl = ppl;
    }
    //============================================================
    public bool FuncFisherSnedecor(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_FisherSnedecor.FuncFisherSnedecor";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.FisherSnedecor(d1)(d2)", new object[] { func_name });
        return false;
      }
      try
      {
        double d1, d2;
        if (System.Double.TryParse(parameters[0], out d1) == false)
        {
          ppl.print("Error: [{0}] not digital d1 [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out d2) == false)
        {
          ppl.print("Error: [{0}] not digital d2 [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        fisherSnedecor = new MathNet.Numerics.Distributions.FisherSnedecor(d1, d1, new System.Random());
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name }); 
        return false; 
      }
       return true; 
    }
    //============================================================
    public bool FuncCDF(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Distributions.PPL_FisherSnedecor.FuncCDF";
      if (parameters.Count != 3)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.FisherSnedecor.CDF (d1)(d2)(x)", new object[] { func_name });
        return false;
      }
      try
      {
        double d1, d2, x;
        if (System.Double.TryParse(parameters[0], out d1) == false)
        {
          ppl.print("Error: [{0}] not digital d1 [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out d2) == false)
        {
          ppl.print("Error: [{0}] not digital d2 [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out x) == false)
        {
          ppl.print("Error: [{0}] not digital x [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }
        result = MathNet.Numerics.Distributions.FisherSnedecor.CDF(d1, d2, x).ToString();
      }
      catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncInvCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_FisherSnedecor.FuncInvCDF";
      if (parameters.Count != 3)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.FisherSnedecor.CDF (d1)(d2)(p)", new object[] { func_name });
        return false;
      }
      try
      {
        double d1, d2, p;
        if (System.Double.TryParse(parameters[0], out d1) == false)
        {
          ppl.print("Error: [{0}] not digital d1 [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out d2) == false)
        {
          ppl.print("Error: [{0}] not digital d2 [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out p) == false)
        {
          ppl.print("Error: [{0}] not digital p [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }
        result = MathNet.Numerics.Distributions.FisherSnedecor.InvCDF(d1, d2, p).ToString();
      }
      catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
  }
}
