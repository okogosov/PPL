/***************************************************************
*This code generated with Application ULC.exe                  *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using MathNet.Numerics.Distributions;
using System;
using System.Collections.Generic;
namespace PPLNS
{
  //============================================================
  public class PPL_Normal
  {
    PPL ppl = null;
    MathNet.Numerics.Distributions.Normal normal = null;
    public PPL_Normal(PPL ppl)
    {
      this.ppl = ppl;
    }
    //============================================================
    //Normal(double mean, double stddev, Random randomSource)
    /// <summary>
    /// 
    /// </summary>
    /// <param name="mean"></param>
    /// <param name="stdev"></param>
    /// <returns></returns>
    public bool FuncNormal(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncNormal";
      if ((parameters.Count != 0) && (parameters.Count != 2))
      {
        ppl.print("Error: [{0}] wrong format: Distributions.Normal () | (mean)(stddev)", new object[] { func_name });
        return false;
      }
      try
      {
        if (parameters.Count == 0)
        {
          normal = new MathNet.Numerics.Distributions.Normal();
          return true;
        }
        double mean;
        double stddev;

        if (System.Double.TryParse(parameters[0], out mean) == false)
        {
          ppl.print("Error: [{0}] not digital mean [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out stddev) == false)
        {
          ppl.print("Error: [{0}] not digital stddev [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        normal = new MathNet.Numerics.Distributions.Normal(mean, stddev, new System.Random());
      }
      catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="mean"></param>  double
    /// <param name="stddev"></param> double
    /// <param name="x"></param>      double
    /// <returns></returns>
    /// double = Distributions.Normal.CDF(mean)(stddev)(x);
    // static
    public bool FuncCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncCDF";
      if (parameters.Count != 3)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.Normal.FuncCDF (mean)(stddev)(x)", new object[] { func_name });
        return false;
      }
      try
      {
        double mean, stddev, x;
        if (System.Double.TryParse(parameters[0], out mean) == false)
        {
          ppl.print("Error: [{0}] not digital mean [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out stddev) == false)
        {
          ppl.print("Error: [{0}] not digital stddev [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out x) == false)
        {
          ppl.print("Error: [{0}] not digital x [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }

        result = MathNet.Numerics.Distributions.Normal.CDF(mean, stddev, x).ToString();
      }
      catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    // static
    public bool FuncEstimate(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncEstimate";
      if ((parameters.Count != 0) && (parameters.Count != 2))
      {
        ppl.print("Error: [{0}] wrong format: Distributions.Normal.Estimate () | (mean)(stddev)", new object[] { func_name });
        return false;
      }
      try
       {
        double mean;
        double stddev;

        if (System.Double.TryParse(parameters[0], out mean) == false)
        {
          ppl.print("Error: [{0}] not digital mean [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out stddev) == false)
        {
          ppl.print("Error: [{0}] not digital stddev [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        // code from https://www.csharpcodi.com/csharp-examples/?api=mathnet.Numerics.distributions
        //var original = new Normal(mean, stddev, new Random());
        //var estimated = Normal.Estimate(original.Samples().Take(10000));

        // O.K. code:
        double[] original = { mean,stddev};
        var estimated = Normal.Estimate(original);
        result = String.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}",
          estimated.Entropy, 
          estimated.Maximum, 
          estimated.Mean, 
          estimated.Median, 
          estimated.Minimum,
          estimated.Mode,
          estimated.Precision,
          estimated.Skewness,
          estimated.StdDev,
          estimated.Variance);
      }
      catch (Exception ex) 
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    /// <summary>
    /// 
    /// </summary>
    /// <param name="means"></param>  double
    /// <param name="stddev"></param> double
    /// <param name="p"></param>      double
    /// <returns></returns>
    /// double = Distributions.Normal.InvCDF(mean)(stddev)(p);
    /// static
    public bool FuncInvCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncInvCDF";
      if (parameters.Count != 3)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.Normal.FuncInvCDF (mean)(stddev)(p)", new object[] { func_name });
        return false;
      }
      try
      {
        double mean, stddev, p;
        if (System.Double.TryParse(parameters[0], out mean) == false)
        {
          ppl.print("Error: [{0}] not digital mean [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out stddev) == false)
        {
          ppl.print("Error: [{0}] not digital stddev [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out p) == false)
        {
          ppl.print("Error: [{0}] not digital p [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }

        result = MathNet.Numerics.Distributions.Normal.CDF(mean, stddev, p).ToString();
      }
      catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncIsValidParameterSet(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncIsValidParameterSet";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncPDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncPDF";
       try
       {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncPDFLn(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncPDFLn";
       try
       {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncSample(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncSample";
       try
       {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncSamples(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncSamples";
       try
       {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncWithMeanPrecision(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncWithMeanPrecision";
       try
       {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncWithMeanStdDev(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncWithMeanStdDev";
       try
       {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncWithMeanVariance(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncWithMeanVariance";
       try
       {
          ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncCumulativeDistribution(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncCumulativeDistribution";
       try
       {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncDensity(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncDensity";
       try
       {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncDensityLn(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncDensityLn";
       try
       {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncEquals(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncEquals";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncGetHashcode(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncGetHashcode";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncGetType(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncGetType";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncInverseCumulaiveDistribution(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncInverseCumulaiveDistribution";
       try
       {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncToString(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncToString";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncEntropy(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncEntropy";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncMaximum(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncMaximum";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncMean(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncMean";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncMedian(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncMedian";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncMinimum(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncMinimum";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncMode(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncMode";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncPrecision(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncPrecision";
       try
       {
        ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncRandomSource(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncRandomSource";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncSkeness(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncSkeness";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncStdDev(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncStdDev";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
    //============================================================
    public bool FuncVariance(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_Normal.FuncVariance";
       try
       {
         ppl.print("Warning: [{0}]Under Construction", new object[] { func_name });
       }
       catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
  }
}
