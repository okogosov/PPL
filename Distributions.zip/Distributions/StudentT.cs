/***************************************************************
*This code generated with Application ULC.exe                  *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Collections.Generic;
namespace PPLNS
{
  //============================================================
  public class PPL_StudentT
  {
    PPL ppl = null;
    MathNet.Numerics.Distributions.StudentT studenT = null;
    public PPL_StudentT(PPL ppl)
    {
      this.ppl = ppl;
    }
    //============================================================
    public bool FuncStudentT(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_StudentT.FuncStudentT";
      if ((parameters.Count != 0) && (parameters.Count != 3))
      {
        ppl.print("Error: [{0}] wrong format: Distributions.StudentT() | (location)(scale)(freedom)", new object[] { func_name });
        return false;
      }
      try
      {
        if (parameters.Count == 0)
        {
          studenT = new MathNet.Numerics.Distributions.StudentT();
          return true;
        }
        double location, scale, freedom, x;
        if (System.Double.TryParse(parameters[0], out location) == false)
        {
          ppl.print("Error: [{0}] not digital location [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out scale) == false)
        {
          ppl.print("Error: [{0}] not digital scale [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out freedom) == false)
        {
          ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }
        studenT = new MathNet.Numerics.Distributions.StudentT(location, scale, freedom, new Random());
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name }); 
        return false; 
      }
       return true; 
    }
    //============================================================
    public bool FuncCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_StudentT.FuncCDF";
      if (parameters.Count != 4)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.StudentT.CDF (location)(scale)(freedom)(x)", new object[] { func_name });
        return false;
      }
      try
      {
        double location, scale, freedom, x;
        if (System.Double.TryParse(parameters[0], out location) == false)
        {
          ppl.print("Error: [{0}] not digital location [{1}]", new object[] { func_name, parameters[0] });
          return false;
        }
        if (System.Double.TryParse(parameters[1], out scale) == false)
        {
          ppl.print("Error: [{0}] not digital scale [{1}]", new object[] { func_name, parameters[1] });
          return false;
        }
        if (System.Double.TryParse(parameters[2], out freedom) == false)
        {
          ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[2] });
          return false;
        }
        if (System.Double.TryParse(parameters[3], out x) == false)
        {
          ppl.print("Error: [{0}] not digital x [{1}]", new object[] { func_name, parameters[3] });
          return false;
        }
        result = MathNet.Numerics.Distributions.StudentT.CDF(location, scale, freedom, x).ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}]", new object[] { func_name }); 
        return false; 
      }
       return true; 
    }
    //============================================================
    public bool FuncInvCDF(List<string> parameters, ref string result, Composite node = null)
    {
       string func_name = "Distributions.PPL_StudentT.FuncInvCDF";
      if (parameters.Count != 4)
      {
        ppl.print("Error: [{0}] wrong format: Distributions.StudentT.InvCDF (location)(scale)(freedom)(p)", new object[] { func_name });
        return false;
      }
      try
      {
          double location, scale, freedom, p;
          if (System.Double.TryParse(parameters[0], out location) == false)
          {
            ppl.print("Error: [{0}] not digital location [{1}]", new object[] { func_name, parameters[0] });
            return false;
          }
          if (System.Double.TryParse(parameters[1], out scale) == false)
          {
            ppl.print("Error: [{0}] not digital scale [{1}]", new object[] { func_name, parameters[1] });
            return false;
          }
          if (System.Double.TryParse(parameters[2], out freedom) == false)
          {
            ppl.print("Error: [{0}] not digital freedom [{1}]", new object[] { func_name, parameters[2] });
            return false;
          }
          if (System.Double.TryParse(parameters[3], out p) == false)
          {
            ppl.print("Error: [{0}] not digital p [{1}]", new object[] { func_name, parameters[3] });
            return false;
          }
          result = MathNet.Numerics.Distributions.StudentT.InvCDF(location, scale, freedom, p).ToString();
      }
      catch (Exception ex)
       {
         ppl.print("Error: [{0}]", new object[] { func_name }); 
         return false; 
       }
       return true; 
    }
  }
}
