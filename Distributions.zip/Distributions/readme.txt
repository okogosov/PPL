Normal
	IEnumerable<double> Samples(Random rnd, double mean, double stddev)
	void Samples(Random rnd, Double[] values, double mean, double stddev)
	IEnumerable<double> Samples(double mean, double stddev)
	void Samples(Double[] values, double mean, double stddev)

Normal.Samples(Double[] values)   with mean=1 stddev=1
