﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.InteropServices;

namespace InvokeByName
{
  public class Test
  {
    public Test() { }
    public void FuncA()
    {
      //Console.WriteLine("FuncA");
    }
    public void FuncB()
    {
      //Console.WriteLine("FuncB");
    }
  }
   
  public class Program
  {
    [DllImport("Kernel32.dll")]
    private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);

    [DllImport("Kernel32.dll")]
    private static extern bool QueryPerformanceFrequency(out long lpFrequency);

    static long startTime = -1;
    static long stopTime = 0;
    static long freq = 0;
    static double duration;

    static public bool FuncTest()
    {
      return true;
    }

    delegate bool MethodDelegate();
    static void Main(string[] args)
    { 
      QueryPerformanceFrequency(out freq);
      QueryPerformanceCounter(out startTime);
      Dictionary<string, MethodDelegate> dict = new Dictionary<string, MethodDelegate>();
      dict.Add("Test",FuncTest);

      for (int j = 0; j < 10000000; j++)
         dict["Test"]();    

      QueryPerformanceCounter(out stopTime);
      duration = (double)(stopTime - startTime) / (double)freq;
      Console.WriteLine("duration = {0}", duration);        // duration=0.19sec
      //=================================================

      Test test = new Test();
      MethodInfo testMethod = test.GetType().GetMethod("FuncA");
      QueryPerformanceCounter(out startTime);
      for (int j = 0; j < 10000000; j++)
        testMethod.Invoke(test, new object[] {});

      QueryPerformanceCounter(out stopTime);
      duration = (double)(stopTime - startTime) / (double)freq;

      Console.WriteLine("duration = {0}", duration);   // duration=1.12sec

      Console.WriteLine("Enter any key");
      Console.ReadKey();
    } 
  }
}
