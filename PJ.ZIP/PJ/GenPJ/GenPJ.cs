﻿using System;
using System.IO;
using System.Linq;
using PatternJsonNS;

namespace GenPJ
{
  internal class GenPJ
  {
    static void Main(string[] args)
    {
      string filenamePatterns = "Patterns.json";
      string filenameKeywords = "keywords.json";
      string directory = Directory.GetCurrentDirectory();

      PatternJson pattern_json = new PatternJson(Print);

      string dstDirectory = "";
      bool b = pattern_json.SetDirectory(directory, ref dstDirectory, 4);
      if (!b)
        return;
      filenamePatterns = dstDirectory + "\\Json\\" + filenamePatterns;
      filenameKeywords = dstDirectory + "\\Json\\" + filenameKeywords;

      b = pattern_json.InitFromFiles(filenamePatterns, filenameKeywords);
      if (!b)
        return;

      string genCodeDirectory = dstDirectory + "\\GeneratedCode\\";
      if (Directory.Exists(genCodeDirectory) == false)
        Directory.CreateDirectory(genCodeDirectory);
      pattern_json.CreateKeywordFunctionsCode(genCodeDirectory);
      return;
    }
    //=====================================================
    static void Print(string str, Object[] o = null)
    {
      if (o == null)
      {
        if (str == "")
          System.Console.WriteLine();
        else
          System.Console.WriteLine("{0}", str);
      }
      else
        System.Console.WriteLine(str, o);
      return;
    }
  }
}
