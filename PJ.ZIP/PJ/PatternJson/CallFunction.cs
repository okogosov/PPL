﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;


namespace PatternJsonNS
{
  public partial class PatternJson
  {
      public struct Matching
      {
        public Matching(string[] tokens, int numberDelimiters, int numberVariables, int PatternNumber)
        {
          this.tokens = tokens;
          this.numberDelimiters = numberDelimiters;
          this.numberVariables  = numberVariables;
          this.PatternNumber    = PatternNumber;
        }
        public string[] tokens;
        public int numberDelimiters;
        public int numberVariables;
        public int PatternNumber;
      }

    public string indent = "";
    public int nspaces = 2;
    public bool CallFunction(string input, Statement statement, ref string result, int nesting, KeywordDelegate callback)
    {
      int final_index = 0;
      string stmt = "";
      try
      { 
         if (statement.block == false)
         {
           final_index = input.IndexOf(";");
           stmt = input.Substring(0, final_index);
         }
         else
           stmt = input;
     //    stmt = stmt.Trim();
         stmt = (stmt.Remove(0, statement.keyword.Length));
         List<Matching> listMatching = new List<Matching>();
     
         for (int i = 0; i < statement.patterns.Count; i++)
         {
           int[] indexes = new int[statement.patterns[i].description.Count()];
           string stmt2 = stmt;
           int offset = 0;
           int numberDelimiters = 0;
           int numberVariables = 0;
           for (int k = 0; k < indexes.Length; k++)
           {
             stmt2 = stmt.Substring(offset);
            if (statement.patterns[i].description[k].name == "delimiter")
            {
              int j = SmartIndexOf(stmt2, statement.patterns[i].description[k].value[0]);
              if (j == -1)
              {
                indexes[k] = offset;
              }
              else
              {
                indexes[k] = offset + j;
                offset = indexes[k] + 1;
                numberDelimiters++;
              }
            }
            else
               indexes[k] = offset;
           }
           numberVariables = indexes.Length - numberDelimiters;
           string[] tokens = new string[numberVariables];
           int m = 0;
           for (int k = 0; k < indexes.Length; k++)
           {
              if (statement.patterns[i].description[k].name == "delimiter")
                continue;
              if (k == indexes.Length - 1)
              {
                tokens[m] = stmt.Substring(indexes[k]);
                break;
               }
               else
               {
                 tokens[m] = stmt.Substring(indexes[k], indexes[k + 1] - indexes[k]);
                 m++;
                 continue;
               }
           }
           for(int m2 = 0;m2 < tokens.Length ;m2++)
           {
              if(tokens[m2] ==  null)
              {
                print("Error: [CallFunction] delimiter omitted [{0}]",new object[] { input });
                return false;
              }
           }
           Matching matching = new Matching(tokens, numberDelimiters, numberVariables,i);
           listMatching.Add(matching);
         }
//=======================================
         Matching matching_right = new();
         int max_number_elements = -1;
         for(int n = 0; n < listMatching.Count; n++)
         {
             Matching m = listMatching[n];
             
             if(statement.patterns[m.PatternNumber].description.Length > max_number_elements)
             {
               max_number_elements = statement.patterns[m.PatternNumber].description.Length;
               matching_right = m;
               continue;
             }            
         }
         int jj = 0;
         int PatternNumber = matching_right.PatternNumber;
         Description[] description = new Description[listMatching[PatternNumber].tokens.Length];
         Pattern pattern = statement.patterns[PatternNumber];
         for (int i = 0; i < pattern.description.Length; i++)
         {
           if (pattern.description[i].name == "delimiter")
             continue;
           description[jj].name = pattern.description[i].name;
           description[jj].value = matching_right.tokens[jj];
           jj++;
         } 
         return callback(description, statement, PatternNumber, nesting, ref result);
      }
      catch (Exception ex)
      {
        return false;
      }
      return true;
    }
//==========================================================================================
  }
}