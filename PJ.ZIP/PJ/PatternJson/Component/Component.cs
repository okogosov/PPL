﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using static PatternJsonNS.PatternJson;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.Metadata;

namespace PatternJsonNS
{
  abstract public class Component
  {
    public string name;
    public string value;
    public Composite parent;

    // Constructor
    public Component(string name,string value)
    {
      this.name  = name;
      this.value = value;
    }
    public Component()
    { }
    public abstract void Display(PrintDelegate print, int depth);
  }
  //=======================================================
  public partial class Composite : Component
  {
    public int nesting; 
    public List<Component> children = new List<Component>();
    public Composite(string name, string value = "")
      : base(name, value)
    {
     // if (name == "root")
        nesting = 0;
    }
    //=========================================================
    public  void Add(Component component)
    {
      children.Add(component);
      component.parent = this;
 
      if (component is Composite cc)
      {
        ((Composite)component).nesting = this.nesting + 1;
      }
    }
    //=======================================================
    public Component Last()
    {
      if (children.Count != 0)
        //return children[children.Count - 1];
        return children.Last();
      else
        return null;
    }
    //=======================================================
    public Component First()
    {
      if (children.Count != 0)
        return children[0];
      else
        return null;
    }
    //=======================================================
    public override void Display(PrintDelegate print, int depth=2)
    {
      String str = new String(' ', depth);
      if (value == "")
        print("{0}N{1}\t{2}", new object[] { str, this.nesting, name });
      else
        print("{0}N{1}\t{2,-15}\t[{3}]", new object[] { str, this.nesting, name, value});

      // Recursively display child nodes
      foreach (Component component in children)
      {
        component.Display(print, depth + 2);
      }
    }
  }
  //=========================================================
  //=====================Leaf================================
  public partial class Leaf : Component
  {
      // Constructor
      public Leaf(string name, string value = "")
        : base(name, value)
      {
      }
    //===========================================================
    public override void Display(PrintDelegate print, int depth=2)
    {
      print("{0}{1}", new object[] { new String(' ', depth), value });
    }
  }
}
