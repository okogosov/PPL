﻿using System;

namespace PatternJsonNS
{
  public partial class Composite : Component
  { 
    static string result = "";
    //========================================================
    public bool Traversal(PatternJson pattern_json)
    {      
      try
      {
        foreach (Component component in children)
        {
           if (component.name == "root")
             ((Composite)component).Traversal(pattern_json);
           if (component.name == "")    // notkeyword_text
           {
             pattern_json.NonKeywordProcessing(component, ref result);
             continue;
           }
           Statement stmt = pattern_json.GetStatement(component.name);
           pattern_json.EntryToProcessing(component, ref result);
           if(pattern_json.keyword_dict.ContainsKey(component.name) == false)
           {
            ;
            //======================
           }
           bool b = pattern_json.CallFunction(component.value, stmt, ref result, nesting, pattern_json.keyword_dict[component.name]);           
           if (!b)
           {
            pattern_json.print("Error: [Traversal]");
            return false;
           }
          pattern_json.ExitFromProcessing(component, ref result);
          if (component is Composite cc)
          {
            if (cc.Traversal(pattern_json) == false)
              return false;
            pattern_json.ExitFromBlock(component, ref result);
          }
        }       
      }
      catch (Exception err)
      {
        pattern_json.print("Error: [Traversal] ");
      }
      return true;
    } 
  }
}
