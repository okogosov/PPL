﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PatternJsonNS
{
   public partial class PatternJson
  {
    //================================================================
    public string PJ_GetContents_Old(string input, char start, char end, ref int BeginBlock, ref int EndBlock)
    { //chars 'start' & 'end' are not same characters
      if (start == end)
        return "";
      char[] arr = input.ToCharArray();
      int counter = 0;
      string result = "";
      int index = -1;
      EndBlock = 0;
      int nquoutes = 0;
      foreach (char c in arr)
      {
        index++;
        if (c == '\"')
          nquoutes++;
        if (nquoutes % 2 != 0)
          continue;
        if (c == start)
        {
          if (counter == 0)
            BeginBlock = index;
          counter++;
          continue;
        }
        if (c == end)
        {
          counter--;
          if (counter == 0)
          {
            EndBlock = index; // - 1;
            break;
          }
          continue;
        }
      }
      if ((EndBlock == 0) || (BeginBlock >= EndBlock)) // no block
        return "";
      result = input.Substring(BeginBlock + 1, EndBlock - BeginBlock - 1);
      //EndBlock++;
      return result;
    }
    //================================================================
    // additional processing string in quotes
    // EndBlock - next position after 'end'
    public string PJ_GetContents(string input0, char start, char end, ref int BeginBlock, ref int EndBlock)
    {
      string input = input0;
      List<string> quotedText = new();
      string qt = "";
      int qtBegin = 0;
      int qtEnd = 0;
      string decorator = ((char)0x2665).ToString(); //0x000F;   //♥ 

      input = input.Replace("\\\"", decorator + "ETOUQ" + decorator);
      input = input.Replace("\"\"", decorator + "SETOUQ2" + decorator);

      //================================
      if (start == end)
      {
        EndBlock = -2;   // chars 'start' & 'end' are not same characters
        return "";
      }
      char[] arr = input.ToCharArray();
      bool inQuotes = false;
      char c;
      int index = 0;
      // Create quotedText list and replace in input saved quottedText  on numbers in list
      while (true)
      {
        if (index == arr.Length)
          break;
        c = arr[index];
        if (c == '\"')
        {
          if (!inQuotes)
          {
            qt = "";
            qtBegin = index;
          }
          inQuotes ^= true;
          qt += c;
          if (!inQuotes)
          {
            qtEnd = index;
            string src = input.Substring(qtBegin, qtEnd - qtBegin + 1);
            string dst = decorator + quotedText.Count + decorator;
            quotedText.Add(qt);
            input = input.Replace(src, dst);
            arr = input.ToCharArray();
            index = input.IndexOf(dst) + dst.Length;
            continue;
          }
          index++;
          continue;
        }
        if (index < arr.Length - 1)
        {
          if ((c == '\\') && (arr[index + 1] == '\"'))
          {
            qt += c;
            qt += arr[index + 1];
            index += 2;
            continue;
          }
        }
        if (!inQuotes)
        {
          index++;
          continue;
        }
        qt += c;
        index++;
      }
      //=======================
      //   processing text between start and end
      bool inContents = false;
      int counter = 0;
      EndBlock = 0;

      StringBuilder sb = new();
      for (index = 0; index < arr.Length; index++)
      {
        c = arr[index];
        if (inContents)
          sb.Append(c);
        if (c == start)
        {
          if (counter == 0)
            inContents = true;
          counter++;
        }
        if (c == end)
        {
          counter--;
          if (counter == 0)
          {
            sb.Remove(sb.Length - 1, 1);
            break;
          }
        }
      }
      string result = sb.ToString();
      if (result == "")
      {        // ()    empty contents
        EndBlock = index + 1;
        return "";  // no char contents end
      }
      string tmp;
      // Replace in input numbers in list on saved quotedText
      //=========================================================
      // it is other right decision
      //int delta = 0;   
      //for (int i = 0; i < quotedText.Count; i++)
      //{
      //  tmp = decorator + i.ToString() + decorator;
      //  if (result.Contains(tmp))
      //  {
      //    result = result.Replace(tmp, quotedText[i]);
      //    delta += quotedText[i].Length - tmp.Length;
      //  }
      //}
      //EndBlock = delta + index + 1; 
      //=========================================================

      for (int i = 0; i < quotedText.Count; i++)
      {
        tmp = decorator + i.ToString() + decorator;
        if (result.Contains(tmp))
        {
          result = result.Replace(tmp, quotedText[i]);
        }
      }

      result = result.Replace(decorator + "ETOUQ" + decorator, "\\\"");
      result = result.Replace(decorator + "SETOUQ2" + decorator, "\"\"");

      tmp = start + result + end;
      BeginBlock = input0.IndexOf(tmp);
      EndBlock   = BeginBlock + result.Length + 1;
      //if(EndBlock == input0.Length)
      //{
      //  EndBlock = 0;    // end
      //  result = "";
      //}
      if ((EndBlock > input0.Length) && (result.Length > 0))
      {
        EndBlock = -1;    // char end is omitted
        result = "";
      }
      return result;
    }
    //================================================================
  }
}
