﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PatternJsonNS
{
   public partial class PatternJson
  {
    //================================================================
    public string GetContents(string input, char start, char end, ref int BeginBlock, ref int EndBlock)
    { //chars 'start' & 'end' are not same characters
      if (start == end)
        return "";
      char[] arr = input.ToCharArray();
      int counter = 0;
      string result = "";
      int index = -1;
      //int BeginBlock = 0;
      EndBlock = 0;
      int nquoutes = 0;
      foreach (char c in arr)
      {
        index++;
        if (c == '\"')
          nquoutes++;
        if (nquoutes % 2 != 0)
          continue;
        if (c == start)
        {
          if (counter == 0)
            BeginBlock = index;
          counter++;
          continue;
        }
        if (c == end)
        {
          counter--;
          if (counter == 0)
          {
            EndBlock = index; // - 1;
            break;
          }
          continue;
        }
      }
      if ((EndBlock == 0) || (BeginBlock >= EndBlock)) // no block
        return "";
      result = input.Substring(BeginBlock + 1, EndBlock - BeginBlock - 1);
      //EndBlock++;
      return result;
    }
    //================================================================
  }
}
