﻿using System;


namespace PatternJsonNS
{
  public partial class PatternJson
  {
    public bool LinkPatternsToKeywords()
    {
      foreach (Keyword keyword in Keywords)
      {
        bool b = AddPatternsToKeyword(keyword.name, keyword.block, keyword.patterns);
        if (!b)
          return false;
      }
      return true;
    }    
  }
}