﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;



namespace PatternJsonNS
{
  public struct Description
  {
    public string name;
    public string value;
    public int patern_index;
  }
  //=========================================================
  public class Statement
  {
    public Statement(string keyword, bool block = false)
    {
      this.keyword = keyword;
      this.block = block;
      patterns = new List<Pattern>();
    }

    public string keyword;
    public bool block;
    public List<Pattern> patterns;
  }
  //=========================================================
  public class Pattern
  {
    public string name;
    public Description[] description;
    public int numberDelimiters;
    public int numberVariables;
  }
  //=========================================================
  public class Keyword
  {
    public string name;
    public bool block;
    public string[] patterns;
  }
  //=========================================================
  public partial class PatternJson
  {
    //=======================================================
    public string result_code = "";
    public delegate void PrintDelegate(string str, object[] o = null);
    public delegate bool KeywordDelegate(Description[] description, Statement stmt, int pattern_index, int nesting, ref string result);
    //========================================================
    public PatternJson(PrintDelegate print)
    {
      Statements = new List<Statement>();
      keyword_dict = new Dictionary<string, KeywordDelegate>();
      this.print = print;
    }
    public PrintDelegate print;
    public List<Pattern> Patterns;
    public List<Keyword> Keywords;
    public List<Statement> Statements;
    public Dictionary<string, KeywordDelegate> keyword_dict;
    public List<string> keyList = null;
    //========================================================
    public Statement GetStatement(string keyword)
    {
      for (int i = 0; i < Statements.Count; i++)
      {
        Statement statement = Statements[i];
        if (statement.keyword == keyword)
          return statement;
      }
      return null;
    }
    //========================================================
    public Pattern GetPattern(string name)
    {
      for (int i = 0; i < Patterns.Count; i++)
      {
        Pattern pattern = Patterns[i];
        if (pattern.name == name)
          return pattern;
      }
      return null;
    }
    //========================================================
    public bool AddPatternsToKeyword(string keyword, bool block,  string[] list)
    {
      Statement stmt_var = new Statement(keyword, block);
      for (int i = 0; i < list.Length; i++)
      {
        Pattern p = GetPattern(list[i]);
        if(p == null)
        {
          print("Error: [AddPatternsToKeyword]  [{0}]", new object[] { list[i] });
          return false;
        }
        stmt_var.patterns.Add(p);
      }
      Statements.Add(stmt_var);
      return true;
    }
    //========================================================
    string json_patterns  = "";
    string jsons_keywords = "";
    public bool ReadPatternsFromFile(string filename)
    {
      string curDir = Environment.CurrentDirectory + "\\";
      string path = "Json\\";
      string filenamePatterns = curDir + path + filename;
      try
      {
        if (File.Exists(filenamePatterns) == false)
        {
          print("Error: [ReadPatternsFromFile] file [{0}] not found", new object[] { filename });
          return false;
        }
        json_patterns = File.ReadAllText(filenamePatterns);

        Patterns = JsonConvert.DeserializeObject<List<Pattern>>(json_patterns);
        for (int i = 0; i < Patterns.Count; i++)
        {
          for (int j = 0; j < Patterns[i].description.Length; j++)
          {
            if (Patterns[i].description[j].name == "delimiter")
              Patterns[i].numberDelimiters++;
            else
              Patterns[i].numberVariables++;
          }
        }
      }
      catch(Exception ex)
      {
         print("Error: [ReadPatternsFromFile] errors in file [{0}]  {1}", new object[]{filename, ex.Message});
         return false;
      }
       return true;
    }
    //========================================================
    public bool ReadPatternsFromString(string json)
    {
      try
      {
        Patterns = JsonConvert.DeserializeObject<List<Pattern>>(json);
        for (int i = 0; i < Patterns.Count; i++)
        {
          for (int j = 0; j < Patterns[i].description.Length; j++)
          {
            if (Patterns[i].description[j].name == "delimiter")
              Patterns[i].numberDelimiters++;
            else
              Patterns[i].numberVariables++;
          }
        }
      }
      catch (Exception ex)
      {
        print("Error: [ReadPatternsFromString] {0}", new object[] { ex.Message });
        return false;
      }
      return true;
    }
    //========================================================
    public bool ReadKeywordsFromFile(string filename)
    {
      string curDir = Environment.CurrentDirectory + "\\";
      string path = "Json\\";
      string filenameKeywords = curDir + path + filename;
      try
      {
        if (File.Exists(filenameKeywords) == false)
        {
          print("Error: [ReadKeywordsFromFile] file [{0}] not found", new object[] { filename });
          return false;
        }
        jsons_keywords = File.ReadAllText(filenameKeywords);
        Keywords = JsonConvert.DeserializeObject<List<Keyword>>(jsons_keywords);
      }
      catch (Exception ex)
      {
        print("Error: [ReadKeywordsFromFile] errors in file [{0}]  {1}", new object[] { filename, ex.Message });
        return false;
      }
      return true;
    }   
    //========================================================
    public bool ReadKeywordsFromString(string json)
    {
      try
      {
        Keywords = JsonConvert.DeserializeObject<List<Keyword>>(json);
      }
      catch (Exception ex)
      {
        print("Error: [ReadKeywordsFromString] {0}", new object[] { ex.Message });
        return false;
      }
      return true;
    }
    //========================================================
    //recursive
    public bool CreateStatementTree(ref string input, ref Composite current_node)
    {
      string keyword = "";
      int final_index = 0;
      int input_index = 0;
      char[] arrch = input.ToCharArray();
      string nonkeyword_text = "";
      for (int i = 0; i < arrch.Length; i++)
      {
        char ch = arrch[i];
        nonkeyword_text += ch.ToString();
        if (ch == ';')
        {
           if(nonkeyword_text.Length > 0)
           {
              nonkeyword_text = nonkeyword_text.Trim();
             // nonkeyword_text = nonkeyword_text.Remove(nonkeyword_text.Length - 1);
              current_node.Add(new Leaf("", nonkeyword_text));
              nonkeyword_text = "";
              keyword = "";
              
              final_index = i;
              input = input.Remove(0, final_index + 1);
              input_index += final_index + 1;
              arrch = input.ToCharArray();
              i = -1;
              continue;
           }
        }
        if (Char.IsWhiteSpace(ch))
          continue;
        keyword += ch.ToString();
        if (keyword_dict.ContainsKey(keyword) == false)
          continue;
        nonkeyword_text = "";
        Statement stmt = GetStatement(keyword);
        if (stmt.block == false)
        {
          final_index = input.IndexOf(";");
          if(final_index == -1)
          {
            print("Error: [CreateStatementTree] omitted ';'  keyword  [{0}], position [{1}]", new object[]{keyword,input_index});
            return false;
          }
          string tmp = input.Substring(0, final_index + 1);
          tmp = tmp.Trim();
          int keyword_counter = 0;
          for(int k = 0; k < keyList.Count; k++)
          {
            if (tmp.Contains(keyList[k]))
              keyword_counter++;         
          }
          string tmp2 = tmp.Substring(keyword.Length);
          if (tmp2.Contains(keyword))   // is exist keyword twice?
            keyword_counter++;
          if (keyword_counter > 1)
          {
            print("Error: [CreateStatementTree] omitted ';'  keyword  [{0}], position [{1}]", new object[] { keyword, input_index });
            return false;
          }
          current_node.Add(new Leaf(keyword, tmp));
          keyword = "";
          input = input.Remove(0, final_index + 1);
          input_index += final_index + 1;
          arrch = input.ToCharArray();
          i = -1;
          continue;
        }
        if (stmt.block == true)
        {
          int BeginBlock = 0;
          int EndBlock = 0;
          string block_contents = GetContents(input, '{', '}', ref BeginBlock, ref EndBlock);
          string before_block = input.Substring(0, BeginBlock).Trim();
          Composite comp = new Composite(keyword, before_block);
          current_node.Add(comp);
          current_node = comp;

          bool b = CreateStatementTree(ref block_contents, ref current_node);
          if(!b)
            return false;
          current_node = current_node.parent;
          input = input.Remove(0, EndBlock + 1);
          arrch = input.ToCharArray();
          i = -1;
          keyword = "";
          continue;
        }
      }
      nonkeyword_text = nonkeyword_text.Trim();
      if (nonkeyword_text.Length > 0)
      {
        print("Error: [CreateStatementTree] omitted ';' in [{0}]",new object[]{nonkeyword_text});
        return false;
      }
      return true;
    }
    //==========================================================================================
    public delegate bool dlgt_Decoration(Component comp, ref string result);    
    public dlgt_Decoration funcEntryToProcessing;
    public dlgt_Decoration funcExitFromProcessing;
    public dlgt_Decoration funcExitFromBlock;
    public dlgt_Decoration funcNonKeywordProcessing;
    public void ExitFromProcessing(Component comp, ref string result)
    {
      if(funcExitFromProcessing == null)
      {
        print("Warning: [ExitFromProcessing] ExitFromProcessing is not defined");
      }
      else
        funcExitFromProcessing(comp, ref result);
    }
    //==========================================================================================
    public void EntryToProcessing(Component comp, ref string result)
    {
      if (funcEntryToProcessing == null)
      {
        this.print("Warning: [EntryToProcessing] funcEntryToProcessing is not defined");
      }
      else
        funcEntryToProcessing(comp, ref result);
    }
    //==========================================================================================
    public void ExitFromBlock(Component comp, ref string result)
    {
      if (funcExitFromProcessing == null)
      {
        this.print("Warning: [ExitFromBlock] funcExitFromBlock is not defined");
      }
      else
        funcExitFromBlock(comp, ref result);
    }
    //==========================================================================================
    public void NonKeywordProcessing(Component comp, ref string result)
    {
      if (funcNonKeywordProcessing == null)
      {
        this.print("Warning: [NonKeywordProcessing] funcExitFromBlock is not defined");
      }
      else
        funcNonKeywordProcessing(comp, ref result);
    }
  }
}