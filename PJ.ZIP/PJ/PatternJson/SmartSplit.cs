﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;

namespace PatternJsonNS
{
  public partial class PatternJson
  { // not processing contents in quotes
    public string[] SmartSplit(string input, char[] separators)
    {
      List<string> list = new();
      string t = "";
      bool b = false;
      string tmp = input;
      char[] arr = tmp.ToCharArray();
      bool inquotes = false;
      bool IsChar(char[] arrchar, char ch)
      {
        for (int i = 0; i < arrchar.Length; i++)
        {
          if (arrchar[i] == ch)
          {
            return true;
          }
        }
        return false;
      }
      for (int i = 0; i < arr.Length; i++)
      {
        if (arr[i] == '\"')
        {
          inquotes ^= true;
          t += arr[i].ToString();
          continue;
        }
        if (inquotes == true)
        {
          t += arr[i].ToString();
          continue;
        }
        else
        {
          if (IsChar(separators, arr[i]))
          {
            /*if (t != "")
            {
              //t = t.Replace("space", "\"\"");
              //if (b)
              //  t = t.Replace("space", "\" \"");
              //
              list.Add(t);
              t = "";
            }*/

            list.Add(t);   //  empty value => 1,,3
            t = "";
            continue;
          }
          else
          {
            t += arr[i];
            continue;
          }
        }
      }
      if (t != "")
      {
        //t = t.Replace("space", "\"\"");
        //if (b)
        //  t = t.Replace("space", "\" \"");
        list.Add(t);
        t = "";
      }

      return list.ToArray();
    }
    //==============================================================
    public string SmartReplace(string input, string src, string dst)
    {
      char[] array = input.ToCharArray();
      StringBuilder sb = new StringBuilder();
      string result = "";
      bool inQuote = false;
      char ch;
      for (int j = 0; j < array.Length; j++)
      {
        ch = array[j];
        if (ch == '\"')
        {
          inQuote = !inQuote;
          sb.Append(ch);
          continue;
        }
        if ((inQuote) && (ch == '\\') && (array[j + 1] == '\"'))
        {
          sb.Append(ch);
          sb.Append(array[j + 1]);
          j++;
          continue;
        }
        if ((inQuote) && (ch == '\\') && (array[j + 1] == '\\'))
        {
          sb.Append(ch);
          sb.Append(array[j + 1]);
          j++;
          continue;
        }
        if (!inQuote)
        {
          if (j + src.Length > input.Length)
          {
            sb.Append(ch);
            continue;
          }
          else
          {
            string tmp = "";
            for (int i = j; i < j + src.Length; i++)
            {
              tmp += array[i].ToString();
            }
            if (tmp == src)
            {
              j += src.Length - 1;
              for (int n = 0; n < dst.Length; n++)
                sb.Append(dst[n]);
            }
            else
              sb.Append(ch);
            continue;
          }
        }
        sb.Append(ch);
        continue;
      }
      result = sb.ToString();
      return result;
    }
    //==============================================================
    public bool SmartIsExist(string input, string src)
    {
      char[] array = input.ToCharArray();
      bool inQuote = false;
      char ch;
      for (int j = 0; j < array.Length; j++)
      {
        ch = array[j];
        if (ch == '\"')
        {
          inQuote = !inQuote;
          continue;
        }
        if ((inQuote) && (ch == '\\') && (array[j + 1] == '\"'))
        {
          j++;
          continue;
        }
        if ((inQuote) && (ch == '\\') && (array[j + 1] == '\\'))
        {
          j++;
          continue;
        }
        if (!inQuote)
        {
          if (j + src.Length > input.Length)
            continue;
          else
          {
            string tmp = "";
            for (int i = j; i < j + src.Length; i++)
            {
              tmp += array[i].ToString();
            }
            if (tmp == src)
            {
              return true;
            }
            continue;
          }
        }
        continue;
      }
      return false;
    }
    //==============================================================
    public int SmartIndexOf(string input, char ch0)
    {
      bool inQuote = false;
      char ch;
      for (int i = 0; i < input.Length; i++)
      {
        ch = input[i];
        if (ch == '\"')
        {
          inQuote = !inQuote;
          continue;
        }
        if ((inQuote) && (ch == '\\') && (input[i + 1] == '\"'))
        {
          i++;
          continue;
        }
        if ((inQuote) && (ch == '\\') && (input[i + 1] == '\\'))
        {
          i++;
          continue;
        }
        if (ch == ch0)
        {
          if (inQuote)
            continue;
          return i;
        }
        if (ch == ';')
        {
          if (inQuote)
            continue;
          return -1;
        }
      }
      return -1;
    }

    //==============================================================
    //   Counts: for  1,2,3,,5 five elements
    public string[] SplitCsv(string input, char separator)
    {
      // separator - not whitespace
      List<string> result = new();
      StringBuilder currentStr = new StringBuilder("");
      bool inQuotes = false;
      string tmp = "";
      for (int i = 0; i < input.Length; i++)
      {
        if (input[i] == '\"')
        {
          inQuotes = !inQuotes;
          currentStr.Append(input[i]);
          continue;
        }
        else if (input[i] == separator)
        {
          if (!inQuotes) // If not in quotes, end of current string, add it to result
          {
            tmp = currentStr.ToString().Trim();
            /////////if (tmp.Length > 0)
              result.Add(tmp);
            currentStr.Clear();
          }
          else
            currentStr.Append(input[i]); // If in quotes, just add it 
        }
        else // Add any other character to current string
        {
          currentStr.Append(input[i]);
        }
      }
      tmp = currentStr.ToString().Trim();
      /////////if (tmp.Length > 0) 
        result.Add(tmp);
      return result.ToArray();
    }
    //==========Test============================================
    /*string[] tokens = SplitCsv("set x = 2;;write(\"{0}\",x);", ';');
    Writearray<string>(tokens);
    string text = "\"first_line, one\",  3,4,\"second_line, two\", 7,8,\"third_line, three\",  9,10,\"fourth_line\", 11,12,13,14,15,\"16,17,18\",19,20";
    string[] tokens2 = SplitCsv(text, ',');
    Writearray<string>(tokens2);*/
  }
}
