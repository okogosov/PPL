This project is illustration of PPL Preprocessor:
	converts  file.scr   to file.ppl in accordance with grammar, 
	defined in files Patterns.json & Keywords.json
SolutionPJ includes 3 projects:
1.PatternJson.dll
	Dependencies: Newtonsoft.Json
2.GenPJ.exe
	Dependencies: Newtonsoft.Json,PatternJson.dll
	Reads files Json/Patterns.json & Json/Keywords.json
	and creates the following files (skeleton files ):
		GeneratedCode\
                        PJ.cs
			FuncArray.cs
			FuncFor.cs
			FuncFunction.cs
			FuncSet.cs
			FuncVar.cs
			KeywordFunctions.cs


3.PJ.exe
	Dependencies: Newtonsoft.Json,PatternJason.dll
	All files in GeneratedCode (see p.2) added to project PJ
	with fulfillment code.
	Reads file testpj.scr
	and 	creates file ResultCode.ppl