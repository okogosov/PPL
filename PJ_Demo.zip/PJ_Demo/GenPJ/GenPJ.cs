﻿using System;
using PatternJsonNS;

namespace GenPJ
{
  internal class GenPJ
  {
    static void Main(string[] args)
    {
      string filenamePatterns = "Patterns.json";
      string filenameKeywords = "keywords.json";

      PatternJson pattern_json = new PatternJson(Print);
      if (pattern_json.ReadPatternsFromFile(filenamePatterns) == false)
        return;
      if (pattern_json.ReadKeywordsFromFile(filenameKeywords) == false)
        return;

      if (pattern_json.LinkPatternsToKeywords() == false)
      {
        Console.WriteLine("Error:");
        return;
      }
      pattern_json.CreateKeywordFunctionsCode();
      return;
    }
    //=====================================================
    static void Print(string str, Object[] o = null)
    {
      if (o == null)
      {
        if (str == "")
        {
          System.Console.WriteLine();
        }
        else
        {
          System.Console.WriteLine("{0}", str);
        }
      }
      else
        System.Console.WriteLine(str, o);
      return;
    }
  }
}
