﻿using System;
using System.IO;
using PatternJsonNS;

namespace PJ
{
  class Program
  {
    static void Main(string[] args)
    {
      string filename;
      if (args.Length == 0)
      {
        //Console.WriteLine("usage: pj <filename>");
        //return;
        filename = "testpj.scr";
      }
      else
         filename = args[0];
      if (File.Exists(filename) == false)
      {
        Print("Error: [PJ.Main] file [{0}] not found", new object[] { filename });
        return;
      }
      string input = File.ReadAllText(filename);
      
      string filename_Patterns = "Patterns.json";
      string filename_Keywords = "keywords.json";
      bool read_json_fromFile_flag = true;      
      PatternJson pattern_json = new PatternJson(Print);
      KeywordFunctions keywordFunctions = new KeywordFunctions(pattern_json);
      if (read_json_fromFile_flag)
        keywordFunctions.InitFromFiles(filename_Patterns, filename_Keywords);
      else
      {
        #region
        // or
        string curDir = Environment.CurrentDirectory + "\\";
        string path = "Json\\";
        filename_Patterns = curDir + path + filename_Patterns;
        string json_patterns;
        if (File.Exists(filename_Patterns) == false)
        {
          Print("Error: [Main] file [{0}] not found", new object[] { filename_Patterns });
          return;
        }
        string jpatterns = File.ReadAllText(filename_Patterns);

        filename_Keywords = curDir + path + filename_Keywords;
        if (File.Exists(filename_Keywords) == false)
        {
          Print("Error: [Main] file [{0}] not found", new object[] { filename_Keywords });
          return;
        }
        string jkeywords = File.ReadAllText(filename_Keywords);
        keywordFunctions.InitFromString(jpatterns, jkeywords);
#endregion
      }

      Composite root = new("root");
      Composite current_node = root;
      Print(input);
      Print();
      if(pattern_json.CreateStatementTree(ref input, ref current_node) == false)
        return;

      if (root.Traversal(pattern_json) == false)
        return;
     // CheckParentheses(pattern_json.result_code);
      Print("{0}", new object[] { pattern_json.result_code });
      root.Display(Print);
      File.WriteAllText("ResultCode.ppl",pattern_json.result_code);
    }
    //=====================================================
    static void CheckParentheses(string input)
    {
      int count = 0;
      for(int i = 0; i < input.Length;i++)
      {
        if(input[i] == '(')
          count++;
        if (input[i] == ')')
          count--;
      }
      Console.WriteLine("CheckParentheses {0}", count);
      return ;
    }
    //=====================================================
    static void Print(string str = "", Object[] o = null)
    {
      if (o == null)
      {
        if (str == "")
          System.Console.WriteLine();
        else
          System.Console.WriteLine("{0}", str);
      }
      else
        System.Console.WriteLine(str, o); 
      return;
    }
  }
}