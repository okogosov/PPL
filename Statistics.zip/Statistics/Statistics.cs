﻿/***************************************************************
*This code generated with Application CreateUserLibCode.exe    *
*for creation PPL User Library                                 *
*Add  Project Reference PPL.Lib                                *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/
using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using MathNet.Numerics.Statistics;
//https://numerics.mathdotnet.com/api/MathNet.Numerics.Statistics/ArrayStatistics.htm
/*
4-quantiles are called quartiles.
5-quantiles are called quintiles.
8-quantiles are called octiles.
10-quantiles are called deciles.
100-quantiles are called percentiles.
 */
namespace PPLNS
{
  public class Statistics : AbstractClass
  {
    //  ppl & help_dict in Abstract Class
    //public PPL ppl;
    //Dictionary<string, string> help_dict = new Dictionary<string, string>();
    public Statistics(PPL ppl)
    {
      this.ppl = ppl;
    }
    public void AddToKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, PPL.OperatorDelegate>();
      keyword_dict.Add("help", FuncHelp);

      keyword_dict.Add("Covariance", FuncCovariance);
      keyword_dict.Add("FiveNumberSummary", FuncFiveNumberSummary);
      keyword_dict.Add("GMean", FuncGMean);
      keyword_dict.Add("HMean", FuncHMean);
      //keyword_dict.Add("InterquartileRange", FuncInterquartileRange);
      //keyword_dict.Add("LowerQuartile", FuncLowerQuartile);
      keyword_dict.Add("Maximum", FuncMaximum);
      //keyword_dict.Add("MaximumAbsolute", FuncMaximumAbsolute);
      ///keyword_dict.Add("MaximumMagnitudePhase", FuncMaximumMagnitudePhase);
      keyword_dict.Add("Mean", FuncMean);
      keyword_dict.Add("MeanStandardDeviation", FuncMeanStandardDeviation);
      //keyword_dict.Add("MeanVariance", FuncMeanVariance);
      keyword_dict.Add("Median", FuncMedian);
      keyword_dict.Add("Minimum", FuncMinimum);
      //keyword_dict.Add("MinimumAbsolute", FuncMinimumAbsolute);
      //keyword_dict.Add("MinimumMagnitudePhase", FuncMinimumMagnitudePhase);
      keyword_dict.Add("OrderStatistic", FuncOrderStatistic);
      keyword_dict.Add("Percentile", FuncPercentile);
      keyword_dict.Add("PopulationCovariance", FuncPopulationCovariance);
      keyword_dict.Add("PopulationStandardDeviation", FuncPopulationStandardDeviation);
      keyword_dict.Add("PopulationVariance", FuncPopulationVariance);
      keyword_dict.Add("QuantileCustom", FuncQuantileCustom);
      keyword_dict.Add("Quantile", FuncQuantile);
      keyword_dict.Add("Ranks", FuncRanks);
      keyword_dict.Add("RootMeanSquare", FuncRootMeanSquare);
      keyword_dict.Add("StandardDeviation", FuncStandardDeviation);
      //keyword_dict.Add("UpperQuartile", FuncUpperQuartile);
      keyword_dict.Add("Variance", FuncVariance);

      //help_dict.Add("Max", "\tStatistics.GMean(\"ppl_array\")");
      help_dict.Add("help", "\tStatistics.help([name])");
      help_dict.Add("Covariance", "\tStatistics.FuncCovariance(\"sample1\")(\"sample2\")");
      help_dict.Add("FiveNumberSummary", "\tStatistics.FuncFiveNumberSummary(\"sample_name\")(\"result_array5\")");
      help_dict.Add("GMean", "\tStatistics.GMean(\"array_ppl\")");
      help_dict.Add("HMean", "\tStatistics.HMean(\"array_ppl\")");
      //help_dict.Add("InterquartileRangeInplace", "");
      //help_dict.Add("LowerQuartileInplace", "");
      help_dict.Add("Maximum", "\tStatistics.Maximum(\"array_ppl\")");
      //help_dict.Add("MaximumAbsolute", "");
      //help_dict.Add("MaximumMagnitudePhase", "");
      help_dict.Add("Mean", "\tStatistics.Mean(\"array_ppl\")");
      help_dict.Add("MeanStandardDeviation", "\tStatistics.MeanStandardDeviation(\"array_ppl\")");
      //help_dict.Add("MeanVariance", "");
      help_dict.Add("Median", "\tStatistics.Median(\"array_ppl\")");
      help_dict.Add("Minimum", "\tStatistics.Minimum(\"array_ppl\")");
      //help_dict.Add("MinimumAbsolute", "");
      //help_dict.Add("MinimumMagnitudePhase", "");
      help_dict.Add("OrderStatistic", "\tStatistics.OrderStatistic(\"array_ppl\")(order)");
      help_dict.Add("Percentile", "\tStatistics.Percentile(\"array_ppl\")(selector)");
      help_dict.Add("PopulationCovariance", "\tStatistics.FuncCovariance(\"sample1\")(\"sample2\")");
      help_dict.Add("PopulationStandardDeviation", "\tStatistics.PopulationStandardDeviation(\"array_ppl\")");
      help_dict.Add("PopulationVariance", "\tStatistics.PopulationVariance(\"array_ppl\")");
      help_dict.Add("QuantileCustom", "\tStatistics.QuantileCustom(\"array_ppl\")(tau)(definition)");
      help_dict.Add("Quantile", "\tStatistics.Quantile(\"array_ppl\")(tau)");
      help_dict.Add("Ranks", "\tStatistics.Ranks(\"array_ppl\")(\"rank_array_ppl\")(definition)");
      help_dict.Add("RootMeanSquare", "\tStatistics.RootMeanSquare(\"array_ppl\")");
      help_dict.Add("StandardDeviation", "\tStatistics.StandardDeviation(\"array_ppl\")");
      //help_dict.Add("UpperQuartileInplace", "");
      help_dict.Add("Variance", "\tStatistics.Variance(\"array_ppl\")");


      try
      {
        if (ppl.ImportList.ContainsKey("Statistics") == false)
        {
          foreach (KeyValuePair<string, PPL.OperatorDelegate> pair in keyword_dict)
          {
            ppl.processing.keyword_dict.Add("Statistics." + pair.Key, pair.Value);
          }
          ppl.ImportList.Add("Statistics", this);
        }
      }
      catch (Exception io)
      { }
    }
    //==========================================================
    public bool FuncCovariance(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncCovariance";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.FuncCovariance(\"sample1\")(\"sample2\")", new object[] { func_name });
        return false;
      }
      string sample1 = parameters[0];
      string sample2 = parameters[1];
      Composite cc;
      try
      {
        int length;
        bool b = false;
        double tmp;
        //====================================================
        cc = GetArrayComposite(sample1);
        if (cc == null)
          return false;
        
        length = cc._children.Count;
        double[] arraySample1 = new double[length];
        b = false;
        tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            arraySample1[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, sample1, i, cc._children[i].value });
            return false;
          }
          arraySample1[i] = tmp;
        }
        //====================================================
        cc = GetArrayComposite(sample2);
        if (cc == null)
          return false;

        length = cc._children.Count;
        double[] arraySample2 = new double[length];
        b = false;
        tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            arraySample2[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, sample2, i, cc._children[i].value });
            return false;
          }
          arraySample2[i] = tmp;
        }

        double covariance = MathNet.Numerics.Statistics.Statistics.Covariance(arraySample1, arraySample2);
        result = covariance.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    
    //==========================================================
    public bool FuncFiveNumberSummary(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncFiveNumberSummary";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.FuncFiveNumberSummary(\"sample_name\")(\"result_array5\")", 
           new object[] { func_name });
        return false;
      }
      string sample = parameters[0];
      string result_array5 = parameters[1];
      try
      {
        Composite cc = GetArrayComposite(sample);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }
        cc = GetArrayComposite(result_array5);
        if (cc == null)
          return false;

        double[]  FiveNSI = MathNet.Numerics.Statistics.Statistics.FiveNumberSummary(array);
        for(int i = 0; i < 5;i++)
        {
          cc._children[i].value = FiveNSI[i].ToString();
        }
        
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    
    //==========================================================
    // GeometricMean
    public bool FuncGMean(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncGMean";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.GMean(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double gm = MathNet.Numerics.Statistics.Statistics.GeometricMean(array);
        result = gm.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}] not decimal value in array [{1}]", new object[] { func_name, fullname });
        return false;
      }
      return true;
    }
    //==========================================================
    //HarmonicMean
    public bool FuncHMean(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncHMean";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.HMean(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double hm = MathNet.Numerics.Statistics.Statistics.HarmonicMean(array);
        result = hm.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}] not decimal value in array [{1}]", new object[] { func_name, fullname });
        return false;
      }
      return true;
    }
    //==========================================================
    /*
    public bool FuncInterquartileRange(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {

      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncLowerQuartile(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {

      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    */
    //==========================================================
    public bool FuncMaximum(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncMaximum";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.Maximum(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double max = MathNet.Numerics.Statistics.Statistics.Maximum(array);
        result = max.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}] not decimal value in array [{1}]", new object[] { func_name, fullname });
        return false;
      }
      return true;
    }
    //==========================================================
    /*
    public bool FuncMaximumAbsolute(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {

      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }*/
    //==========================================================
    /*
    public bool FuncMaximumMagnitudePhase(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {

      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }*/
    //==========================================================
    public bool FuncMean(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.Mean";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.Mean(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double gm = MathNet.Numerics.Statistics.Statistics.Mean(array);
        result = gm.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}] not decimal value in array [{1}]", new object[] { func_name, fullname });
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncMeanStandardDeviation(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncMeanStandardDeviation";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.MeanStandardDeviation(\"name\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        //double mean = Statistics.Mean(array);
        var msd = MathNet.Numerics.Statistics.Statistics.MeanStandardDeviation(array);
        result = msd.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}] not decimal value in array [{1}]", new object[] { func_name, fullname });
        return false;
      }
      return true;
    }
    //==========================================================
    /*
    public bool FuncMeanVariance(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {

      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }*/
    //==========================================================
    public bool FuncMedian(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncMedian";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.Median(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double median = MathNet.Numerics.Statistics.Statistics.Median(array);
        result = median.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncMinimum(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncMinimum";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.Minimum(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double min = MathNet.Numerics.Statistics.Statistics.Minimum(array);
        result = min.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: [{0}] not decimal value in array [{1}]", new object[] { func_name, fullname });
        return false;
      }
      return true;
    }
    //==========================================================
    /*
    // error in MinAbs
    public bool FuncMinimumAbsolute(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncMinimumAbsolute";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.MinimumAbsolute(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double min = MathNet.Numerics.Statistics.Statistics.MinimumAbsolute(array);
        result = min.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    */
    //==========================================================
    /*
    public bool FuncMinimumMagnitudePhase(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {

      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }*/
    //==========================================================
    public bool FuncOrderStatistic(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncOrderStatistic";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.OrderStatistic(\"array_ppl\")(order)", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      int order = 0;
      try
      {
        if(Int32.TryParse(parameters[1],out order) == false)
        {
          ppl.print("Error: [{0}] array {1}, order not digital [{2}])",
             new object[] { func_name, parameters[0], parameters[1] });
          return false;
        }
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }
        //???
        double orderstat = MathNet.Numerics.Statistics.Statistics.OrderStatistic(array,order);
        result = orderstat.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncPercentile(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncPercentile";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.Percentile(\"array_ppl\")(selector)", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      int selector;   // 0-100
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;

        if (Int32.TryParse(parameters[1], out selector) == false)
        {
          ppl.print("Error: [{0}] array {1}, order not digital [{2}])",
             new object[] { func_name, parameters[0], parameters[1] });
          return false;
        }
        if ((selector < 0) || (selector >100))
        {
          ppl.print("Error: [{0}] array {1}, selector [{2}] of bounds (0-100)",
             new object[] { func_name, parameters[0], parameters[1] });
          return false;
        }
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double p_Percentile = MathNet.Numerics.Statistics.Statistics.Percentile(array,selector);
        result = p_Percentile.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncPopulationCovariance(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncCovariance";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.FuncCovariance(\"sample1\")(\"sample2\")", new object[] { func_name });
        return false;
      }
      string sample1 = parameters[0];
      string sample2 = parameters[1];
      Composite cc;
      try
      {
        int length;
        bool b = false;
        double tmp;
        //====================================================
        cc = GetArrayComposite(sample1);
        if (cc == null)
          return false;

        length = cc._children.Count;
        double[] arraySample1 = new double[length];
        b = false;
        tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            arraySample1[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, sample1, i, cc._children[i].value });
            return false;
          }
          arraySample1[i] = tmp;
        }
        //====================================================
        cc = GetArrayComposite(sample2);
        if (cc == null)
          return false;

        length = cc._children.Count;
        double[] arraySample2 = new double[length];
        b = false;
        tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            arraySample2[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, sample2, i, cc._children[i].value });
            return false;
          }
          arraySample2[i] = tmp;
        }

        double pop_covariance = MathNet.Numerics.Statistics.Statistics.PopulationCovariance(arraySample1, arraySample2);
        result = pop_covariance.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncPopulationStandardDeviation(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncPopulationStandardDeviation";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.PopulationStandardDeviation(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double pop_standardDeviation = MathNet.Numerics.Statistics.Statistics.PopulationStandardDeviation(array);
        result = pop_standardDeviation.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncPopulationVariance(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncPopulationVariance";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.PopulationVariance(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }
        var pop_var = MathNet.Numerics.Statistics.Statistics.PopulationVariance(array);
        result = pop_var.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    // QuantileDefinition "R1", ... "R9"
    void GetQuantileDefinition(string data, out QuantileDefinition qd)
    {
      switch(data)
      {
        case "R1":
          qd = QuantileDefinition.R1;
          break;
        case "R2":
          qd = QuantileDefinition.R2;
          break;
        case "R3":
          qd = QuantileDefinition.R3;
          break;
        case "R4":
          qd = QuantileDefinition.R4;
          break;
        case "R5":
          qd = QuantileDefinition.R5;
          break;
        case "R6":
          qd = QuantileDefinition.R6;
          break;
        case "R7":
          qd = QuantileDefinition.R7;
          break;
        case "R8":
          qd = QuantileDefinition.R8;
          break;
        case "R9":
          qd = QuantileDefinition.R9;
          break;
        default:
          qd = QuantileDefinition.R8;
          return;
      }
      return;
    }
    public bool FuncQuantileCustom(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncQuantileCustom";
      if (parameters.Count != 3)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.QuantileCustom(\"array_ppl\")(tau)(definition)", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      double selector;   // 0.0-1.0
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;

        if (Double.TryParse(parameters[1], out selector) == false)
        {
          ppl.print("Error: [{0}] array {1}, order not digital [{2}])",
             new object[] { func_name, parameters[0], parameters[1] });
          return false;
        }
        if ((selector < 0) || (selector > 1.0))
        {
          ppl.print("Error: [{0}] array {1}, selector [{2}] of bounds (0-1.0)",
             new object[] { func_name, parameters[0], parameters[1] });
          return false;
        }
        QuantileDefinition qd = QuantileDefinition.R8;
        GetQuantileDefinition(parameters[2],out qd);
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b1 = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b1 = Double.TryParse(cc._children[i].value, out tmp);
          if (b1 == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double quantile_custom = MathNet.Numerics.Statistics.Statistics.QuantileCustom(array, selector,qd);
        result = quantile_custom.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncQuantile(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncQuantile";
      if (parameters.Count != 2)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.Quantile(\"array_ppl\")(tau)", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      double selector;   // 0.0-1.0
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;

        if (Double.TryParse(parameters[1], out selector) == false)
        {
          ppl.print("Error: [{0}] array {1}, order not digital [{2}])",
             new object[] { func_name, parameters[0], parameters[1] });
          return false;
        }
        if ((selector < 0) || (selector > 1.0))
        {
          ppl.print("Error: [{0}] array {1}, selector [{2}] of bounds (0-1.0)",
             new object[] { func_name, parameters[0], parameters[1] });
          return false;
        }
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b1 = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b1 = Double.TryParse(cc._children[i].value, out tmp);
          if (b1 == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double quantile = MathNet.Numerics.Statistics.Statistics.Quantile(array, selector);
        result = quantile.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    void GetRankDefinition(string data, out RankDefinition rd)
    {
      switch (data)
      {
        case "Average":
          rd = RankDefinition.Average;
          break;
        case "Min":
          rd = RankDefinition.Min;
          break;
        case "Max":
          rd = RankDefinition.Max;
          break;
        case "First":
          rd = RankDefinition.First;
          break;
        case "EmpiricalCDF":
          rd = RankDefinition.EmpiricalCDF;
          break;
        default:
          rd = RankDefinition.Default;   // Average
          return;
      }
      return;
    }
    //==========================================================
    // order number in sorted array
    public bool FuncRanks(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncRanks";
      if (parameters.Count != 3)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.Ranks(\"array_ppl\")(\"rank_array_ppl\")(definition)", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;

        RankDefinition rd = RankDefinition.Average;
        //====================================================

        GetRankDefinition(parameters[1], out rd);
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b1 = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b1 = Double.TryParse(cc._children[i].value, out tmp);
          if (b1 == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }
        //====================================================
        cc = GetArrayComposite(parameters[2]);
        if (cc == null)
          return false;
        //====================================================
        double[] ranks = MathNet.Numerics.Statistics.Statistics.Ranks(array, rd);
        string result1 = "";
        List<string> paramR = new List<string>();
        paramR.Add(parameters[2]);
        paramR.Add("");
        paramR.Add(ranks.Length.ToString());
        paramR.Add("");
        ppl.processing.FuncReAllocArray(paramR, ref result1, node);

        for(int i = 0; i < array.Length;i++)
          cc._children[i].value = ranks[i].ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncRootMeanSquare(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncRootMeanSquare";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.RootMeanSquare(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double rms = MathNet.Numerics.Statistics.Statistics.RootMeanSquare(array);
        result = rms.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    public bool FuncStandardDeviation(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncStandardDeviation";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.StandardDeviation(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }

        double standardDeviation = MathNet.Numerics.Statistics.Statistics.StandardDeviation(array);
        result = standardDeviation.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //==========================================================
    /*
    public bool FuncUpperQuartileInplace(List<string> parameters, ref string result, Composite node = null)
    {
      try
      {

      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    */
    //==========================================================
    //variance = (Sigma(x - mean)*((Sigma(x - mean)))/(n - 1)
    public bool FuncVariance(List<string> parameters, ref string result, Composite node = null)
    {
      string func_name = "Statistics.FuncVariance";
      if (parameters.Count != 1)
      {
        ppl.print("Error: [{0}] wrong operator format: Statistics.Variance(\"array_ppl\")", new object[] { func_name });
        return false;
      }
      string fullname = parameters[0];
      try
      {
        Composite cc = GetArrayComposite(fullname);
        if (cc == null)
          return false;
        //====================================================
        int length = cc._children.Count;
        double[] array = new double[length];
        bool b = false;
        double tmp = 0;
        for (int i = 0; i < length; i++)
        {
          if (cc._children[i].value == "")
          {
            array[i] = 0;
            continue;
          }
          b = Double.TryParse(cc._children[i].value, out tmp);
          if (b == false)
          {
            ppl.print("Error: [{0}] array {1}[{2}] not digital [{3}])",
              new object[] { func_name, parameters[0], i, cc._children[i].value });
            return false;
          }
          array[i] = tmp;
        }
        var v = MathNet.Numerics.Statistics.Statistics.Variance(array);
        result = v.ToString();
      }
      catch (Exception ex)
      {
        ppl.print("Error: ...");
        return false;
      }
      return true;
    }
    //====================================================
    //====================================================
    Composite GetArrayComposite(string fullname)
    {
      string func_name = "Statistics.GetArrayComposite";
      string name = "";
      string nodes = "";
      ppl.processing.SplitNodesName(fullname, ref nodes, ref name);
      Composite path = null;
      bool b = ppl.processing.GetPathAndNameFromGlobalLocal(func_name, fullname, ref path, ref nodes, ref name);
      if (b == false)
      {
        ppl.print("Error: [{0}] wrong name [{1}]", new object[] { func_name, fullname });
        return null;
      }
      Component c = null;
      for (int m = 0; m < path.GetChildren().Count; m++)
      {
        c = path.GetChildren()[m];
        if (c.name == name)
          break;
      }
      if (c == null)
      {
        ppl.print("Error: [{0}] wrong name [{1}]", new object[] { func_name, name });
        return null;
      }
      return (Composite)c;   // node array in Tree
    }
  }
}