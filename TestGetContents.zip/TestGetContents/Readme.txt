1. find in input string all quoted substrings and save them in List<string> quotedText.
	input string:		("1\"2)3") zxc (Hello)
	quoted text[0]: 	"1\"2)3"
2. replace every quoted substring in input string on it's position in quotedText surrounded by char '♥'.
	new string:	 (♥0♥) zxc (Hello)
3. find in new string substring between 'start' and 'end' characters.
	finded substring:	♥0♥
4. return in finded substring all substrings surrounded by char '♥' (p.2) with position in quotedText
	on value from  quotedText
	resulted substring:		"1\"2)3"
5. find in input string index (EndBlock) of first chararacter after char 'end'
	EndBlock = 10
6. repeat p.p.1-5 for substring wich begins from Endblock to get the next substring
	substring:	 			zxc (Hello)
	next resulted substring:	Hello