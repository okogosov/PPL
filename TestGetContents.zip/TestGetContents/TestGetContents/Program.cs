﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.InteropServices;
using System.Text;

namespace TestGetContents
{
  internal class Program
  {
    static void Main(string[] args)
    {
      int EndBlock = 0;
      char start = '(';
      char end = ')';
      string result = "";
      string input;
      //input = "(123)as";   
      //input = "as(123)";
      //input = "(\"123)as";
      //input = "(\"1\\\"2)3\") zxc (Hello)";
      //input = "(\"1\\\"2)3\" zxc (Hello)dd))";
      //input = "String.Format(\"\\\"{0}\")(\"Hello\");";
      //input = "call Convert.StringToInt32Array(\"12345\",getname(arr_int32));";
      //input = "(w\"1\\\"2***(asdfg)\") (\"qwe\")";
      input = "set x = 2*Math.Sqrt(2 + 2);";

      Console.WriteLine("{0}  [{1}]",input, input.Length);
  
      int offset = 0;
      while (true)
      {
        /*   if line 160 uncommented
        if(offset > input.Length)
        {
          Console.WriteLine("End");
          return;
        }
        */
        //EndBlock = 0;
        result = GetContents(input.Substring(offset), start, end, ref EndBlock);
        switch(EndBlock)
        {
          case -2:
            Console.WriteLine("Error: [GetContents] chars 'start' & 'end' are not same characters");
            return;
          case -1:
            Console.WriteLine("Error:[GetContents] char end is absent");
            return;
          case 0:   // line 160 commented
            Console.WriteLine("End");
            return;
          default:
            Console.WriteLine("{0} [{1}]  [{2}]", result, EndBlock, result.Length);
            offset += EndBlock;
            break;
        }     
      }

    }
    //================================================================================
    // EndBlock - next index after 'end'
    static string GetContents(string input0, char start, char end, ref int EndBlock)
    {
      string input = input0;
      List<string> quotedText = new();
      string qt = "";
      int qtBegin = 0;
      int qtEnd = 0;
      string decorator = ((char)0x2665).ToString(); //0x000F;   //♥ 
      //================================
      if (start == end)
      {
        EndBlock = -2;   // chars 'start' & 'end' are not same characters
        return "";
      }
      char[] arr = input.ToCharArray();
      bool inQuotes = false;
      char c;
      int index = 0;
      // Create quotedText list and replace in input saved quottedText  on numbers in list
      while (true)
      {
        if (index == arr.Length)
          break;
        c = arr[index];
        if (c == '\"')
        {
          if (!inQuotes)
          {
            qt = "";
            qtBegin = index;
          }
          inQuotes ^= true;
          qt += c;
          if (!inQuotes)
          {
            qtEnd = index;
            string src = input.Substring(qtBegin, qtEnd - qtBegin + 1);
            string dst = decorator + quotedText.Count + decorator;
            quotedText.Add(qt);
            input = input.Replace(src, dst);
            arr = input.ToCharArray();
            index = input.IndexOf(dst) + dst.Length;
            continue;
          }
          index++;
          continue;
        }
        if (index < arr.Length - 1)
        {
          if ((c == '\\') && (arr[index + 1] == '\"'))
          {
            qt += c;
            qt += arr[index + 1];
            index += 2;
            continue;
          }
        }
        if (!inQuotes)
        {
          index++;
          continue;
        }
        qt += c;
        index++;
      }
      //=======================
      //   processing text between start and end
      bool inContents = false;
      int counter = 0;
      EndBlock = 0;

      StringBuilder sb = new();
      for (index = 0; index < arr.Length; index++)
      {
        c = arr[index];
        if (inContents)
          sb.Append(c);
        if (c == start)
        {
          if (counter == 0)
            inContents = true;
          counter++;
        }
        if (c == end)
        {
          counter--;
          if (counter == 0)
          {
            sb.Remove(sb.Length - 1, 1);
            break;
          }
        }
      }
      string result = sb.ToString();
      if (result == "")
      {    // ()    empty contents
        //EndBlock = index + 1;
        return "";  // no char contents end
      }
      string tmp;
      // Replace in input numbers in list on saved quottedText
      for (int i = 0; i < quotedText.Count; i++)
      {
        tmp = decorator + i.ToString() + decorator;
        if (result.Contains(tmp))
          result = result.Replace(tmp, quotedText[i]);
      }
      EndBlock = input0.IndexOf(result) + result.Length + 1;
      if ((EndBlock > input0.Length) && (result.Length > 0))
      {
        EndBlock = -1;    // char end is absent
        result = "";
      }
      return result;
    }
  }
}
