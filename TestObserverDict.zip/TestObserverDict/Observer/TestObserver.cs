﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace Observer
{
  internal class TestObserver
  {
    [DllImport("Kernel32.dll")]
    private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);

    [DllImport("Kernel32.dll")]
    private static extern bool QueryPerformanceFrequency(out long lpFrequency);

    static long startTime = -1;
    static long stopTime = 0;
    static long freq = 0;
    static double duration;
    interface IObservable
    {
      void AddObserver(IObserver o);
      void RemoveObserver(IObserver o);
      void NotifyObservers();
    }
    class ConcreteObservable : IObservable
    {
      private List<IObserver> observers;
      public ConcreteObservable()
      {
        observers = new List<IObserver>();
      }
      public void AddObserver(IObserver o)
      {
        observers.Add(o);
      }

      public void RemoveObserver(IObserver o)
      {
        observers.Remove(o);
      }

      public void NotifyObservers()
      {
        foreach (IObserver observer in observers)
          observer.Update();
      }
    }

    interface IObserver
    {
      void Update();
    }
    class ConcreteObserver : IObserver
    {
      int number;
      public ConcreteObserver(int number)
      {
        this.number = number;
      }
      public void Update()
      {
        string key = "Test" + number.ToString();
      }
    }
    static void Main(string[] args)
    {
      QueryPerformanceFrequency(out freq);
      QueryPerformanceCounter(out startTime);
      ConcreteObservable concreteObservable = new ConcreteObservable();
      for (int j = 0; j < 1000000; j++)
      {
        for (int i = 0; i < 100; i++)
          concreteObservable.AddObserver(new ConcreteObserver(i));
      }
      concreteObservable.NotifyObservers();

      QueryPerformanceCounter(out stopTime);
      duration = (double)(stopTime - startTime) / (double)freq;

      Console.WriteLine("duration = {0}", duration);
      Console.WriteLine("Press any key for exit");
      Console.ReadKey();
    }
  }
}
