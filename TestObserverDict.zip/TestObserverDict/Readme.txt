Compare duration:
TestObserver - 13sec   Observer pattern
TestDict     - 5.6sec  using function call by delegates in Dictionary 
TestCompDict - 6.5sec  using function call by delegates in Dictionary & Travesal in Composite pattern