﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;


namespace TestComponentDict
{
  internal class CompDict
  {

//the single interface for primitives & composite types.|
abstract class Component
  {
    abstract public void AddChild(Component c);
    abstract public void Traverse();
  }
  //A primitive type.
  class Leaf : Component
  {
    public string name;
    public Leaf(string name)
    {
      this.name = name;
    }
    public override void AddChild(Component c)
    {
      //no action; This method is not necessary for Leaf
    }
    public override void Traverse()
    {
      //Console.WriteLine("Leaf:" + name);
    }
  }
  //A composite type.
  class Composite : Component
  {
    public string name = "";
    private ArrayList ComponentList = new ArrayList();
    public Composite(string name)
    {
      this.name = name;
    }
    public override void AddChild(Component c)
    {
      ComponentList.Add(c);
    }
    public override void Traverse()
    {
      //Console.WriteLine("Composite:" + name);
      foreach (Component c in ComponentList)
      {
          string result = "";
          keyword_dict[((Composite)c).name](ref result);
          c.Traverse();
      }
    }
    //========================================================
  }

    //==================================================
      [DllImport("Kernel32.dll")]
    private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);

    [DllImport("Kernel32.dll")]
    private static extern bool QueryPerformanceFrequency(out long lpFrequency);

    static long startTime = -1;
    static long stopTime = 0;
    static long freq = 0;
    static double duration;

    public delegate bool OperatorDelegate(ref string result);
    static Dictionary<string, OperatorDelegate> keyword_dict;
    static public void CreateKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, OperatorDelegate>();

      for (int i = 0; i < 100; i++)
        keyword_dict.Add("Test" + i.ToString(), FuncTest);
    }
    static public bool FuncTest(ref string result)
    {
      result = "Test";
      return true;
    }
    //=================================================================  



    static void Main(string[] args)
    {
      QueryPerformanceFrequency(out freq);
      QueryPerformanceCounter(out startTime);
      CreateKeywordDictionary();

      //Composite root = new Composite("Root");// Root
      Composite node = new Composite("Node"); 
      for(int i = 0; i < 100;i++)
        node.AddChild(new Composite("Test" + i.ToString()));

      for (int j = 0; j < 1000000; j++)
        node.Traverse();

      QueryPerformanceCounter(out stopTime);
      duration = (double)(stopTime - startTime) / (double)freq;

      Console.WriteLine("duration = {0}", duration);
      Console.WriteLine("Press any key for exit");
      Console.ReadKey();    
    }
  }
}
