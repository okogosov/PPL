﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace TestObserverDict
{
  internal class Dict
  {
    [DllImport("Kernel32.dll")]
    private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);

    [DllImport("Kernel32.dll")]
    private static extern bool QueryPerformanceFrequency(out long lpFrequency);

    static long startTime = -1;
    static long stopTime = 0;
    static long freq = 0;
    static double duration;

    public delegate bool OperatorDelegate(ref string result);
    static Dictionary<string, OperatorDelegate> keyword_dict;
    static public void CreateKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, OperatorDelegate>();

      for(int i = 0; i < 100;i++)
         keyword_dict.Add("Test" + i.ToString(), FuncTest);
    }
    static public bool FuncTest(ref string result)
    {
      result = "Test";
      return true;
    }
    //=================================================================  
    static void Main(string[] args)
    {
      QueryPerformanceFrequency(out freq);
      QueryPerformanceCounter(out startTime);
      CreateKeywordDictionary();
      string key = "";
      string result = "";
      for (int j = 0; j < 1000000; j++)
      {
        for (int i = 0; i < 100; i++)
        {
          key = "Test" + i.ToString();
          keyword_dict[key](ref result);
        }
      }
      
      QueryPerformanceCounter(out stopTime);
      duration = (double)(stopTime - startTime) / (double)freq;

      Console.WriteLine("duration = {0}", duration);
      Console.WriteLine("Press any key for exit");
      Console.ReadKey();
    }
  }
}
