1. to find in input string all quoted substrings and save them in List<string> StringsInQuotationMarks.
	input string:				("1\"2)3") zxc (Hello)
	StringsInQuotationMarks[0]: 	"1\"2)3"
2. to replace every quoted substring in 'notQMstring' on it's position in 'StringsInQuotationMarks' 
	surrounded by decorator char '♥'.
	notQMstring:	 (♥0♥) zxc (Hello)
3. to find in 'notQMstring' substring between 'begin' and 'end' characters.
	finded substring:	♥0♥
4. to return in finded substring all substrings surrounded by char '♥' (p.2) with position in 'StringsInQuotationMarks'
	on value from  'StringsInQuotationMarks'
	resulted substring:		"1\"2)3"
5. to find in input string index (EndBlock) of first chararacter after char 'end'
	EndBlock = 10
6. to repeat p.p.1-5 for substring which begins from Endblock to get the next substring
	substring:	 			zxc (Hello)
	next resulted substring:	Hello