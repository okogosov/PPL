﻿#region 
/*************************************************************
 * Author: Oscar Kogosov                                     *
 * email: ok21@hotmail.com                                   *
 * You must not remove this notice from this software.       *     
 *************************************************************/
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace TestQMString
{
  internal class Program
  {
    static void Main(string[] args)
    {
      int EndBlock = 0;
      char begin = '(';
      char end = ')';
      string result = "";
      string input;
      //input = "(123)as";   
      //input = "as(123)";
      //input = "(\"123)as";
      //input = "(\"1\\\"2)3\" day) zxc (Hello\"aaa\")";
      input = "(\"1\\\"2)3\" ) zxc ( ( hello\"HELLO\")dd)";
      //input = "String.Format(\"\\\"{0}\")(\"Hello\");";
      //input = "call Convert.StringToInt32Array(\"12345\",getname(arr_int32));";
      //input = "(w\"1\\\"2***(asdfg)\") (\"qwe\")";
      //input = "set x = 2*Math.Sqrt(2 + 2);";
      //input = "123 (qwerty) 456";
      //input = "func(Length(qwerty))";
      QMString qmstring;

      // test QMString.Split
      qmstring = new QMString();
      string[] tokens = qmstring.Split("\"aaa;bbb\"Hello, World;2022", 0, new char[] { ',', ';' });
      foreach (string s in tokens) Console.WriteLine(s);

      // test QMString.GetContents
      qmstring = new QMString();
      Console.WriteLine("{0}  [{1}]", input, input.Length);
      int offset = 0;
      while (true)
      {
        result = qmstring.GetContents(input, offset, begin, end, ref EndBlock);
        switch (EndBlock)
        {
          case -2:
            Console.WriteLine("Error: [GetContents] chars 'begin' & 'end' are same characters");
            return;
          case -1:
            Console.WriteLine("Error:[GetContents] char end is absent");
            return;
          case 0:
            Console.WriteLine("End");
            return;
          default:
            Console.WriteLine("{0} [{1}]  [{2}]", result, EndBlock, result.Length);
            offset += EndBlock;
            break;
        }
      }
    }
    //================================================================================
    //================================================================================
    struct Property
    {
      public string value;
      public int index;     // index  '<decorator>Number<decorator>' in notQMstring 
    }
    public class QMString // QuotationMarks class
    {
      string notQMstring = ""; // string without QuotationMarks
      int offset_in_notQMstring = 0;
      List<Property> StringsInQuotationMarks = null;
      string decorator = ((char)0x2665).ToString();    //♥ 
      //================================================================================
      //public QMString()   { }
      //================================================================================
      public void CreateStringsInQuotationMarks(string input)
      {
        char[] arr = input.ToCharArray();
        notQMstring = input;
        bool inQuotes = false;
        char c;
        int index = 0;

        string qt = "";
        int qtBegin = 0;
        int qtEnd = 0;
        StringsInQuotationMarks = new();

        // Create StringsInQuotationMarks list and notQMstring
        while (true)
        {
          if (index == arr.Length)
            break;
          c = arr[index];
          if (c == '\"')
          {
            if (!inQuotes)
            {
              qt = "";
              qtBegin = index;
            }
            inQuotes ^= true;
            qt += c;
            if (!inQuotes)
            {
              qtEnd = index;
              string src = notQMstring.Substring(qtBegin, qtEnd - qtBegin + 1);
              string dst = decorator + StringsInQuotationMarks.Count + decorator;
              Property qm;
              qm.value = qt;

              notQMstring = notQMstring.Replace(src, dst);
              ////qm.index = index - qm.value.Length;
              qm.index = notQMstring.IndexOf(dst);
              //qm.index = index;
              StringsInQuotationMarks.Add(qm);
              arr = notQMstring.ToCharArray();
              index = notQMstring.IndexOf(dst) + dst.Length;
              continue;
            }
            index++;
            continue;
          }
          if (index < arr.Length - 1)
          {
            if ((c == '\\') && (arr[index + 1] == '\"'))
            {
              qt += c;
              qt += arr[index + 1];
              index += 2;
              continue;
            }
          }
          if (!inQuotes)
          {
            index++;
            continue;
          }
          qt += c;
          index++;
        }

        return;
      }
      //================================================================================
      // EndBlock - next index after 'end' in input0.Substring(offset)
      public string GetContents(string input0, int offset, char begin, char end, ref int EndBlock)
      {
        string input = input0.Substring(offset);
        if (StringsInQuotationMarks == null)
          CreateStringsInQuotationMarks(input);
        if (begin == end)
        {
          EndBlock = -2;   // chars 'begin' & 'end' are same characters
          return "";
        }
        //=======================
        char[] arr = (notQMstring.Substring(offset_in_notQMstring)).ToCharArray();
        char c;
        //   processing text between begin and end
        bool inContents = false;
        int counter = 0;
        EndBlock = 0;
        int index = 0;
        StringBuilder sb = new();
        for (index = 0; index < arr.Length; index++)
        {
          c = arr[index];
          if (inContents)
            sb.Append(c);
          if (c == begin)
          {
            if (counter == 0)
              inContents = true;
            counter++;
          }
          if (c == end)
          {
            counter--;
            if (counter == 0)
            {
              sb.Remove(sb.Length - 1, 1);
              break;
            }
          }
        }
        string result = sb.ToString();
        offset_in_notQMstring = index + 1;
        if (result == "")
        {    // ()    empty qmstring
             //EndBlock = offset + index + 1;
          return "";  // no char qmstring end
        }
        string tmp;

        // Replace in input numbers in list on saved StringsInQuotationMarks
        for (int i = 0; i < StringsInQuotationMarks.Count; i++)
        {
          tmp = decorator + i.ToString() + decorator;
          if (result.Contains(tmp))
            result = result.Replace(tmp, StringsInQuotationMarks[i].value);
        }
        EndBlock = input0.IndexOf(result) + result.Length - offset + 1;
        if ((EndBlock > input0.Length) && (result.Length > 0))
        {
          EndBlock = -1;    // char end is absent
          result = "";
        }
        return result.Trim();
      }
      //================================================================================
      public string[] Split(string input0, int offset, char[] separators)
      {
        //========================================
        bool IsChar(char[] arrchar, char ch)
        {
          foreach (char c in arrchar)
          {
            if (c == ch)
              return true;
          }
          return false;
        }
        //========================================
        List<string> list = new();
        string input = input0.Substring(offset);
        if (StringsInQuotationMarks == null)
          CreateStringsInQuotationMarks(input);
        char[] arr = notQMstring.ToCharArray();
        char c;
        StringBuilder sb = new();
        for (int i = 0; i < arr.Length; i++)
        {
          c = arr[i];
          if (IsChar(separators, c))
          {
            list.Add(sb.ToString());
            sb.Clear();
          }
          else
          {
            sb.Append(c);
          }
        }
        if (sb.Length > 0)
          list.Add(sb.ToString());

        string tmp = "";
        for (int j = 0; j < list.Count; j++)
        {
          for (int i = 0; i < StringsInQuotationMarks.Count; i++)
          {
            if (StringsInQuotationMarks[i].index < offset)
              continue;
            tmp = decorator + i.ToString() + decorator;
            if (list[j].Contains(tmp))
              list[j] = list[j].Replace(tmp, StringsInQuotationMarks[i].value);
            list[j] = list[j].Trim();
          }
        }
        return list.ToArray();
      }
    }
  }
}
