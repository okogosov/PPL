﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TinyCompiler
{
  abstract public class Component
  {
    public string value;
    public string name;
    public Composite parent;

    // Constructor

    public Component(string name, string value)
    {
      this.name = name;
      this.value = value;
    }
    public Component()
    { }
    public abstract void Add(Component c);
    public abstract void Remove(Component c);
    public abstract void Display(int depth);
  }

  public class Composite : Component
  {
    private List<Component> _children = new List<Component>();

    public Composite(string name, string value = "")
      : base(name, value)
    {
    }
    public override void Add(Component component)
    {
      _children.Add(component);
      component.parent = this;
    }

    public override void Remove(Component component)
    {
      _children.Remove(component);
    }

    public List<Component> GetChildren()
    {
      return _children;
    }
    public void SetChildren(List<Component> children)
    {
      _children = children;
    }
    public override void Display(int depth)
    {
      String str = new String('-', depth);
      if(value == "")
        Console.WriteLine("{0}Node\tname={1}", str, name);
      else
        Console.WriteLine( "{0}Node\tname={1}\tvalue=[{2}]", str, name, value);

      // Recursively display child nodes
      foreach (Component component in _children)
      {
        component.Display(depth + 2);
      }
    }
  }
  //====================================================
  class Leaf : Component
  {
    // Constructor
    public Leaf(string name, string value = "")
      : base(name, value)
    {
    }
    public override void Add(Component c)
    {
      Console.WriteLine("Cannot add to a leaf");
    }

    public override void Remove(Component c)
    {
      Console.WriteLine("Cannot remove from a leaf");
    }
    public override void Display(int depth)
    {
      String str = new String('-', depth);
      if (value == "")
        Console.WriteLine("{0}Leaf  name={1}", str, name);
      else
        Console.WriteLine("{0}Leaf  name={1}  value=[{2}]", str, name, value );
    }
  }
}
