﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace TinyCompiler
{
  partial class Program
  {
    static public Composite parser(List<TypeValue> tokens)
    {
      Composite root = new Composite("root");
      Composite current_node = root;
      Leaf leaf = null;
      Composite node = null;
      foreach (TypeValue token in tokens)
      {
        switch (token.type)
        {
          case "number":
            leaf = new Leaf("NumberLiteral", token.value);
            current_node.Add(leaf);
            break;
          case "string":
            leaf = new Leaf("StringLiteral", token.value);
            current_node.Add(leaf);
            break;
          case "paren":
            if (token.value == "(")
            {
              node = new Composite("CallExpression");
              current_node.Add(node);
              current_node = node;
              break;
            }            
            if (token.value == ")")
              current_node = current_node.parent;
            break;
          case "name":
            node = new Composite("name", token.value);
            current_node.Add(node);
            current_node = node;
            break;
          default:
            Console.WriteLine("Error wrong type[{ 0}]", token.type);
            return null;
            break;
        }
      }
      return root;
    }
  }
}