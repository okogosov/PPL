﻿using System;
using System.Collections.Generic;

namespace TinyCompiler
{
  public  class PrefixNotation
  {
    public delegate bool OperatorDelegate(string[] parameters, ref string result);
    public Dictionary<string, OperatorDelegate> keyword_dict = null;
    public struct TypeValue
    {
      public TypeValue(string type, string value)
      {
        this.type = type;
        this.value = value;
      }
      public string type;
      public string value;
    };
    bool CallExpressionFlag = true;
    public PrefixNotation(bool CallExpressionFlag)
    {
       this.CallExpressionFlag = CallExpressionFlag;
    }
    public List<TypeValue> Tokenizer(string input)
    {
      int current = 0;
      List<TypeValue> tokens = new List<TypeValue>();
      while (current < input.Length)
      {
        char ch = input[current];
        if (ch == '(')
        {
          tokens.Add(new TypeValue("paren", "("));
          current++;
          continue;
        }

        if (ch == ')')
        {
          tokens.Add(new TypeValue("paren", ")"));
          current++;
          continue;
        }
        if (Char.IsWhiteSpace(ch))
        {
          current++;
          continue;
        }
        if (Char.IsDigit(ch))
        {
          string value = "";

          while (Char.IsDigit(ch) == true)
          {
            value += ch.ToString();
            ch = input[++current];
          }
          tokens.Add(new TypeValue("number", value));
          continue;
        }

        // We'll also add support for strings in our language which will be any
        // text surrounded by double quotes (").
        //
        //   (concat "foo" "bar")
        //            ^^^   ^^^ string tokens
        //
        // We'll start by checking for the opening quote:
        if (ch == '"')
        {
          string value = "";
          ch = input[++current];
          while (ch != '\"')  // Then we'll iterate through each character until we reach another double quote.
          {
            value += ch.ToString();
            ch = input[++current];
          }
          ch = input[++current];   // Skip the closing double quote.

          tokens.Add(new TypeValue("string", value));  // And add our `string` token to the `tokens` array.
          continue;
        }
        // The last type of token will be a `name` token. This is a sequence of
        // letters instead of numbers, that are the names of functions in our lisp
        // syntax.
        //
        //   (add 2 4)
        //    ^^^
        //    Name token
        //
        if ((Char.IsLetter(ch)) || (ch == '+') || (ch == '-'))
        {
          string value = "";
          // Again we're just going to loop through all the letters pushing them to a value.
          //while (Char.IsLetter(ch))
          while((Char.IsLetter(ch)) || (ch == '+') || (ch == '-'))
          {
            value += ch.ToString();
            ch = input[++current];
          }
          // And pushing that value as a token with the type `name` and continuing.
          // O.K. 'name' replaced on 'operator'
          tokens.Add(new TypeValue("operator", value));
          continue;
        }
        else
        {
          // Finally if we have not matched a character by now, we're going to throw an error and completely exit.
          Console.WriteLine("I dont know what this character is: {0}", ch);
          return null;
        }
      }
      return tokens;
    }
    public Composite Parser(List<TypeValue> tokens)
    {
      Composite root = new Composite("root");
      Composite current_node = root;
      Leaf leaf = null;
      Composite node = null;
      foreach (TypeValue token in tokens)
      {
        switch (token.type)
        {
          case "number":
            leaf = new Leaf("NumberLiteral", token.value);
            current_node.Add(leaf);
            break;
          case "string":
            leaf = new Leaf("StringLiteral", token.value);
            current_node.Add(leaf);
            break;
          case "paren":
            if (token.value == "(")
            {
              if (CallExpressionFlag)
              {
                node = new Composite("CallExpression");
                current_node.Add(node);
                current_node = node;
              }
              break;
            }            
            if (token.value == ")")
              current_node = current_node.parent;
            break;
          case "operator":
            node = new Composite("operator", token.value);
            current_node.Add(node);
            current_node = node;
            break;
          default:
            Console.WriteLine("Error wrong type[{ 0}]", token.type);
            root =  null;
            break;
        }
      }
      return root;
    }
    public void CreateKeywordDictionary()
    {
      keyword_dict = new Dictionary<string, OperatorDelegate>();
      keyword_dict.Add("add", FuncAdd);
      keyword_dict.Add("+", FuncAdd);  
      keyword_dict.Add("subtract", FuncSubtract);
      keyword_dict.Add("-",        FuncSubtract);
    }
    public bool FuncAdd(string[] parameters, ref string result)
    {
      Int32 ires = Int32.Parse(parameters[0]) + Int32.Parse(parameters[1]);
      result = ires.ToString();
      return true;
    }
    public bool FuncSubtract(string[] parameters, ref string result)
    {
      Int32 ires = Int32.Parse(parameters[0]) - Int32.Parse(parameters[1]);
      result = ires.ToString();
      return true;
    }
  }
}