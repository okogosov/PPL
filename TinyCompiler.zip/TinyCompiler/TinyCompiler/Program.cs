﻿// based on https://github.com/jamiebuilds/the-super-tiny-compiler
using System;
using System.Collections.Generic;

namespace TinyCompiler
{
  partial class Program
  {

    static void Run(bool b,string input)
    {
      Console.WriteLine("==================={0}   {1}===================", b, input);
      PrefixNotation pref_notation = new(b); // arg 'true' includes node 'CalExpression' to tree
      Console.WriteLine("---Tokenizer---");
      List<PrefixNotation.TypeValue> tokens = pref_notation.Tokenizer(input);
      if (tokens != null)
      {
        foreach (PrefixNotation.TypeValue tv in tokens)
          Console.WriteLine("{0}\t{1}", tv.type, tv.value);
        Console.WriteLine("---Parser---");
        Composite tree = pref_notation.Parser(tokens);
        if (tree != null)
        {
          tree.Display(1);
          Console.WriteLine("---Traversal---");
          pref_notation.CreateKeywordDictionary();
          ((Composite)tree).Traversal(pref_notation);
          Console.WriteLine("result = {0}", tree.children_results.Pop());
        }
      }
    }
    static void Main(string[] args)
    {
      Run(true,  "add 2 (subtract 4 2)");
      Run(false, "add 1(subtract 4 (+ 5 7))");
    }
  }
}

/*
  Result:
===================True   add 2 (subtract 4 2)===================
---Tokenizer---
operator        add
number  2
paren   (
operator        subtract
number  4
number  2
paren   )
---Parser---
-Node   name=root
---Node name=operator   value=[add]
-----Leaf  name=NumberLiteral  value=[2]
-----Node       name=CallExpression
-------Node     name=operator   value=[subtract]
---------Leaf  name=NumberLiteral  value=[4]
---------Leaf  name=NumberLiteral  value=[2]
---Traversal---
1  operator  add
1  CallExpression
1  operator  subtract
result = 4
===================False   add 1(subtract 4 (+ 5 7))===================
---Tokenizer---
operator        add
number  1
paren   (
operator        subtract
number  4
paren   (
operator        +
number  5
number  7
paren   )
paren   )
---Parser---
-Node   name=root
---Node name=operator   value=[add]
-----Leaf  name=NumberLiteral  value=[1]
-----Node       name=operator   value=[subtract]
-------Leaf  name=NumberLiteral  value=[4]
-------Node     name=operator   value=[+]
---------Leaf  name=NumberLiteral  value=[5]
---------Leaf  name=NumberLiteral  value=[7]
---Traversal---
1  operator  add
1  operator  subtract
1  operator  +
result = -7
*/ 