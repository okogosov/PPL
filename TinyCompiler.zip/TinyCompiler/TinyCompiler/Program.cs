﻿// based on https://github.com/jamiebuilds/the-super-tiny-compiler
using System;
using System.Collections;
using System.Collections.Generic;

namespace TinyCompiler
{
  partial class Program
  {
    public struct TypeValue
    {
      public TypeValue (string type, string value)
      {
        this.type  = type;
        this.value = value; 
      }
      public string type;
      public string value;
    };

  static public List<TypeValue>  tokenizer(string input)
    {
      int current = 0;
      List<TypeValue> tokens = new List<TypeValue> ();
      while (current < input.Length)
      {
        char ch = input[current];
        if (ch == '(')
        {
          tokens.Add(new TypeValue("paren", "("));
          current++;
          continue;
        }

        if (ch == ')')
        {
          tokens.Add(new TypeValue("paren", ")"));
          current++;
          continue;
        }
        if (Char.IsWhiteSpace(ch))
        {
          current++;
          continue;
        }
        if(Char.IsDigit(ch))
        {
          string value = "";

          while (Char.IsDigit(ch) == true)
          {
            value += ch.ToString();
            ch = input[++current];
          }
          tokens.Add(new TypeValue("number",value));
          continue;
        }

        // We'll also add support for strings in our language which will be any
        // text surrounded by double quotes (").
        //
        //   (concat "foo" "bar")
        //            ^^^   ^^^ string tokens
        //
        // We'll start by checking for the opening quote:
        if (ch == '"')
        {
          string value = "";
          ch = input[++current];          
          while (ch != '\"')  // Then we'll iterate through each character until we reach another double quote.
          {
            value += ch.ToString();
            ch = input[++current];
          }
          ch = input[++current];   // Skip the closing double quote.

          tokens.Add(new TypeValue("string", value));  // And add our `string` token to the `tokens` array.
          continue;
        }
        // The last type of token will be a `name` token. This is a sequence of
        // letters instead of numbers, that are the names of functions in our lisp
        // syntax.
        //
        //   (add 2 4)
        //    ^^^
        //    Name token
        //
        if (Char.IsLetter(ch))
        {
          string value = "";
          // Again we're just going to loop through all the letters pushing them to a value.
          while (Char.IsLetter(ch))
          {
            value += ch.ToString();
            ch = input[++current];
          }
          // And pushing that value as a token with the type `name` and continuing.
          tokens.Add(new TypeValue("name", value));
          continue;
        }
        else
        {
          // Finally if we have not matched a character by now, we're going to throw an error and completely exit.
          Console.WriteLine("I dont know what this character is: {0}",ch);
          return null;
        }
      }
      return tokens;
    }

    static void Main(string[] args)
    {
      List<TypeValue> tokens = tokenizer("(add 2 (subtract 4 2))");
      if (tokens != null)
      {
        foreach(TypeValue tv in tokens)
          Console.WriteLine("{0}\t{1}",tv.type,tv.value);
      }
      Composite tree = parser(tokens);
      if (tree != null)
        tree.Display(1);
    }
  }
}

/* output
 from tokenizer
 paren   (
 name    add
 number  2
 paren   (
 name    subtract
 number  4
 number  2
 paren   )
 paren   )

from parser
-Node   name=root
---Node name=CallExpression
-----Node       name=name       value=[add]
-------Leaf  name=NumberLiteral  value=[2]
-------Node     name=CallExpression
---------Node   name=name       value=[subtract]
-----------Leaf  name=NumberLiteral  value=[4]
-----------Leaf  name=NumberLiteral  value=[2]
*/ 