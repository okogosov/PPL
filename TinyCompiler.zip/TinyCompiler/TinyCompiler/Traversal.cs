﻿using System;
using System.Collections.Generic;

namespace TinyCompiler
{
  public partial class Composite : Component
  {
    public void Traversal(PrefixNotation pref_notation)
    {
      //Console.WriteLine("Traversal    {0} {1}", this.name, this.value);
      for (int j = _children.Count - 1; j > -1; j--)   // because results will be added to ChildrenResults stack
      {
        Component child = _children[j];
        if (child is Composite cchild)
        {
          Console.WriteLine("1  {0}  {1}", cchild.name, cchild.value);
          cchild.Traversal(pref_notation);
        }
        if (child is Leaf)
        {
     // Console.WriteLine("leaf  {0}  {1}", child.name, child.value);
          ((Composite)child.parent).children_results.Push(child.value);
          continue;
        }
      }
      if (this.name == "CallExpression")
      {
        ((Composite)parent).children_results.Push(children_results.Pop());
      }

      if (children_results.Count == 2)
      {
        string[] parameters = new string[2];
        parameters[0] = children_results.Pop();
        parameters[1] = children_results.Pop();
        string result = "";
        pref_notation.keyword_dict[value](parameters, ref result);
    // Console.WriteLine("{0}  result = {1}", value, result);
        ((Composite)parent).children_results.Push(result);
        if (parent.name == "root")
          return;
      }
    }
  }
}
