/***************************************************************
*  TreeCreatorTest                                             *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/

#include <iostream>
#include <string>
#include <iterator>
#include <list>
#include <typeinfo>
#include <string>
#include <stack>
using namespace std;

#ifndef COMPONENT_H
#define COMPONENT_H


class Component
{
  protected:
    string _className = "Component";
    //================================================================
    string SetClassName(string fullClassName)
    {
      //(typeid(this).name() = "class Component * __ptr64
      string s = fullClassName;
      string delimiter = " ";
      string token1 = s.substr(0, s.find(delimiter));
      s = s.substr(token1.length() + delimiter.length());
      return  s.substr(0, s.find(delimiter));
    }
  public:
    string name;
    string value;
    //================================================================
    Component(string name, string value)
    {
      this->name = name;
      this->value = value;
    }
    virtual void Display(int depth) const = 0;
    //================================================================
    string GetClassName()
    {
      return _className;
    }
};
//================================================================
class Leaf : public Component
{
  public:
    Leaf(string name, string value = "") : Component(name, value)
    {
      this->name = name;
      this->value = value;
      _className = SetClassName(typeid(this).name());  //(typeid(this).name() = "class Leaf * __ptr64
    }
//================================================================
    void Display(int depth) const override
    {
      string offset(depth, '-');
      //cout << offset << _className << endl;
      cout << offset << "Leaf\t" << "Name: " << this->name << "\tvalue: " << this->value << endl;
    }
//================================================================
};
//================================================================
class Composite : public Component
{
    list<Component*> _children;
    public:
    Composite(string name, string value = "") : Component(name, value)
    {
      this->name = name;
      this->value = value;
      _className = SetClassName(typeid(this).name());   //(typeid(this).name() = "class Composite * __ptr64
    }
    //================================================================
    list<Component*> GetChildren() { return _children; }
    //================================================================
    void Add(Component* c)
    {
      _children.push_back(c);
    }
    //================================================================
    void Display(int depth)  const override
    {
      string offset(depth, '-');
      if (value == "")
        cout << offset << "Node\t" << name << endl;
      else
        cout << "Node\t" << name << "\t" << value << endl;
      //cout << offset << _className << endl;
      for(const auto& i : _children)
      {
        i->Display(depth + 2);
      }
    }
};
//================================================================
#endif