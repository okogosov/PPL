/***************************************************************
*  TreeCreatorTest                                             *
*Author: Oscar Kogosov, email: ok21@hotmail.com                *
*You must not remove this notice from this software.           *
***************************************************************/

#include "TreeCreator.h"

string TreeCreator::trim(const string& source, const string& chars)
{
  std::string s(source);
  s.erase(0, s.find_first_not_of(chars));
  s.erase(s.find_last_not_of(chars) + 1);
  return s;
}
//================================================================
string TreeCreator::GetString(const string& str, const string& begin,const string& end)
{   //search forward
  string empty = "";
  string ret = "";
  try
  {    
    string::size_type i1 = str.find(begin);  //int i1 = str.IndexOf(begin);

    if (i1 == string::npos)   // if (i1 == -1)
      return empty;

    i1 += begin.length();
    int i2 = 0;
    if (end == "")
      i2 = (int)str.length();
    else
      i2 = (int)str.find_last_of(end,str.length());  //i2 = str.LastIndexOf(end, str.Length);     // search backward

    if (i2 == string::npos)   // if (i1 == -1)
      return empty;
    ret = str.substr(i1, i2 - i1);
    ret = trim(ret);
  }
  catch (...)
  {
    return "";
  }
  return ret;
}
//================================================================
bool TreeCreator::CheckNumberOfParentheses(const string& text)
{
  bool CommentFlag = false;    // only for one-line comment   //
  bool CommentFlag2 = false;   // only for multi-line comment 
  bool inQuotes = false;
  int number_parentheses = 0;
  const char*  arrch = text.c_str();  // char[] arrch = text.ToCharArray();
  char ch;

  for (long i = 0; i < text.length() - 1; i++)   // arrch.length() 
  {
    ch = arrch[i];
    if (ch == '\"')
    {
      inQuotes = !inQuotes;
      continue;
    }
    if (!inQuotes)
    {
      if ((ch == '/') && (arrch[i + 1] == '/'))
      {
        CommentFlag = true;
        i++;
        continue;
      }
      if ((ch == '/') && (arrch[i + 1] == '*'))
      {
        CommentFlag2 = true;
        i++;
        continue;
      }
      if ((ch == '*') && (arrch[i + 1] == '/'))
      {
        CommentFlag2 = false;
        i++;
        continue;
      }
      if (CommentFlag2)
        continue;
      if (ch == '\n')
      {
        CommentFlag = false;
        continue;
      }
      if (ch == '(')
        number_parentheses++;
      if (ch == ')')
        number_parentheses--;
    }
    else
    {
      if ((ch == '\\') && (arrch[i + 1] == '\"'))
      {
        i++;
        continue;
      }
      if ((ch == '\\') && (arrch[i + 1] == '\\'))
      {
        i++;
        continue;
      }
    }
  }
  ch = arrch[text.length() - 1];  // arrch.length() 
  if (ch == '\"')
    inQuotes = !inQuotes;
  if (ch == '(')
    number_parentheses++;
  if (ch == ')')
    number_parentheses--;
  if (number_parentheses != 0)
  {
    cout << "##################";
    cout << "Error: [CheckNumberOfParentheses] wrong number of parentheses";
    cout << text;
    cout << "##################";
    return false;
  }
  return true;
}
//================================================================
//================================================================
bool TreeCreator::CheckNumberOfQuotes(const string& input, const string& filename)
{
      if (input.size() == 0)
        return true;
      bool CommentFlag = false;    // only for one-line comment   //
      bool CommentFlag2 = false;   // only for multi-line comment /*... */
      bool inQuotes = false;
      char ch;
      for (long j = 0; j < input.size() - 1; j++)
      {
        ch = input[j];
        if ((CommentFlag == false) && (CommentFlag2 == false))
        { 
          if (ch == '\"')
          {
            inQuotes = !inQuotes;
            continue;
          }
        }
        if (inQuotes)
        {
          if ((ch == '\\') && (input[j + 1] == '\"'))
          {
            j++;
            continue;
          }
        }
        if ((ch == '\\') && ((input[j + 1] == '\\')))
        {
          j++;
          continue;
        }
        //================================================
        if ((ch == '/') && (input[j + 1] == '/'))
        {
          CommentFlag = true;
          j++;
          continue;
        }
        if ((ch == '/') && (input[j + 1] == '*'))
        {
          CommentFlag2 = true;
          j++;
          continue;
        }
        if ((ch == '*') && (input[j + 1] == '/'))
        {
          CommentFlag2 = false;
          j++;
          continue;
        }
        if (CommentFlag2)
          continue;
        if (ch == '\n')
        {
          CommentFlag = false;
          continue;
        }
        //================================================
      }
      if ((CommentFlag == false) && (CommentFlag2 == false))
      {
        if (input[input.size() - 1] == '\"')
          inQuotes = !inQuotes;
      }
      if (inQuotes)
      {
        string text = "Error: [CheckNumberOfQuotes] number of opened and closed quotes are not equal";
        cout << text << endl;
        text+= "\t";
        if (filename.size() != 0)
        {
          text += "[";
          text += filename;
          text += "]\t";
        }
        cout << text << input <<endl;
        return false;
      }

      return true;
}
//=====================================================
char TreeCreator::GetNextNotWhiteSpaceSymbol(const string& input,long index)
{
  for(long j = index;j < input.size() ;j++)
  {
    if (isspace(input[j]))
      continue;
    else
      return input[j];
  }
  return '\0';
}
//=================================================
bool TreeCreator::TrimPPL(string& text)
{
  if (text.length() >= 2)
  {
    text = trim(text);
    return true;
  }
  return false;
}
//================================================================
Composite* TreeCreator::CreateTree(const string& input0, bool CheckQuotesAndParentheses)
{
   //=====================================================
   if (input0 == "")
     return nullptr;
   string input = input0;
   if (CheckQuotesAndParentheses)
   {
     // for input Console, not from file
     // for input File  is checked in ReadCommandFromFile
     if (CheckNumberOfQuotes(input) == false)      // for readcode
       return nullptr;

     if (CheckNumberOfParentheses(input) == false)
       return nullptr;
   }
  
  // add parentheses, around all input if they are omitted
  for(long i2 = 0;i2 < input.size(); i2++)
  {
    char c = input[i2];
    if ((c == '(') && (i2 == 0))
      break;
    if ((c == 0xD) || (c == 0xA))
      break;
    if ((c != '('))
    {
      if (input[input.size() - 1] != ';')
        input = "(" + input + ")";
      else
        input = "(" + input.substr(0, input.size() - 1) + ");";
      break;
    }
  }
  Composite* root = nullptr; 
 
  string value = "";
  string name = "";
  int open_brackets = 0;
  int number_quotes = 0;
  bool inQuotes = false;
  long counter_leaf = 0;
  for (long k = 0; k < input.size(); k++)
  {
    char c = input[k];
    switch (c)
    {
      case '/':
        value.push_back(c); 
      break;
      case '\"':
        value.push_back(c);   //value += c.ToString();
        number_quotes ^= 1;
        inQuotes ^= true;
      break;
      case '\\':
      {
        if (k != input.size() - 1)
        {
          if (input[k + 1] == '\\')
          {
            value.push_back('\\');
            k++;
            break;
          }
          if (input[k + 1] == '\"')
          {
            char ch2 = GetNextNotWhiteSpaceSymbol(input, k + 2);
            if ((ch2 == ')') || (ch2 == ']') || (ch2 == '\0'))
            {
              value.push_back('\"');
              value.push_back(ch2);
              k += 2;
            }
            else
            {
              value.push_back('\"');
              k++;
            }
          }
          else
            value.push_back(c);
        }
      }
      break;
      case '\t':
      case '\n':
      case '\r':
        break;

      case '[':
      {
        if (number_quotes == 0)
          open_brackets++;
        value.push_back(c); //value += c.ToString();
      }
      break;
      case ']':
      {
        if (number_quotes == 0)
          open_brackets--;
        value.push_back(c);
      }
      break;
      case ';':
      {
        if (open_brackets != 0)
          value.push_back(c); 
      //...
      if (number_quotes == 1)
      {
        if (value[value.length() - 1] != ';')      // value.last()
          value.push_back(c); 
        break;
      }
      }
      break;
    //==============================================
      case '(':
      {
      if (open_brackets != 0)
      {
        value.push_back(c); 
        break;
      }
      if (number_quotes == 1)
      {
        value.push_back(c);  
        break;
      }
      if (parentheses->size() == 0)
      {
        parentheses->push(c);
        root = new Composite("root");
        nodes->push(root);
        value = "";
        break;
      }
      if (parentheses->top() == ')')   
      {
        parentheses->pop();
        parentheses->push(c);
        value = "";
        break;
      }
      if (parentheses->top() == '(')    
      {
        string value_tmp = "";
        name = "";
        if (value != "")
        {
          value = trim(value);//value = value.Trim();
          value_tmp = GetString(value, "[", "]");
          string::size_type i = value.find("[");  //int i = value.IndexOf('[');  
          if (i > 0)
            name = value.substr(0, i);    // name = value.Substring(0, i);
          if (i == string::npos)
            name = value;
        }
        if (name == "")
        {
          name = "#";      //  parentheses block 
          value_tmp = "internal_block";
        }
       
        Composite* node = new Composite(trim(name), value_tmp);

        value = "";
        Composite* parent = nodes->top();
        //================================================
        parent->Add(node);
        nodes->push(node);
        parentheses->pop();
        parentheses->push(c);
      }
      break;
    }
    //==============================================
      case ')':
      {
      if (open_brackets != 0)
      {
        value.push_back(c);
        break;
      }
      if (number_quotes == 1)
      {
        value.push_back(c);
        break;
      }
//===========================================
      if (parentheses->top() == '(')
      {
        string tmp = "";
        string value_tmp = "";
        string value_orig = "";
        name = "";
        if (value != "")
        {
          tmp = value;
          if (value.find('\"') == string::npos)  //if (value.Contains('\"'.ToString()) == false)
          {
            value_tmp = GetString(value, "[", "]");

            string::size_type i = value.find_last_of('[');  //     int i = value.IndexOf('[');
            if (i > 0)
            {
              if (CheckNumberOfParentheses(value) == false)
              {
                return nullptr;
              }
              name = value.substr(0, i);
            }
            else
              name = value;
          }
          else
          { // set data in quotes and remove quotes
            value_orig = value;
            value = trim(value);
            if (value[0] == '\"')
            {
              name = "#"; // ex. write("y[{0}] = ...")
              value_tmp = value;
              name = trim(value_tmp, "\"");

              if (TrimPPL(value_tmp) == false)
              {
                cout << "Error: [Parser] wrong data [" << value_tmp;
                return nullptr;
              }
              name = value_tmp;
              value_tmp = "";
            }
            else
            {
              // var(x["===[xxx]==="])
              value_tmp = GetString(value, "[", "]");
              string::size_type offset = value.find("[");
              if (offset == 0)
              {
                name = "#";
              }
              if (offset == string::npos)
              {
                name = value;
              }
              else
                name = value.substr(0, offset);
            }
          }
        }
        //===========================================
        value_orig = trim(value_orig);
        if(value_orig[0] != '\"')       //if (value_orig.StartsWith("\"") == false)
          name = trim(name);
        else
        {
          name = value_orig;
        }

        Leaf* leaf = new Leaf(name, value_tmp);
        //============================
        counter_leaf++;
        if (counter_leaf % 100000 == 0)
          cout << "leaf_counter = " << counter_leaf << " leaf->name = " <<  leaf->name;
        //============================
        value = "";
        parentheses->pop();
        parentheses->push(c);
        Composite* parent = nodes->top();
        parent->Add(leaf);
        break;
        //===========================================
      }

      if (parentheses->top() == ')')
      {
        if (nodes->size() == 0)
          break;
        nodes->pop();
        parentheses->pop();
        parentheses->push(c);
      }
      break;
    }
    //==============================================
      default:
      {
        value.push_back(c); 
        break;
      }
    }
  }
  if (open_brackets != 0)
  {
    cout << "Error: [Parser] number of brackets are wrong" << endl;
    return nullptr;
  }
  if (parentheses->size() > 0)
    parentheses->pop();
  if (nodes->size() > 0)
    nodes->pop();
  return root;
}