#ifndef TREE_CREATOR_H
#define TREE_CREATOR_H

#include "Component.h"
using namespace std;
const string WHITESPACE = " \n\r\t\f\v";
class TreeCreator
{
    stack<Composite*>* nodes = new stack<Composite*>;
    stack<char>* parentheses = new stack<char>;

    string trim(const string& source, const string& chars = WHITESPACE);
    string GetString(const string& str, const string& begin, const string& end);
    bool CheckNumberOfParentheses(const string& text);
    bool CheckNumberOfQuotes(const string& input, const string& filename = "");
    char GetNextNotWhiteSpaceSymbol(const string& input, long index);
    bool TrimPPL(string& text);
public:
    Composite* CreateTree(const string& input0, bool CheckQuotesAndParentheses = false);
  
    ~TreeCreator()
    {
      delete nodes;
      delete parentheses;
    }
};
#endif