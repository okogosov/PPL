#include "TreeCreator.h"

int main()
{
  TreeCreator* tc = new TreeCreator();
  const char* countries =
    "Countries"
      "(Italy"
        "(Roma)(Milan)(Turin))"
      "(France"
        "(Paris)(Marseile)(Provence))"
      "(Spain"
        "(Madrid)(Granada)(Alicante))";

  Composite* root = tc->CreateTree(countries);
  root->Display(1);
  delete tc;
}


/*
-Node   root
---Node Countries
-----Node       Italy
-------Leaf     Name: Roma      value:
-------Leaf     Name: Milan     value:
-------Leaf     Name: Turin     value:
-----Node       France
-------Leaf     Name: Paris     value:
-------Leaf     Name: Marseile  value:
-------Leaf     Name: Provence  value:
-----Node       Spain
-------Leaf     Name: Madrid    value:
-------Leaf     Name: Granada   value:
-------Leaf     Name: Alicante  value:
*/
